<template>
  <div class="relative flex-column overflow-hidden full-height full-width">
    <div class="sticky-header sticky">
      <GeneralFeedback v-if="allowGeneralFeedback && !isSmallScreen"></GeneralFeedback>
      <SettingsDialog class="bs-font-medium-3-normal settings-btn" />
    </div>
    <div class="relative full-height full-width flex-1 overflow-auto conv-container conv-body">
      <div class="relative flex-column full-height">
        <div
          class="relative flex-1 full-height overflow-hidden"
          :class="{ loading: loadingQuestion }"
        >
          <div
            class="full-height full-width overflow-y"
            ref="scrollArea"
            id="conv-scroll-area"
            @scroll="debouncedScrollHanlder"
          >
            <div class="full-width overflow-hidden">
              <div
                v-for="(item, index) in currentConversation?.data"
                :key="item.id"
                class="flex-column history full-width overflow-hidden"
              >
                <QuestionCard :query="item.query" :letter-icon="userNameFirstLetter">
                  <FilePreview
                    :uploaded-image="item.uploaded_image"
                    v-if="item.uploaded_image"
                    :height="'70%'"
                    :width="'100%'"
                    style="margin-top: 4px"
                  ></FilePreview>
                  <FiltersContainer :filters="item.filters" v-if="item.filters" />
                </QuestionCard>
                <AnswerCard
                  v-if="item.query && item.query !== ''"
                  :answer="item.answer ? item.answer: index < currentConversation!.data.length-1 ? t('error_message') : ''"
                  :feedback="item.feedback"
                  :feedback-options-negative="setup.feedbackNegativeChoices ?? []"
                  :feedback-options-positive="setup.feedbackPositiveChoices ?? []"
                  :kb-on="item.kbOn"
                  :db-on="item.dbOn"
                  @update:feedback="(value) => logFeedback(item.id, item, value)"
                  :typing-effect-on="false"
                  :error-state="errorState"
                  :loading="loadingQuestion && index === currentConversation!.data.length - 1"
                  :query-index="index"
                  :step="item.step || 'loading'"
                  @expand-source="(value) => (expandSource = value)"
                >
                  <SourcesContainer
                    class="self-start"
                    :sources="item.sources"
                    :query-index="index"
                    :project-key="setup.projectKey"
                    :folder-id="setup.docsFolderId"
                    :expandSource="expandSource"
                    v-if="item.sources && item.sources.length > 0 && (item.kbOn || item.dbOn)"
                    @update:expanded="(value) => handleSourceExpanded(index, value)"
                  />
                </AnswerCard>
              </div>
            </div>
          </div>
          <q-btn
            round
            dense
            v-if="isScrollArrowVisible"
            class="absolute scroll-down-btn"
            @click="debouncedScrollToBottom"
          >
            <q-icon name="arrow_downward" />
          </q-btn>
        </div>
        <div class="full-width conv-container conv-footer">
          <RetrievalToggle
            v-if="retriever"
            v-model:model-value="useRetriever"
            :retrieval-type="retrievalMode"
            :label="retriever.alias"
          ></RetrievalToggle>
          <UserInput
            ref="userInputAreaRef"
            id="user-query-container"
            class="full-width"
            :input-placeholder="inputPlaceholder"
            :value="currentData.query"
            :loading="loadingQuestion"
            :file-path="currentData.file_path"
            :uploaded-image="currentData.uploaded_image"
            :file-input-enabled="enableFileUpload"
            :streaming-enabled="streamingEnabled"
            @send="submitQuery"
            @stop="stopQuery"
            @enterkey="submitQuery"
            @uploadFile="uploadFile"
            @deleteFile="deleteFile"
            @update:value="
              (value) => {
                currentData.query = value
              }
            "
          />
          <DisclaimerSection />
          <div
            class="full-width flex btn-solutions-footer-container"
            v-if="allowGeneralFeedback && isSmallScreen"
          >
            <GeneralFeedback></GeneralFeedback>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { toRefs, computed, ref, onMounted, onBeforeUnmount } from 'vue'
import { useConversation } from '@/components/composables/use-conversation'
import QuestionCard from '@/components/QuestionCard.vue'
import AnswerCard from '@/components/AnswerCard.vue'
import SourcesContainer from '@/components/SourcesContainer.vue'
import { useUI } from '@/components/composables/use-ui'
import { useI18n } from 'vue-i18n'
import UserInput from '@/components/UserInput.vue'
import { watch } from 'vue'
import FiltersContainer from '@/components/FiltersContainer.vue'
import FilePreview from '@/components/FilePreview.vue'
import DisclaimerSection from '@/components/DisclaimerSection.vue'
import SettingsDialog from '@/components/SettingsDialog.vue'
import { debounce } from 'lodash'
import GeneralFeedback from '@/components/GeneralFeedback.vue'
import RetrievalToggle from '@/components/RetrievalToggle.vue'
import { useRetrievalToggle } from '@/components/composables/use-retrieval-toggle'
const { t } = useI18n()

const expandSource = ref({ sourceIndex: '', citationIndex: '', queryIndex: '' })
const props = defineProps<{
  id: string
}>()

const { id } = toRefs(props)
const {
  currentData,
  currentConversation,
  errorState,
  loadingQuestion,
  sendQuestion,
  stopQuery,
  logFeedback,
  uploadFile,
  deleteFile
} = useConversation(id)

const { setup } = useUI()
const { retriever, useRetriever, retrievalMode } = useRetrievalToggle()
const allowGeneralFeedback = computed(() => {
  return setup.value.allowGeneralFeedback
})

const enableFileUpload = computed(() => {
  return setup.value?.llmCapabilities?.multiModal
})
const streamingEnabled = computed(() => {
  return setup.value?.llmCapabilities?.streaming
})

const userNameFirstLetter = computed(() => {
  return setup.value?.user?.length ? setup.value?.user[0].toLocaleUpperCase() : '?'
})

const scrollArea = ref<HTMLElement | null>(null)
const isScrollArrowVisible = ref(false)

const scrollToBottom = () => {
  if (scrollArea.value) {
    scrollArea.value.scrollTo({
      top: scrollArea.value.scrollHeight,
      behavior: 'smooth'
    })
  }
}
const scrollHandler = () => {
  if (scrollArea.value) {
    isScrollArrowVisible.value =
      scrollArea.value.scrollTop + scrollArea.value.clientHeight + 5 < scrollArea.value.scrollHeight
  }
}
const debouncedScrollToBottom = debounce(scrollToBottom, 200)
const debouncedScrollHanlder = debounce(scrollHandler, 50)
watch(id, debouncedScrollToBottom)

function handleSourceExpanded(index: number, newVal: string) {
  if (
    newVal &&
    currentConversation.value?.data.length &&
    index === currentConversation.value.data.length - 1
  ) {
    debouncedScrollToBottom()
  }
}

const inputPlaceholder = computed(() => {
  return setup.value.questionPlaceholder || t('questionPlaceholder')
})

const submitQuery = () => {
  debouncedScrollToBottom()
  sendQuestion()
}

let resizeObserver: ResizeObserver | undefined
let mutationObserver: MutationObserver | undefined
let windowResizeObserver: ResizeObserver | undefined

const isSmallScreen = ref(false)
const checkSmallScreen = () => {
  isSmallScreen.value = useUI().isSmallScreen()
}
onBeforeUnmount(() => {
  if (resizeObserver) {
    resizeObserver.disconnect()
  }
  if (mutationObserver) {
    mutationObserver.disconnect()
  }
  if (windowResizeObserver) {
    windowResizeObserver.disconnect()
  }
})
onMounted(() => {
  debouncedScrollToBottom()
  checkSmallScreen()
  if (scrollArea.value) {
    resizeObserver = new ResizeObserver(debouncedScrollHanlder)
    resizeObserver.observe(scrollArea.value)
    // debouncedScrollHanlder(); // initial check
    // Use MutationObserver to detect changes in the DOM
    mutationObserver = new MutationObserver(debouncedScrollHanlder)
    mutationObserver.observe(scrollArea.value, {
      childList: true,
      subtree: true,
      attributes: true
    })
  }
  windowResizeObserver = new ResizeObserver(() => {
    checkSmallScreen()
  })
  windowResizeObserver.observe(document.body)
})
</script>

<style lang="scss" scoped>
@media (min-width: 1500px) {
}
.conv-container {
  max-width: 800px;
  align-self: center;
}
.conv-footer {
  margin-top: 5px;
  flex-shrink: 0;
}

.history {
  gap: 16px;
  margin-bottom: 16px;
}

.history:first-child {
  padding-top: 0px !important;
}

.history:first-child {
  border-top: none;
}

.clear-history-btn {
  margin-left: auto;
  margin-right: 10px;
  display: inline-flex;
  align-self: flex-start;
}

.scroll-down-btn {
  bottom: 2%;
  right: 50%;
  z-index: 100;
  background-color: white;
}
.btn-solutions-footer-container {
  justify-content: flex-end;
  padding-right: 8px; /*to align with the right edge of the disclaimer*/
}
</style>
