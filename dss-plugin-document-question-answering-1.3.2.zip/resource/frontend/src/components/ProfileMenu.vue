<template>
  <q-menu auto-close>
    <q-list style="min-width: 100px">
      <q-item clickable>
        <q-item-section>
          <div class="flex-row bs-font-medium-3-normal">
            <q-icon name="logout" color="primary" style="align-self: center;"></q-icon>
            <div>
              {{ $t('logout') }}
            </div>
          </div>
        </q-item-section>
      </q-item>
    </q-list>
  </q-menu>
</template>
<style scoped>
.q-item {
  padding-left: 12px !important;
}
</style>
