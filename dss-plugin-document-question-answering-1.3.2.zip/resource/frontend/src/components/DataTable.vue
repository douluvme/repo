<template>
    <div class="q-pa-xs">
        <BsTable
            :title="title"
            :rows="rows"
            :columns="columns"
            row-key="name"
        />
    </div>
</template>
<script setup lang="ts">
import { BsTable } from 'quasar-ui-bs'
defineProps<{
    title?: string;
    columns: Record<string, any>[];
    rows: Record<string, any>[];
 }>()

</script>
