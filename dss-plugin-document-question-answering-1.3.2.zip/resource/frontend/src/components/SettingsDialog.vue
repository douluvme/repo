<template>
  <div>
    <q-btn
      flat
      dense
      no-caps
      no-wrap
      color="primary"
      @click="openSettingsDialog = true"
      size="md"
      class="bs-font-medium-3-normal settings-btn-dialog"
    >
      <q-icon size="32px" style="margin-right: 2px" color="black">
        <SettingsIcon color="currentColor" />
      </q-icon>
      <q-dialog persistent :model-value="openSettingsDialog">
        <q-card style="width: 600px">
          <SettingsDialogHeader @cancel="cancel" />
          <q-separator />
          <q-card-section>
            <UserSettings
              :settings="userSettings"
              @update:settings="updateUserSettings"
            ></UserSettings>
          </q-card-section>
          <q-card-section v-if="!noRetrievalSetup && retriever">
            <div class="row items-center no-wrap q-gutter-x-sm">
              <div class="bs-font-medium-4-semi-bold">{{ t('sources') }}</div>
            </div>
            <div>
              <RetrievalToggle
                v-model:model-value="useRetriever"
                :retrieval-type="retriever.type"
                :label="retriever.alias"
              >
              </RetrievalToggle>
            </div>
            <FiltersSettings
              v-if="useRetriever && setup.retrievalMode === RetrievalMode.KB"
              :filters="filters"
              @update:settings="updateSelectedOption"
            ></FiltersSettings>
          </q-card-section>
          <q-card-actions align="right">
            <bs-button class="bs-btn-flat-danger dku-text" unelevated flat @click="cancel">
              {{ t('cancel') }}</bs-button
            >
            <bs-button
              class="bs-btn-flat dku-text"
              unelevated
              flat
              @click="apply"
              color="primary"
              >{{ t('apply') }}</bs-button
            >
          </q-card-actions>
        </q-card>
      </q-dialog>
    </q-btn>
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ref, computed } from 'vue'
import { useSettings } from './composables/use-settings'
import { useUI } from './composables/use-ui'
import SettingsIcon from './icons/SettingsIcon.vue'
import { watch } from 'vue'
import { isEqual } from 'lodash'
import RetrievalToggle from './RetrievalToggle.vue'
import { RetrievalMode } from '@/models'
import SettingsDialogHeader from './SettingsDialogHeader.vue'
import FiltersSettings from './FiltersSettings.vue'
import UserSettings from './UserSettings.vue'
const { t } = useI18n()

const openSettingsDialog = ref(false)
const { setup, updateUserProfile } = useUI()
const {
  filtersSelections: selectedFilters,
  knowledgeBankSelection: selectedKnowledgeBankId,
  dbSelection,
  retrieverSelected,
  userSettings
} = useSettings()
const useRetriever = ref(retrieverSelected.value ? true : false)
watch(retrieverSelected, () => {
  useRetriever.value = retrieverSelected.value ? true : false
})
const filters = ref({ ...selectedFilters.value })
function updateSelectedOption(column: string, newVal: string[]) {
  filters.value[column] = newVal
}

const retriever = computed(() => {
  return setup.value.retriever
})
watch(setup, (newVal, oldVal) => {
  if (isEqual(newVal.retriever?.id, oldVal.retriever?.id)) {
    return
  }
  if (retriever.value) {
    if (retriever.value.activated) {
      selectedKnowledgeBankId.value =
        setup.value.retrievalMode === RetrievalMode.KB ? retriever.value.id : null
      dbSelection.value = setup.value.retrievalMode === RetrievalMode.DB ? retriever.value.id : null
      useRetriever.value = true
    } else {
      useRetriever.value = selectedKnowledgeBankId.value ? true : false
    }
  } else {
    selectedKnowledgeBankId.value = null
    dbSelection.value = null
    retrieverSelected.value = false
  }
})
const noRetrievalSetup = computed(() => {
  return !retriever.value || setup.value.retrievalMode === RetrievalMode.NO_RETRIEVER
})

const updateUserSettings = (val: Record<string, any>) => {
  userSettings.value = val
}
const cancel = () => {
  useRetriever.value = selectedKnowledgeBankId.value !== null || dbSelection.value !== null
  filters.value = { ...selectedFilters.value }
  openSettingsDialog.value = false
  userSettings.value = JSON.parse(JSON.stringify(setup.value.currentUserProfile))
}
const apply = async () => {
  if (useRetriever.value && retriever.value) {
    selectedKnowledgeBankId.value =
      setup.value.retrievalMode === RetrievalMode.KB ? retriever.value.id : null
    dbSelection.value = setup.value.retrievalMode === RetrievalMode.DB ? retriever.value.id : null
    retrieverSelected.value = true
  } else {
    selectedKnowledgeBankId.value = null
    dbSelection.value = null
    retrieverSelected.value = false
  }
  selectedFilters.value = { ...filters.value }
  openSettingsDialog.value = false
  if (!isEqual(userSettings.value, setup.value.currentUserProfile)) {
    await updateUserProfile(
      userSettings.value,
      t('update_user_profile_success'),
      t('update_user_profile_failure')
    )
  }
}
</script>

<style scoped lang="scss">
.flex-column-14 {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.disabled {
  color: grey;
  opacity: 0.7 !important;
}
.settings-btn-dialog {
  border: 1px solid var(--q-primary);
  border-radius: 8px;
}
</style>
