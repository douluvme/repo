<template>
  <q-btn
    outline
    no-caps
    no-wrap
    class="bs-font-medium-3-normal btn-solution"
    size="md"
    id="feedback-btn-general"
  >
    <q-icon size="18px" :name="`img:${dataikuIcon}`" style="margin-right: 2px"></q-icon
    ><span class="btn-solution-text">{{ $t('feedback_btn_general') }}</span>

    <FeedbackProxyPopup
      :feedback-value="feedbackValue"
      :feedback-options="[]"
      :submit-on-hide="false"
      @save="submitFeedback"
    />
  </q-btn>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import { FeedbackValue, type Feedback } from '@/models'
import { ServerApi } from '@/api/server_api'
import { useSettings } from './composables/use-settings'
import dataikuIcon from '@/assets/icons/dataiku.png'
const { knowledgeBankSelection } = useSettings()
// Reactive data
const feedbackValue = ref(FeedbackValue.GENERAL)
// Method
function submitFeedback(feedback: Feedback) {
  if (!feedback.message) return
  ServerApi.logGeneralFeedback({
    message: feedback.message,
    knowledge_bank_id: knowledgeBankSelection.value ?? ''
  })
}
</script>

<style scoped>
#feedback-btn-general {
  max-width: 170px;
}
.btn-solution-text {
  color: #000000;
  font-family: 'SourceSansPro';
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 12px;
  white-space: nowrap;
}

.btn-solution {
  color: #c8c8c8;
  z-index: 99;
  border-radius: 4px;
  display: inline-flex;
  align-self: center;
}
</style>
