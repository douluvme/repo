<template>
  <div class="dku-tiny-text disclaimer" id="disclaimer">
    <div v-html="disclaimerText"></div>
  </div>
</template>
<script lang="ts">
import { useUI } from '@/components/composables/use-ui'
import DOMPurify from 'dompurify';
export default {
  computed: {
    disclaimerText() {
      // use dompurify to sanitize the html
      return DOMPurify.sanitize(useUI().setup.value.disclaimer || '');
    }
  },
}
</script>
