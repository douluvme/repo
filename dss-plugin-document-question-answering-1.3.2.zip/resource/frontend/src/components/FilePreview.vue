<template>
  <div :style="imgStyle">
    <img :src="image" class="file-preview" :style="imgStyle" @load="emits('loaded')" />
    <q-icon :name="`img:${closeOutline}`" class="cursor-pointer file-preview-close" @click="emits('delete')" size="xs" v-if="removable"/>
  </div>
</template>

<script setup lang="ts">
import { toRefs } from 'vue'
import { computed } from 'vue'
import closeOutline from '@/assets/icons/close-outline.svg'
const props = defineProps<{
  uploadedImage: string,
  height?: string,
  width?: string,
  removable?: boolean
}>()
const emits = defineEmits(['loaded', 'delete'])
const {  uploadedImage, height, width } = toRefs(props)

const imgStyle = computed(() => ({
  maxHeight: height?.value ?? '70px',
  maxWidth: width?.value ?? '100px'
}));

const image = computed(() => {
  return uploadedImage.value
})
</script>
<style>
.file-preview {
  display: inline;
}
.file-preview-close{
  position: absolute;
  top: 4px;
}
</style>
