<template>
    <q-avatar
        color="primary"
        text-color="white"
        size="lg"
        style="font-weight: 500"
        clickable
        class="cursor-pointer profile-menu-btn"
        id="profile-menu"
    >
        {{ userNameFirstLetter }}
        <ProfileMenu />
    </q-avatar>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import ProfileMenu from './ProfileMenu.vue'
import { useUI } from './composables/use-ui';
const { setup } = useUI()
const userNameFirstLetter = computed(() => {
  return setup.value?.user?.length ? setup.value?.user[0].toLocaleUpperCase() : '?'
})
</script>

<style scoped>
.profile-menu-btn {
    align-self: center;
}
</style>
