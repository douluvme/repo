<template>
  <q-card-section>
    <div class="row items-center justify-between">
      <div class="row items-center no-wrap q-gutter-x-sm">
        <q-icon size="24px">
          <SettingsIcon />
        </q-icon>
        <div class="dku-grand-title">{{ t('settings') }}</div>
      </div>
      <q-icon size="24px" name="close" style="cursor: pointer" @click="$emit('cancel')"></q-icon>
    </div>
  </q-card-section>
</template>

<script setup lang="ts">
import SettingsIcon from './icons/SettingsIcon.vue'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
</script>
