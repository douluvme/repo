<template>
  <q-expansion-item
    :label="$t('sources')"
    v-model="expanded"
    header-class="expansion-item"
    switch-toggle-side
    class="sources-expansion-item"
    :id="`query_${queryIndex}_sources`"
  >
    <div class="source-item">
      <div v-for="(source, index) in sources" :key="index" class="source-text">
        <div class="source-meta" :id="`meta_${queryIndex}_source_${index + 1}`">
          <img
            class="source-thumbnail"
            :src="(source.metadata.source_thumbnail_url as string)"
            v-if="source.metadata?.source_thumbnail_url"
          />
          <div>
            <span>{{ `${index + 1}. ` }} </span>
            <span v-if="getUrlFromSource(source)">
              <a :href="getUrlFromSource(source)!" target="_blank" class="source-link">
                <span class="source-title">{{ getSourceTitle(source) }}</span>
              </a>
            </span>
            <span v-else class="source-title">{{ getSourceTitle(source) }}</span>
            <span v-if="source.sample && source.sample.columns" class="source-sample"> ({{ $t('sample') }}) </span>
          </div>
        </div>
        <div
          v-if="source.sample && source.sample.columns"
          :id="`query_${queryIndex}_source_${index + 1}`"
          class="source-content"
        >
          <div v-if="displaySqlQuery">
            <div class="source-query-container">
              <span class="source-sql-query"> {{ $t('sql_query') }} </span>
              <br />
              <span class="source-query"> {{ source.sample.query }} </span>
            </div>
          </div>
          <DataTable :rows="source.sample.rows" :columns="source.sample.columns"></DataTable>
        </div>
        <div
          v-else-if="source.excerpt && displaySourceChunks"
          :id="`query_${queryIndex}_source_${index + 1}`"
          v-html="convertNewlinesToHTML(sanitize(source.excerpt))"
          class="source-content"
        ></div>
        <TagsContainer :tags="getSourceTags(source)" v-if="source.metadata?.tags" />
      </div>
    </div>
  </q-expansion-item>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import type { Source } from '@/models'
import TagsContainer from './TagsContainer.vue'
import type { PropType } from 'vue'
import DOMPurify from 'dompurify'
import DataTable from './DataTable.vue'
import { useUI } from '@/components/composables/use-ui'

const { setup } = useUI()

const urlRegex =
  /(?:https?|ftp):\/\/[\S]+|(www\.[\S]+)|(?:\b\w+\.\w{2,}(?::\d{1,5})?(?:\/[\S]*)?\b)/gi
export default defineComponent({
  props: {
    sources: {
      type: Array as () => Source[],
      required: true
    },
    queryIndex: {
      type: Number,
      required: true
    },
    projectKey: {
      type: String,
      default: ''
    },
    folderId: {
      type: String,
      default: ''
    },
    expandSource: {
      type: Object as PropType<{ sourceIndex: string; citationIndex: string; queryIndex: string }>
    }
  },
  data() {
    return {
      expanded: false,
      timeout: undefined as ReturnType<typeof setTimeout> | undefined,
      displaySqlQuery: setup.value.displaySqlQuery
    }
  },
  methods: {
    getSourceTitle(source: Source) {
      if (!source.metadata) {
        return ''
      }

      const { source_title, page, score } = source.metadata
      if (!source_title) {
        return ''
      }

      const metadataParts = []
      if (page) {
        metadataParts.push(`Page: ${page}`)
      }
      if (score) {
        metadataParts.push(`Similarity Score: ${score}`)
      }

      const metadataString = metadataParts.length > 0 ? `, ${metadataParts.join(', ')}` : ''
      return `${source_title}${metadataString}`
    },
    sanitize(str: string) {
      return DOMPurify.sanitize(str, { FORBID_TAGS: ['input'] })
    },
    getUrlFromSource(source: Source): string | null {
      return (source.metadata?.source_url as string) ?? null
    },
    isFileName(str: string): boolean {
      return /\.(pdf|docx|doc|xls|xlsx|ppt|pptx|txt|csv)$/i.test(str)
    },
    getUrlFromString(txt: string): string {
      const urls = txt.match(urlRegex) || []
      return urls.length > 0 ? (urls[0] as string) : ''
    },
    getDomainFromUrl(url: string): string {
      const match = url.match(/^(?:https?:\/\/)?(www\.)?([^/]+)/i)
      return match ? match[0] : ''
    },
    convertNewlinesToHTML(str: string): string {
      const lines = str.split('\n\n')
      let convertedString = lines[0]
      for (let i = 1; i < lines.length; i++) {
        convertedString += "<div style='margin-bottom: 6px;'>" + lines[i] + '</div>'
      }
      return convertedString
    },
    getSourceTags(source: Source) {
      if (source.metadata && source.metadata.tags) {
        const tags = {} as any
        ;(source.metadata.tags as any[]).forEach(
          (el: { name: string; value: string; type: string }) =>
            (tags[el.name] = el.type === 'string' ? [el.value] : [...el.value])
        )
        return tags
      }
    },
    handleExpandSource(info: Record<string, string>) {
      this.expanded = true
      this.timeout = setTimeout(() => {
        const href = this.displaySourceChunks ? `#query_${this.queryIndex}_source_${info['sourceIndex']}`: `#meta_${this.queryIndex}_source_${info['sourceIndex']}`;
        const targetElement = document.querySelector(href)
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' })
        }
      }, 200)
    },
    expandEventHandler(event: Event) {
      this.handleExpandSource((event as CustomEvent).detail)
    }
  },
  watch: {
    expandSource(info: Record<string, string>) {
      this.handleExpandSource(info)
    }
  },
  computed: {
    displaySourceChunks() {
      return setup.value.displayChunks
    }
  },
  components: { TagsContainer, DataTable },
  mounted() {
    const element = document.getElementById(`query_${this.queryIndex}_sources`)
    element?.addEventListener('expandSource', this.expandEventHandler)
  },
  beforeUnmount() {
    const element = document.getElementById(`query_${this.queryIndex}_sources`)
    element?.removeEventListener('expandSource', this.expandEventHandler)
    clearTimeout(this.timeout)
  }
})
</script>
<style scoped>
.expansion-item {
  font-style: normal;
  font-weight: 600;
  font-size: 20px;
  line-height: 15px;
  color: #666666;
  width: 100%;
}
.sources-expansion-item {
  margin-top: 8px;
  font-size: 12px;
  /* color: teal; */
  margin-left: -4px;
  color: #444;
  font-weight: bold;
  max-width: 90%;
}
:deep(.q-item) {
  padding: 4px;
}
:deep(.q-item__section--side > .q-icon) {
  font-size: 16px;
}
.source-item {
  margin-top: 5px;
  margin-bottom: 5px;
  word-wrap: break-word;
  overflow: hidden; /* Prevents overflowing */
}
.source-text {
  font-style: normal;
  font-weight: 400;
  font-size: 11px;
  line-height: 16px;
  /* color: teal; */
  color: #444;
  margin-bottom: 16px;
  word-wrap: break-word;
  overflow-wrap: break-word;
  overflow: hidden; /* Prevents overflowing */
  white-space: pre-wrap;
}
.source-sample {
  color: #666666;
  font-weight: normal;
}
.source-content {
  word-wrap: break-word;
  overflow-wrap: break-word;
  padding-left: 6px;
  overflow: hidden;
  max-width: 100%; /* Ensures it doesn't exceed parent container */
  padding-left: 6px;
  margin-right: 6px;
  white-space: normal; /* Override if necessary */
}
.source-meta {
  margin-left: 4px;
  margin-bottom: 10px;
  font-weight: 600;
  display: inline-flex;
  gap: 10px;
}
.source-link {
  color: #666666;
  font-weight: 500;
  /* color: teal; */
  color: #444;
}
.source-thumbnail {
  width: 100px;
  height: 60px;
  overflow: hidden;
}
.source-query-container {
  padding-bottom: 8px;
}
.source-query {
  font-size: 12px;
}
.source-sql-query {
  font-weight: bold;
}

/* Ensure parent containers are not causing overflow */
.source-item,
.sources-expansion-item {
  max-width: 100%;
  overflow: hidden;
}
</style>
