import type { QuestionData } from ".";

export interface ConversationInfo {
    id: string;
    name: string;
    timestamp: number;
    selected?: boolean; //Used for UI purposes when creating a new conversation
}

export interface Conversation extends ConversationInfo {
    auth_identifier: string;
    data: QuestionData[];
}
