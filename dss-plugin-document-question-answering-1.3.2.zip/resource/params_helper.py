
from typing import Any, Dict, List

import dataiku
from backend.utils.knowledge_filters import get_knowledge_bank_filtering_settings
from dataiku import Dataset


def get_knowledge_bank_single_choice(config: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    knowledge_bank_id: str = config.get("knowledge_bank_id")
    if knowledge_bank_id is not None:
        if knowledge_bank_id !=  "None" and knowledge_bank_id !=  "":
            filer_config: str = get_knowledge_bank_filtering_settings(
                knowledge_bank_id, False)
            choices: List[Dict[str, str]] = [{"value": meta, "label": meta} for 
                                             meta in filer_config['filter_columns']]
            choices.extend([{"value": "", "label": "None"}])
            return {"choices": choices}
    return {"choices": []}

def get_knowledge_bank_multiple_choices(config: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    knowledge_bank_id: str = config.get("knowledge_bank_id")
    if knowledge_bank_id is not None:
        if knowledge_bank_id !=  "None" and knowledge_bank_id !=  "":
            filer_config: str = get_knowledge_bank_filtering_settings(
                knowledge_bank_id, False)
            choices: List[Dict[str, str]] = [{"value": meta, "label": meta} for 
                                             meta in filer_config['filter_columns']]
            return {"choices": choices}
    return {"choices": []}

def get_dataset_list_and_proj_key()->List[Dict[str, Any]]:
    default_project_key = dataiku.default_project_key()
    client = dataiku.api_client()
    project = client.get_project(default_project_key)
    return project.list_datasets(), default_project_key

def list_sql_conns_in_current_projects() -> Dict[str, List[Dict[str, str]]]:
    datasets, default_project_key = get_dataset_list_and_proj_key()
    sql_connection_list: List[Dict[str, str]] = []
    for dataset_dict in datasets:
        connection_name: str = f"{dataset_dict['params'].get('connection')} ({dataset_dict.get('type')})"
        if connection_name not in [c["label"] for c  in sql_connection_list]:
            dataset = Dataset(project_key=default_project_key, name=dataset_dict["name"])
            ds_info = dataset.get_location_info()
            if ds_info.get("locationInfoType","") == 'SQL':
                val: str = dataset_dict['params'].get("connection")
                sql_connection_list.append({"value": val, "label": connection_name})
    return {"choices": sql_connection_list}

def list_datasets_from_conn(config: Dict[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    selected_conn: str = config.get("sql_retrieval_connection")
    datasets: List[Dict[str, str]]
    _ : str
    datasets, _ = get_dataset_list_and_proj_key()
    connection_datasets: List[str] = [d["name"] for d in datasets if d["params"].get("connection", "") == selected_conn]
    return {"choices": [{"value":dataset_name , "label":dataset_name} for dataset_name in connection_datasets]}


def get_possible_joins_columns(payload: Dict[str, Dict[str, Any]]) -> Dict[str, List[Dict[str, str]]]:
    _: List[Dict[str, str]]
    default_project_key: str
    _, default_project_key = get_dataset_list_and_proj_key()
    sql_retrieval_table_list: List[str] = payload["rootModel"].get("sql_retrieval_table_list", [])
    column_options: List[Dict[str, str]] = []
    for dataset_name in sql_retrieval_table_list:
        dataset = Dataset(project_key=default_project_key, name=dataset_name)
        column_options.extend(
            [{"value": f"{dataset_name}.{c['name']}", 
            "label": f"{dataset_name}.{c['name']}"} for c in dataset.read_schema()]
        )
    return {"choices": column_options}


def do(payload, config, plugin_config, inputs):
    parameter_name = payload["parameterName"]
    client = dataiku.api_client()
    current_project = client.get_default_project()

    if parameter_name == "llm_id":

        return {
            "choices": [
                {"value": llm.get("id"), "label": llm.get("friendlyName")} for llm in current_project.list_llms() if llm.get('type') != 'RETRIEVAL_AUGMENTED'
            ]
        }
    elif parameter_name == "knowledge_bank_id":
        return {
            "choices": [{"value": "", "label": "None"}] + [
                {"value": kb.get("id"), "label": kb.get("name")} for kb in current_project.list_knowledge_banks()
            ]
        }
    elif parameter_name == "knowledge_sources_filters":
        return get_knowledge_bank_multiple_choices(config)
    elif parameter_name == "knowledge_sources_displayed_metas":
        return get_knowledge_bank_multiple_choices(config)
    elif parameter_name == "knowledge_sources_context_metadata":
        return get_knowledge_bank_multiple_choices(config)
    elif parameter_name == "knowledge_source_url":
        return get_knowledge_bank_single_choice(config)
    elif parameter_name == "knowledge_source_title":
        return get_knowledge_bank_single_choice(config)
    elif parameter_name == "knowledge_source_thumbnail":
        return get_knowledge_bank_single_choice(config)
    elif parameter_name == "sql_retrieval_connection":
        return list_sql_conns_in_current_projects()
    elif parameter_name == "sql_retrieval_table_list":
        return list_datasets_from_conn(config)
    elif parameter_name == "sql_left_column" or "sql_right_column":
        return get_possible_joins_columns(payload)
    else:
        return {
            "choices": [
                {
                    "value": "wrong",
                    "label": f"Problem getting the name of the parameter.",
                }
            ]
        }