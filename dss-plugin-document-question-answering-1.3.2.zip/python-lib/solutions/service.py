import json
import re
import time
from typing import Any, Dict, List, Optional, Tuple, Union

from backend.db.base import CONVERSATION_DEFAULT_NAME
from backend.db.sql.sql_timing import log_query_time
from backend.models.base import LLM_STEP, RETRIEVAL_MODE, ConversationParams, LlmHistory, Source
from backend.utils.dataiku_api import dataiku_api
from backend.utils.knowledge_filters import get_current_filter_config, process_filters_for_db
from backend.utils.llm_utils import get_llm_capabilities, get_llm_completion
from backend.utils.parameter_helpers import load_knowledge_bank_parameters, load_role_and_guidelines_prompts
from backend.utils.picture_utils import b64encode_image_from_path
from backend.utils.rag_sources import map_rag_sources
from dataikuapi.utils import DataikuException
from langchain.chains import ConversationChain, LLMChain
from langchain.chains.conversational_retrieval.base import BaseConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.retrievers import EnsembleRetriever
from langchain.schema.document import Document
from langchain_core.prompt_values import PromptValue
from llm_assist.llm_api_handler import llm_setup
from llm_assist.llm_tooling.tools import SqlRetrieverTool, get_all_dataset_descriptions
from llm_assist.logging import logger
from solutions.chains.conversation_retrieval import DKUConversationRetrievalChain
from solutions.chains.conversation_title import ConversationTitleChainHandler
from solutions.chains.description_based_kb_agent import DescriptionBasedKBAgent
from solutions.chains.select_sql_agent import SelectSQLAgent
from solutions.chains.simple_kb_agent import SimpleKBAgent
from solutions.knowledge_bank import get_knowledge_bank_retriever
from solutions.prompts.citations import CITATIONS_PROMPT
from solutions.prompts.conversations import CONVERSATION_TITLE_PROMPT, CondensationChainHandler


def extract_json(response_text: str) -> Dict[str, Any]:
    # Find all characters that could be the start or end of a JSON object
    json_objects = re.findall(r"{.*?}", response_text)
    # Find the longest string that could be a JSON object,
    # since it's most likely to be the correct one
    longest_json = max(json_objects, key=len, default="{}")
    # Convert the string back to a dictionary (JSON object)
    try:
        json_data: Dict[str, Any] = json.loads(longest_json)
    except json.JSONDecodeError as e:
        logger.exception("Error parsing filters json")
        # In case JSON decoding fails, just return an empty dictionary
        json_data = {}

    return json_data


class LLM_Question_Answering:
    """LLM_Question_Answering: A class to facilitate the question-answering process using LLM model"""

    def __init__(self, memory_max_token_limit, llm):
        # Constructor parameters:
        self.project = dataiku_api.default_project
        self.memory_max_token_limit = (memory_max_token_limit,)
        self.llm = llm
        self.memory = ConversationBufferMemory(
            max_token_limit=memory_max_token_limit, input_key="input", return_messages=True
        )
        self.webapp_config = dataiku_api.webapp_config
        # Parameters:
        self.retrieval_mode = self.webapp_config.get("retrieval_mode")
        if self.retrieval_mode == "":
            raise Exception("retrieval_mode must be provided")
        self.sql_retrieval_table_name = self.webapp_config.get("sql_retrieval_table_name")
        # KB parmas ################
        self.all_knowledge_bank_parameters, self.per_knowledge_bank_parameters = load_knowledge_bank_parameters()
        self.knowledge_bank_ids = self.all_knowledge_bank_parameters["knowledge_bank_ids"]
        self.knowledge_bank_vector_db_types = self.all_knowledge_bank_parameters["knowledge_bank_vector_db_types"]
        self.knowledge_bank_weighs = self.all_knowledge_bank_parameters.get("knowledge_bank_weighs")
        self.filters_config = get_current_filter_config()
        ##############################
        if self.retrieval_mode == RETRIEVAL_MODE.KB.value and self.webapp_config.get("enable_smart_usage_of_kb", True):
            self.retrieval_query_agent = DescriptionBasedKBAgent()
        elif self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            self.retrieval_query_agent = SelectSQLAgent()
        else:
            self.retrieval_query_agent = SimpleKBAgent()
        # Chains and chain handlers:
        self.conversation_title_chain = ConversationTitleChainHandler(CONVERSATION_TITLE_PROMPT).get_chain(llm)
        self.condensation_chain_handler = CondensationChainHandler()

    def __update_memory(self, chat_history: List[LlmHistory]) -> None:
        self.memory.clear()
        for item in chat_history:
            inputs = {"input": item["input"]}
            outputs = {"output": item["output"]}

            logger.debug(f"The memory inputs {inputs}")
            logger.debug(f"The memory outputs {outputs}")

            self.memory.save_context(inputs, outputs)

    def __format_history(self, chat_history: List[LlmHistory]):
        return [(item["input"], item["output"]) for item in chat_history]

    def __verify_filters(self, filters: Dict[str, List[Any]]) -> Optional[Dict[str, List[Any]]]:
        if not filters or not self.filters_config:
            return None
        verified_columns = [col for col in filters.keys() if col in self.filters_config["filter_columns"]]
        verified_filters = {}
        for col in verified_columns:
            verified_values = [value for value in filters[col] if value in self.filters_config["filter_options"][col]]

            verified_filters[col] = verified_values

        return verified_filters

    def __get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any], List[str]],
        knowledge_bank_selection: List[str] = [],
        filters=None,
        sql_query: str = "",
        tables_used: List[str] = [],
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        llm_context: Dict[str, Any] = {}

        def handle_filters(filters):
            if filters is not None and isinstance(filters, dict):
                result = (
                    filters.get(knowledge_bank_selection[0], None) if filters and knowledge_bank_selection else None
                )
                return None if result == {} else result
            return filters

        filters = handle_filters(filters)
        if knowledge_bank_selection:
            llm_context["llm_kb_selection"] = knowledge_bank_selection

        if len(sql_query) > 0:
            llm_context["dataset_context"] = {
                "sql_retrieval_table_list": dataiku_api.webapp_config.get("sql_retrieval_table_list"),
                "tables_used": tables_used,
                "sql_query": sql_query.replace("\n", "").replace('\\"', '"'),
            }
        if user_profile:
            llm_context["user_profile"] = user_profile

        if isinstance(generated_answer, str):
            return {
                "answer": generated_answer,
                "sources": [],
                "filters": filters,
                "knowledge_bank_selection": knowledge_bank_selection,
            }

        if isinstance(generated_answer, dict):
            answer = generated_answer.get("answer", "")
            if self.retrieval_mode == RETRIEVAL_MODE.KB.value:
                source_documents: List[Document] = generated_answer.get("source_documents", [])
                sources = []
                for document in source_documents:
                    source_content = document.page_content
                    source_metadata = document.metadata

                    sources.append(dict(Source(excerpt=source_content, metadata=source_metadata)))

                sources = map_rag_sources(sources)
                return {"answer": answer, "sources": sources, "filters": filters, "llm_context": llm_context}
            if self.retrieval_mode == RETRIEVAL_MODE.DB.value:
                tables_used_str = ", ".join(tables_used) if isinstance(tables_used, list) else str(tables_used)

                # sample without answer key in it.
                sample = generated_answer.copy()
                sample.pop("answer", "")
                return {
                    "answer": answer,
                    "sources": [{"sample": sample, "metadata": {"source_title": tables_used_str}}],
                    "filters": filters,
                    "llm_context": llm_context,
                }
            else:
                return {"answer": answer, "sources": [], "filters": None, "llm_context": {}}
        return {}

    def get_ensemble_retriever(self, knowledge_bank_selection: List[str], filters={}):
        knowledge_bank_retrievers = []
        for knowledge_bank_id in knowledge_bank_selection:
            knowledge_bank_filter = filters[knowledge_bank_id]
            knowledge_bank_retriever = get_knowledge_bank_retriever(
                knowledge_bank_id,
                knowledge_bank_filter,
                self.all_knowledge_bank_parameters["retrieval_parameters"]["search_type"],
            )
            knowledge_bank_retrievers.append(knowledge_bank_retriever)
        if self.knowledge_bank_weighs:
            ensemble_retriever = EnsembleRetriever(
                retrievers=knowledge_bank_retrievers, weights=self.knowledge_bank_weighs
            )
        else:
            ensemble_retriever = EnsembleRetriever(retrievers=knowledge_bank_retrievers)  # type: ignore
        return ensemble_retriever

    def create_conversation_chain(self, act_like_prompt: str, system_prompt: str) -> ConversationChain:
        """
        Initializes a ConversationChain with a custom prompt template for generating detailed and friendly AI-human interactions.

        Parameters:
        - act_like_prompt (str): A descriptive string guiding the AI's behavior and language style.
        - system_prompt (str): A system prompt for the AI to follow.

        Returns:
        - ConversationChain: An instance configured with a tailored prompt template, leveraging the provided `act_like_prompt`.
        """
        template = r"""{act_like_prompt}
        
        {system_prompt}
                
        Current conversation:
        {{history}}

        Human: {{input}}
        Assistant:""".format(act_like_prompt=act_like_prompt, system_prompt=system_prompt)
        qa_prompt = PromptTemplate(input_variables=["history", "input"], template=template)

        chain = ConversationChain(llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)
        return chain

    def create_conversational_retrieval_chain(
        self, act_like_prompt: str, system_prompt: str, filters=None, knowledge_banks_to_use: list = []
    ) -> BaseConversationalRetrievalChain:
        enable_llm_citations = self.webapp_config.get("enable_llm_citations", False)
        context_prompt = CITATIONS_PROMPT if enable_llm_citations else "### CONTEXT"
        general_retrieval_template = r""" 
        {act_like_prompt}
        
        {system_prompt}

        {context_prompt}

        ----
        {{context}}
        ----
        
        Chat History:
        {{chat_history}}
        --- End of Current conversation ---
        Human: {{question}}
        Assistant:""".format(
            act_like_prompt=act_like_prompt, system_prompt=system_prompt, context_prompt=context_prompt
        )
        ##############################
        # if enable_llm_citations:
        #     question_prefix = ""
        #     question_suffix = " Answer by leveraging the relevant context sources, and if applicable, include citations following our policy: please inform us if the provided context sources do not allow for a complete answer."
        # else:
        #     question_prefix = ""
        #     question_suffix = ""
        # general_user_template =\
        #     question_prefix + "{question}" + question_suffix + "\nAssistant: "
        ###############################
        logger.debug("Building general_user_template")
        qa_prompt = PromptTemplate(input_variables=["history", "input"], template=general_retrieval_template)

        retriever_chain = self.get_ensemble_retriever(knowledge_banks_to_use, filters=filters)
        dku_chain = DKUConversationRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever_chain,
            return_source_documents=True,
            verbose=True,
            condense_question_llm=self.llm,
            chain_type="stuff",
            combine_docs_chain_kwargs={"prompt": qa_prompt},
        )

        return dku_chain

    def create_db_retrieval_chain(self, act_like_prompt: str, system_prompt: str) -> LLMChain:
        template = r"""{act_like_prompt}

        {system_prompt}

        Context: 
        ----
        {{context}}

        --- End of Context ---


        Current conversation:
        {{history}}
        --- End of Current conversation ---

        Human: {{input}}
        Assistant:""".format(act_like_prompt=act_like_prompt, system_prompt=system_prompt)
        qa_prompt = PromptTemplate(input_variables=["context", "history", "input"], template=template)
        chain = LLMChain(llm=self.llm, prompt=qa_prompt, memory=self.memory, verbose=True)
        return chain

    def create_db_retrieval_chain_on_but_not_used(self, act_like_prompt: str, system_prompt: str) -> LLMChain:
        dataset_descriptions = get_all_dataset_descriptions()
        template = r"""{act_like_prompt}

        {system_prompt}
        
        Be aware that you are part of a team that can retrieve information from external data sources. 
        The data source description is:
        {dataset_descriptions}
        However, your teammate decided not make any query for the following reason:
        {{justification}}
        You do not need to mention this unless you are asked directly about it.
        - Do not attempt to write any SQL
        --- End of justification ---


        Current conversation:
        {{history}}
        --- End of Current conversation ---

        Human: {{input}}
        Assistant:""".format(
            act_like_prompt=act_like_prompt, dataset_descriptions=dataset_descriptions, system_prompt=system_prompt
        )
        qa_prompt = PromptTemplate(input_variables=["justification", "history", "input"], template=template)
        chain = LLMChain(llm=self.llm, prompt=qa_prompt, memory=self.memory, verbose=True)
        return chain

    def prepare_qa_chain(
        self,
        knowledge_bank_selection: List[str],
        filters: Optional[Dict[str, List[Any]]] = None,
        retrieval_enabled: bool = False,
        use_db_retrieval: bool = False,
        **conversation_params,
    ):
        act_like_prompt, system_prompt = load_role_and_guidelines_prompts(
            retrieval_enabled=retrieval_enabled,
            knowledge_banks_to_use=knowledge_bank_selection,
            retrieval_mode=self.retrieval_mode,
            user_profile=conversation_params.get("user_profile", {}),
        )
        if retrieval_enabled and knowledge_bank_selection and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
            return self.create_conversational_retrieval_chain(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                filters=filters,
                knowledge_banks_to_use=knowledge_bank_selection,
            )
        if retrieval_enabled and use_db_retrieval and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            return self.create_db_retrieval_chain(act_like_prompt, system_prompt)
        if retrieval_enabled and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            # 1st LLM decided not use the query not we need make the second LLM aware of this
            return self.create_db_retrieval_chain_on_but_not_used(act_like_prompt, system_prompt)

        return self.create_conversation_chain(act_like_prompt=act_like_prompt, system_prompt=system_prompt)

    def compute_prompt_for_db_but_disabled(
        self, conv_chain: LLMChain, user_question: str, justification: str, chat_history: list
    ) -> PromptValue:
        inputs = conv_chain.prep_inputs(
            {"input": user_question, "history": self.memory, "justification": justification}
        )
        computed_prompt = conv_chain.prep_prompts(
            input_list=[{"input": user_question, "justification": justification, "history": inputs["history"]}]
        )

        logger.debug(computed_prompt)
        return computed_prompt[0][0]

    def compute_prompt_for_streaming(self, conv_chain: ConversationChain, user_question: str) -> PromptValue:
        """
        Generates a prompt for streaming by processing the user's question and conversation history.

        Steps:
        1. Prepares inputs from the user's question and history.
        2. Builds and returns the final prompt based on these inputs

        Parameters:
        - conv_chain (ConversationChain): Used for input preparation and prompt generation.
        - user_question (str): The user's current question.

        Returns:
        - PromptValue: The generated prompt for the given question.
        """
        inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(input_list=[{"input": user_question, "history": inputs["history"]}])
        return computed_prompt[0][0]

    def prep_db_question_context(self, records: List[Dict[str, List[Any]]], sql_query: str):
        columns = []
        if len(records) > 0:
            columns = [{"name": r, "label": r, "field": r, "align": "left"} for r in records[0].keys()]
        question_context = {"rows": records, "columns": columns, "query": sql_query}
        return question_context

    def exception_correction_loop(
        self,  # noqa: PLR0917 too many positional arguments
        db_query: dict,
        justification: str,
        user_question: str,
        attempt: int,
        chat_history: list,
        max_attempts: int = 3,
    ):
        sql_query = ""
        tables_used: List = []
        records: Union[List[List[Dict[str, str]]], List[Dict[str, List[Any]]]] = []
        sql_tool = SqlRetrieverTool()  # type: ignore
        logger.debug(f"Correction attempt no. {attempt}")
        if attempt >= max_attempts or db_query is None:
            logger.error(f"Unable to read from SQL table after maximum retries")
            context = f"""
            Error while reading from SQL table after {max_attempts} attempts
            {self.retrieval_query_agent.previous_sql_errors}
            The SQL table description is:
            {get_all_dataset_descriptions()}
            The following attempts were made:
            {self.retrieval_query_agent.formatted_errors}
            """
            return context, sql_query, records, tables_used
        failed_response = {**db_query, "justification": justification}
        db_query, justification = self.retrieval_query_agent.get_retrieval_query(
            self.llm, chat_history, user_question, failed_response=failed_response
        )
        try:
            context, sql_query, records, tables_used = sql_tool._run(db_query)
            return context, sql_query, records, tables_used
        except Exception as e:
            logger.error(f"Unable to read from SQL table on first attempt {e}")
            context = f"Error when reading from SQL table {e}."
            if db_query is not None:
                failed_response = {**db_query, "justification": justification}
                self.retrieval_query_agent.previous_sql_errors.append(
                    {"response": failed_response, "query": sql_query, "error": e}
                )
                attempt += 1
                return self.exception_correction_loop(
                    db_query=db_query,
                    justification=justification,
                    user_question=user_question,
                    chat_history=chat_history,
                    attempt=attempt,
                )
            return context, sql_query, records, tables_used

    def compute_prompt_for_db(
        self, conv_chain: LLMChain, user_question: str, db_query: dict, justification: str, chat_history: list
    ) -> Tuple[PromptValue, str, Dict[Any, Any], List]:
        sql_query = ""
        records = []  # type: ignore
        question_context = {}
        self.retrieval_query_agent.previous_sql_errors = []
        logger.debug(f"Running DB retrieval.")
        sql_tool = SqlRetrieverTool()  # type: ignore

        try:
            context, sql_query, records, tables_used = sql_tool._run(db_query)
        except Exception as e:
            logger.error(f"Unable to read from SQL table on first attempt {e}")
            context = f"Error when reading from SQL table {e}."
            logger.debug("Entering exception correction loop")
            failed_response = {**db_query, "justification": justification}
            self.retrieval_query_agent.previous_sql_errors.append(
                {"response": failed_response, "query": sql_query, "error": e}
            )
            context, sql_query, records, tables_used = self.exception_correction_loop(
                db_query=db_query,
                justification=justification,
                user_question=user_question,
                chat_history=chat_history,
                attempt=0,
            )
        finally:
            logger.debug(f"Query creation completed. Context: {context}")
            inputs = conv_chain.prep_inputs({"input": user_question, "history": self.memory, "context": context})
            computed_prompt = conv_chain.prep_prompts(
                input_list=[{"input": user_question, "context": context, "history": inputs["history"]}]
            )
            logger.debug(computed_prompt)
            question_context = self.prep_db_question_context(records, sql_query)  # type: ignore
        return computed_prompt[0][0], sql_query, question_context, tables_used

    def auto_filters(
        self, user_query: str, possible_filters: Dict[str, List[str]]
    ) -> Union[Dict[str, List[str]], None]:
        """Analyzes the user query and identifies the relevant filters and their values.
        Args:
            user_query (str): The user query.
            possible_filters (List[str]): A dictionary containing the possible filters and their values.

        Returns:
            Dict[str, List[str]]: A dictionary containing the relevant filters and their values.
        """
        logger.debug(f"Auto Filtering On")

        prompt = (
            f"Examine the user query: {user_query}. "
            f"Identify which of the following possible filter values are relevant: "
            "# POSSIBLE FILTERS: "
            f"{possible_filters}. "
            "# INSTRUCTIONS "
            "1 - Return only a JSON object of the relevant filters directly, with no additional explanations, text decorations, "
            "or markdown. Ensure the JSON object is in a format that can be parsed directly by a JSON parser without needing "
            "any preprocessing. "
            "2- If no filters apply or if you are not sure about the relevant filters, return an empty JSON object: {}. "
            "3- Remember to strictly return the relevant filters JSON object with no additional text or markdown. "
            "### EXAMPLES: "
            "- Example 1: "
            "user query: What are the revenues for Q1 2023 and Q2 in 2023? "
            'possible filters: {"file":["2023 Q2.pdf", "2023 Q1.pdf","2024 Q2.pdf"]} '
            'Expected Answer is: {"file":["2023 Q2.pdf", "2023 Q1.pdf"]}. '
            "- Example 2: "
            "user query: How many vacation days do we have in California. "
            'possible filters: {"location":["California", "New York", "Texas", "Paris"], "tags": ["source","name","url"], "date": ["2022","2023","2024"]} '
            'Expected Answer is: {"location":["California"]}. '
            "- Example 3: "
            "user query: What are the sales for the 2023 last quarter for Microsoft and Samsung? "
            'possible filters: {"company":["Apple", "Microsoft", "Samsung"], "quarter": ["Q1","Q2","Q3","Q4"], "year": ["2022","2023","2024"]} '
            'Expected Answer is: {"company":["Microsoft", "Samsung"], "quarter": ["Q4"], "year": ["2023"]}. '
            "- Example 4: "
            "user query: How many employees are in the marketing department? "
            'possible filters: {"location": ["Paris", "New York", "London"]} '
            "Expected Answer is: {}. "
        )

        logger.debug(f"Auto filters prompt: {prompt}")
        llm_response = get_llm_completion().with_message(prompt).execute()
        response = None
        # TODO fixme: response can stay None and will fail in the try .. except
        if llm_response.success:
            response = llm_response.text
        else:
            logger.error(f"Auto filter completion call failed: {llm_response._raw}")
        logger.debug(f"Auto filters llm response: '{response}'")
        try:
            if not response:
                raise AttributeError

            if isinstance(response, dict):
                relevant_filters = response
            else:
                relevant_filters = extract_json(response)

            logger.debug(f"Extracted filters  {relevant_filters}")
            validated_filters = self.__verify_filters(relevant_filters)

            return validated_filters
        except Exception as e:
            logger.error(f"Failed to parse LLM response for query '{user_query}'. Exception: {e}", exc_info=True)
            return {}

    def create_kb_filters(self, filters, query):
        # TODO: Adapt when several knowledge banks will be connected
        vector_db_type = self.knowledge_bank_vector_db_types[0]
        if vector_db_type and filters and len(filters) > 0:
            verified_filters = process_filters_for_db(  # TODO: Adapt when several knowledge banks will be connected
                self.__verify_filters(filters=filters), vector_db_type
            )
            logger.debug(f"vector_db_type:{vector_db_type}   / filters: {filters}")
            # TODO: Adapt when several knowledge banks will be connected
            return {self.knowledge_bank_ids[0]: verified_filters}
        else:
            if (
                (filters is None or len(filters) == 0)
                and self.filters_config
                and self.webapp_config.get("knowledge_enable_auto_filtering", False)
            ):
                computed_filters = self.auto_filters(query, self.filters_config["filter_options"])
                return {
                    self.knowledge_bank_ids[0]: process_filters_for_db(
                        filters=computed_filters, vector_db_type=vector_db_type
                    )
                }
            else:
                # TODO: Adapt when several knowledge banks will be connected
                return {self.knowledge_bank_ids[0]: {}}

    def create_retrieval_query_from_history(
        self, chat_history: List[LlmHistory], query: str, conversation_params: ConversationParams
    ):
        chat_history_str = None
        condensation_chain_handler = CondensationChainHandler()
        chat_history_str = condensation_chain_handler.format_chat_history_for_condensation(chat_history=chat_history)
        if self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            self.retrieval_query_agent.get_retrieval_graph(
                llm=self.llm, chat_history=chat_history_str, user_input=query
            )
        retrieval_query, justification = self.retrieval_query_agent.get_retrieval_query(
            llm=self.llm, chat_history=chat_history_str, user_input=query
        )
        conversation_params["justification"] = justification
        if self.retrieval_mode == RETRIEVAL_MODE.KB.value:
            conversation_params["kb_query"] = retrieval_query
            logger.debug(
                f"get_retrieval_query for kb_query performed with: [{query}], computed kb_query is [{conversation_params['kb_query']}]"
            )

            conversation_params["knowledge_bank_selection"] = (
                [] if conversation_params["kb_query"] is None else self.knowledge_bank_ids
            )

            if conversation_params["knowledge_bank_selection"] == []:
                logger.warn("No knowledge bank has been selected but knowledge bank is enabled.")
            logger.debug(f"knowledge_bank_selection: {conversation_params['knowledge_bank_selection']}")
            logger.debug(f"retrieval_enabled: {conversation_params['retrieval_enabled']}")
            return conversation_params

        elif self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            conversation_params["db_query"] = retrieval_query
            logger.debug(
                f"get_retrieval_query performed for db_query with: [{query}], computed db_query is [{conversation_params['db_query']}]"
            )

            conversation_params["use_db_retrieval"] = False if conversation_params["db_query"] is None else True
            if conversation_params["use_db_retrieval"] == []:
                logger.warn("No database query has been selected but db_query is enabled.")
            logger.debug(f"use_db_retrieval: {conversation_params['use_db_retrieval']}")
            return conversation_params
        else:
            raise Exception(
                f"Expect retrieval_mode to be either 'kb' or 'db' in order to build query. Got {self.retrieval_mode }"
            )

    def get_answer_and_sources(  # noqa: PLR0917 too many positional arguments
        self,
        query: str,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        file_path: Optional[str] = None,
        retrieval_enabled: bool = False,
        user_profile: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Extracts the answer and its corresponding sources for a given prompt.

        Args:
            query (str): The user query.
            query_index: int: The index of the query within the conversation.
            chat_history (List[LlmHistory]): A list of prior interactions (optional). Each interaction
                is a dictionary with the question and response.
            filters (Optional[Dict[str, List[Any]]]): A dictionary of filters to apply to the knowledge bank.
            file_path (str): The file path uploaded into a managed folder


        Returns:
            Dict[str, Union[str, Dict[str, Any]]]: A dictionary containing:
                - 'answer' (str): The generated answer to the prompt.
                - 'sources' (List[Dict]): A list of dict:
                    - 'excerpt' (str): The content of the source.
                    - 'metadata' (Dict[str, str]): Additional metadata about the source.
        """

        logger.debug("Time ===>: starting tracking time: Generating response")
        conversation_params: ConversationParams = {
            "user_query": query,
            "chat_history": chat_history,
            "file_path": file_path,
            "retrieval_enabled": retrieval_enabled,
            "knowledge_bank_selection": [],
            "use_db_retrieval": False,
            "global_start_time": time.time(),  # Capture start time
            "justification": "",
            "user_profile": user_profile,
        }

        logger.debug(f"retrieval_mode is set to : {self.retrieval_mode}")
        # filters
        if retrieval_enabled and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
            conversation_params["filters"] = self.create_kb_filters(filters, query)
        else:
            conversation_params["filters"] = {}
        # retrieval query
        if retrieval_enabled and self.retrieval_mode != RETRIEVAL_MODE.NO_RETRIEVER.value:
            conversation_params = self.create_retrieval_query_from_history(chat_history, query, conversation_params)

        response = None
        self.__update_memory(chat_history=conversation_params["chat_history"])

        response = self.run_completion_query(conversation_params)
        return response

    def create_computed_prompt(  # noqa: PLR0917 too many positional arguments
        self,
        qa_chain,
        knowledge_bank_selection: List[str],
        kb_query: Union[str, None] = None,
        user_query: str = "",
        chat_history: List[LlmHistory] = [],
        retrieval_enabled: bool = False,
        use_db_retrieval: bool = False,
        db_query: dict = {},
        justification: str = "",
        **conversation_params,
    ):
        start_time = time.time()
        question_context = {}
        computed_prompt = None
        sql_query = ""
        tables_used: List = []

        if retrieval_enabled and knowledge_bank_selection and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
            enable_llm_citations = self.webapp_config.get("enable_llm_citations", False)
            computed_prompt, question_context = qa_chain.prepare_final_answer_prompt(
                condensed_query=user_query,
                kb_query=kb_query,
                inputs={"question": user_query, "chat_history": self.__format_history(chat_history)},
                enable_llm_citations=enable_llm_citations,
            )
            logger.debug(f"question_context: {question_context}")
            logger.debug(f"Time ===> taken by Computing prompt for retrieval: {(time.time() - start_time):.2f} secs")
        elif retrieval_enabled and use_db_retrieval and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            computed_prompt, sql_query, question_context, tables_used = self.compute_prompt_for_db(
                conv_chain=qa_chain,
                user_question=user_query,
                db_query=db_query,
                justification=justification,
                chat_history=self.__format_history(chat_history),
            )  # type: ignore
            logger.debug(f"Time ===> taken by Computing prompt for retrieval: {(time.time() - start_time):.2f} secs")

        elif retrieval_enabled and self.retrieval_mode == RETRIEVAL_MODE.DB.value and not use_db_retrieval:
            computed_prompt = self.compute_prompt_for_db_but_disabled(
                conv_chain=qa_chain,
                user_question=user_query,
                justification=justification,
                chat_history=self.__format_history(chat_history),
            )  # type: ignore
            logger.debug(
                f"Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs"
            )
        else:
            computed_prompt = self.compute_prompt_for_streaming(conv_chain=qa_chain, user_question=user_query)
            logger.debug(
                f"Time ===> taken by Computing prompt for conversational: {(time.time() - start_time):.2f} secs"
            )
        logger.debug(f"Final prompt:  {computed_prompt.to_string() if computed_prompt else 'No prompt'}")
        return computed_prompt, question_context, sql_query, tables_used

    def create_completion_query(self, computed_prompt: PromptValue, file_path: Optional[str]):
        completion = get_llm_completion()
        if file_path:
            try:
                img_b64 = b64encode_image_from_path(file_path)
                completion.cq["messages"].append(
                    {
                        "role": "user",
                        "parts": [
                            {"type": "TEXT", "text": computed_prompt.to_string()},
                            {"type": "IMAGE_INLINE", "inlineImage": img_b64},
                        ],
                    }
                )
            except DataikuException as e:
                logger.error(f"Dataiku API Error: {e}")
            except FileNotFoundError:
                logger.error("File not found in the managed folder.")
            except IOError as e:
                logger.error(f"I/O Error: {e}")
            except Exception as e:
                logger.error(f"An unexpected error occurred: {e}")
        else:
            completion.cq["messages"].append(
                {
                    "role": "user",
                    "parts": [
                        {"type": "TEXT", "text": computed_prompt.to_string()},
                    ],
                }
            )
        return completion

    def run_completion_query(self, conversation_params: ConversationParams):
        retrieval_enabled = conversation_params["retrieval_enabled"]
        knowledge_bank_selection = conversation_params["knowledge_bank_selection"]
        use_db_retrieval = conversation_params["use_db_retrieval"]
        user_profile = conversation_params.get("user_profile", None)
        qa_chain = self.prepare_qa_chain(**conversation_params)
        sql_query = ""
        question_context = {}

        if retrieval_enabled and knowledge_bank_selection and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
            yield {"step": LLM_STEP.COMPUTING_PROMPT_WITH_KB}
        elif retrieval_enabled and use_db_retrieval and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
            yield {"step": LLM_STEP.COMPUTING_PROMPT_WITH_DB}
        else:
            yield {"step": LLM_STEP.COMPUTING_PROMPT_WITHOUT_RETRIEVAL}

        # Fixme: qa_chain also in conversation_params. To change to prevent errors
        computed_prompt, question_context, sql_query, tables_used = self.create_computed_prompt(
            qa_chain, **conversation_params
        )  # type: ignore

        completion = self.create_completion_query(computed_prompt, conversation_params["file_path"])
        llm_capabilities = get_llm_capabilities()
        global_start_time = conversation_params["global_start_time"]
        filters = conversation_params["filters"]
        start_time = time.time()
        log_time = True
        if llm_capabilities["streaming"]:
            yield {"step": LLM_STEP.STREAMING_START}
            for chunk in completion.execute_streamed():
                yield chunk
                if log_time:
                    logger.info(f"Time ===> taken by getting first chunk: {(time.time() - start_time):.2f} secs")
                    if global_start_time:
                        logger.debug(
                            f"Time ===> GLOBAL taken by getting first chunk: {(time.time() - global_start_time):.2f} secs"
                        )
                    log_time = False
            yield {"step": LLM_STEP.STREAMING_END}
            if retrieval_enabled and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
                # Send sources and filters at the end of the streaming
                yield self.__get_as_json(
                    question_context,
                    knowledge_bank_selection=knowledge_bank_selection,
                    filters=filters,
                    user_profile=user_profile,
                )

            if retrieval_enabled and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
                logger.debug("SQL context sent")
                yield self.__get_as_json(
                    question_context, sql_query=sql_query, tables_used=tables_used, user_profile=user_profile
                )

        else:
            response = ""
            resp = None
            if retrieval_enabled and knowledge_bank_selection and self.retrieval_mode == RETRIEVAL_MODE.KB.value:
                step = LLM_STEP.QUERING_LLM_WITH_KB
            elif retrieval_enabled and use_db_retrieval and self.retrieval_mode == RETRIEVAL_MODE.DB.value:
                step = LLM_STEP.QUERING_LLM_WITH_DB
            else:
                step = LLM_STEP.QUERING_LLM_WITHOUT_RETRIEVAL
            logger.debug({"step": step})
            yield {"step": step}
            resp = completion.execute()
            if resp and resp.success:
                response = resp.text
            else:
                logger.error(f"Multimodal completion call failed: ${resp._raw if resp else 'No response'}")
                response = resp._raw if resp else None
            question_context["answer"] = response
            yield self.__get_as_json(
                question_context,
                knowledge_bank_selection=knowledge_bank_selection,
                filters=filters,
                sql_query=sql_query,
            )

    @log_query_time
    def get_conversation_title(self, query: str, answer: str, user_profile: Optional[Dict[str, Any]] = None) -> str:
        result = self.conversation_title_chain.run(query=query, answer=answer, user_profile=user_profile)
        json_answer: str = self.__get_as_json(result, user_profile=user_profile).get(
            "answer", CONVERSATION_DEFAULT_NAME
        )
        return json_answer


memory_max_token_limit = int(dataiku_api.webapp_config.get("memory_token_limit", 2000))

llm_qa = LLM_Question_Answering(memory_max_token_limit, llm_setup.get_llm())
