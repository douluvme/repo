def join_documents_as_plain_text(retriever_documents):
    return "".join([document.page_content for document in retriever_documents])