from solutions.prompts.sql_generation.conversation_examples import EXAMPLE_LIST
from solutions.prompts.sql_generation.loading import (
    load_empty_json_string,
    load_json_query_structure_explanations,
    structure_examples,
)

# JSON SQL query data model
JSON_SQL_FORBIDDEN_KEYS = ["type", "with", "distinct", "from", "join", "having", "comment", "alias"]

JSON_SQL_KEY_EXPLANATIONS = {
    "type": "Specifies the type of the SQL statement.\n",
    "with": "A list for Common Table Expressions (CTEs).\n",
    "distinct": "A boolean indicating whether the SELECT statement is distinct.\n",
    "selectList": "A list of columns or expressions to be selected. Each item in the list includes:\n"
    "    - expr: An expression object that specifies the type and details of the expression, such as columns or operators.\n"
    "    - alias: An optional alias for the expression.\n",
    "from": "Describes the source table for the query, including:\n"
    "    - 'type': The type of table.\n"
    "    - 'name': The name of the table.\n"
    "    - 'catalog': Catalog of the table.\n"
    "    - 'schema': Schema of the table.\n"
    "    - 'alias': An optional alias for the table.\n",
    "join": "A list of join clauses.\n",
    "where": "A list of conditions for the WHERE clause. Each condition includes:\n"
    "    - 'type': Usually 'OPERATOR'.\n"
    "    - 'op': The operator (Example: 'EQ', 'LT', 'AND')\n"
    "    - 'args': The arguments for the operator, typically columns and constants.\n",
    "having": "A list of conditions for the HAVING clause.\n",
    "groupBy": "A list of columns or expressions for the GROUP BY clause. Each item includes:\n"
    "    - 'expr': An expression object specifying the column.\n",
    "orderBy": "A list of columns or expressions for the ORDER BY clause. Each item includes:\n"
    "    - 'expr': An expression object specifying the column.\n"
    "    - 'orderType': The order direction, either 'ASC' or 'DESC'.\n",
    "limit": "Specifies the LIMIT clause.\n",
    "comment": "An optional comment.\n",
    "alias": "An optional alias for the entire query.\n",
}

JSON_SQL_KEY_TYPES = {
    "type": "[STRING]",
    "with": "[ARRAY]",
    "distinct": "[BOOLEAN]",
    "selectList": "[ARRAY]",
    "from": "[ARRAY]",
    "join": "[ARRAY]",
    "where": "[ARRAY]",
    "having": "[ARRAY]",
    "groupBy": "[ARRAY]",
    "orderBy": "[ARRAY]",
    "limit": "[INT]",
    "comment": "[STRING]",
    "alias": "[STRING]",
}


COLUMN_VALUE_FORMAT = """### column
{{"type": "COLUMN", "name": <NAME_OF_COLUMN>}}
### value
{{"type": "CONSTANT", "value": <VALUE>}}
### list
{{"type": "LIST", "items": [{{"type": "CONSTANT", "value": <VALUE1>}},
    {{"type": "CONSTANT", "value": <VALUE2>}}]}}
"""
GRP_FORMAT = """### "groupBy" and "orderBy" both use "expr" as key and a column as a value
for example 
"groupBy" : [{{"expr": {{"type": "COLUMN", "name": <NAME_OF_COLUMN>}}}}]
"orderBy" : [{{"expr": {{"type": "COLUMN", "name": <NAME_OF_COLUMN>}}}}]
"orderBy" has the optional key "orderType" which can be "ASC", "DESC"

"""

JUSTIFICATION_FORMAT = """
If no query is needed, all other keys should be null and 'justification' should explain why no query is necessary.
{{
    "selectList": null,
    "where":null,
    "groupBy":null,
    "orderBy":null,
    "limit": null,
    "justification": <YOUR JUSTIFICATION>
}}"""

OPERATOR_EXPRESSION_FORMAT = """The operator expressions take 3 keys: 'type', 'op' and 'args', where:
- 'type' [STRING]: Has the value 'OPERATOR'.
- 'op': [STRING] Is the type of operator to use in the query.
- 'args'[ARRAY]: Is a list containing the expressions of the operator.

The available operators are as follows:
- String operators:
    - UPPER
    - LOWER
    - CONCAT
    - CONTAINS
    - STARTS_WITH
    - LENGTH
    - TRIM
    - CONCAT
    - CONTAINS
    - STARTS_WITH
    - COALESCE
    - REPLACE
- Numerical operators:
    - AVG
    - MEDIAN
    - MIN
    - MAX
    - SUM
    - PLUS
    - MINUS
    - TIMES
    - DIV
    - MOD
    - POW
    - STDDEV_SAMP
    - STDDEV_POP
    - ABS
    - FLOOR
    - CEIL
    - ROUND
    - SQRT
    - EXP
    - LN
    - LOG
- Boolean operators:
    - EQ (equals)
    - NE (not equal)
    - GT (greater than)
    - LT (less than)
    - GE (greater than or equal)
    - LE (less than or equal)
    - LIKE (SQL LIKE operator)
    - AND (logical AND)
    - OR (logical OR)
    - NOT (logical NOT)
    - ISNULL (is null)
    - ISNOTNULL (is not null)

- Date operators:
    - DATETRUNC, with the parameters:
        - YEAR
        - QUARTER
        - MONTH
        - WEEK
        - DAY
        - HOUR
        - MINUTE
        - SECOND
    Beware of the argument order: DATETRUNC(COLUMN, CONSTANT)
    DATETRUNC('WEEK',"timestamp") is represented as
    {{"expr": {{"type": "OPERATOR",
    "op": "DATETRUNC",
    "args": [{{"type": "COLUMN", "name": "timestamp"}},
    {{"type": "CONSTANT", "value": "week"}}]}}
    - DATEPART, with the parameters:
        - YEAR
        - QUARTER_OF_YEAR
        - MONTH_OF_YEAR
        - WEEK_OF_YEAR
        - DAY_OF_MONTH
        - DAY_OF_WEEK
        - HOUR_OF_DAY
        - MINUTE_OF_HOUR
        - SECOND_OF_MINUTE
        - MILLISECOND_OF_SECOND
        - SECOND_FROM_EPOCH
        - MILLIS_FROM_EPOCH

    Beware of the argument order: DATEPART(COLUMN, CONSTANT)
    EXTRACT(YEAR FROM ("timestamp")) is represented as
    DATEPART
    {{"expr": {{"type": "OPERATOR",
    "op": "DATEPART",
    "args": [{{"type": "COLUMN", "name": "timestamp"}},
    {{"type": "CONSTANT", "value": "year"}}]}}
    - DATEDIFF, with the parameters:
        - YEAR
        - MONTH
        - WEEK
        - DAY
        - HOUR
        - MINUTE
        - SECOND
    Beware of the argument order: DATEDIFF(COLUMN, COLUMN, COLUMN)
    DATEDIFF(YEAR, "timestamp1", "timestamp2")
    {{"expr": {{"type": "OPERATOR",
    "op": "DATEDIFF",
    "args": [{{"type": "COLUMN", "name": "timestamp1"}},
    {{"type": "COLUMN", "name": "timestamp2"}},
    {{"type": "COLUMN", "value": "year"}}]}}
- Other operators: 
    - COUNT
    - DISTINCT
    - FIRST_VALUE
    - LAST_VALUE
For example DISTINCT can be made in the following way
{{"type": "OPERATOR","op": "DISTINCT", "args": [{{"type": "COLUMN", "name": <NAME_OF_COLUMN>}}]}}

- IN operator
IN expressions take a list of values
For example, the WHERE condition
WHERE "user_id" IN ('user1','user3') 
should be defined as
[{{"type": "OPERATOR",
    "op": "IN",
    "args": [{{"type": "COLUMN", "name": "user_id"}},
    {{"type": "LIST",
        "items": [{{"type": "CONSTANT", "value": "user1"}},
        {{"type": "CONSTANT", "value": "user3"}}]}}]}}]
        
## CASE 
Case expressions takes 2 keys "items" and "elseValue"
- "items": an array of WhenItem
- "elseValue": a value expression
WhenItem take 2 keys "when" and "then"
- "when": an operator expression which evaluates to a boolean
- "then": a value expression
SELECT CASE 
    WHEN "call_length" > 20.0 THEN 'long'
    WHEN "call_length" > 10.0 THEN 'medium'
    ELSE 'small'
END AS "call_bins"
would be expressed as:
[{{"expr": {{"type": "CASE",
    "items": [{{"when": {{"type": "OPERATOR",
        "op": "GT",
        "args": [{{"type": "COLUMN", "name": "call_length_seconds"}},
        {{"type": "CONSTANT", "value": 20}}]}},
        "then": {{"type": "CONSTANT", "value": "large"}},
        {{"when": {{"type": "OPERATOR",
        "op": "GT",
        "args": [{{"type": "COLUMN", "name": "call_length_seconds"}},
        {{"type": "CONSTANT", "value": 10}}]}},
        "then": {{"type": "CONSTANT", "value": "medium"}}],
    "elseValue": {{"type": "CONSTANT", "value": "small"}},
    "alias": "call_bins"}}]
        
        
## alias
"alias" is optional key that can be added to an "expr"
When aggregates it is important create aliases so that is clear what the table shows.
here we add "average_speed_by_user" instead of "avg"
[{{"expr": {{"type": "COLUMN", "name": "user_id"}}, "alias": "user"}},
    {{"expr": {{"type": "OPERATOR",
    "op": "AVG",
    "args": [{{"type": "COLUMN", "name": "speed_in_seconds"}}]}}, "alias": "average_speed_by_user"}}]

## limit
int or null

## In line expression policy
In line expressions such as INTERVAL, CURRENT_DATE, CURRENT_TIME, CURRENT_TIMESTAMP, NOW() can be made using "INLINE_EXPRESSION" which takes 2 keys 
- "type": "INLINE_EXPRESSION"
- "expr": string: the inline expression 
for example:
{{"expr": {{"type": "INLINE_EXPRESSION", 'expr': "NOW() - INTERVAL '5 MINUTES'"}}}}
This expression works because no columns are referenced in the expression. If we want to refer to columns we should do so using the column policy.      
        
"""


STRUCTURED_EXAMPLES = structure_examples(EXAMPLE_LIST, JSON_SQL_FORBIDDEN_KEYS)
JSON_QUERY_STRUCTURE_EXPLANATIONS = load_json_query_structure_explanations(JSON_SQL_KEY_EXPLANATIONS, JSON_SQL_FORBIDDEN_KEYS, JSON_SQL_KEY_TYPES)
EMPTY_JSON_STRING = load_empty_json_string(JSON_SQL_KEY_EXPLANATIONS, JSON_SQL_FORBIDDEN_KEYS)
