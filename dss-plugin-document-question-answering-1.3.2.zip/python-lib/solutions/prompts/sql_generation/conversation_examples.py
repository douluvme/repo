
TITANIC_DATASOURCE_NAME = "titanic_data_prepared"
TITANIC_DATASOURCE_DESCRIPTION = f"""## SQL Table Description and Schema
Name: {TITANIC_DATASOURCE_NAME}
SQL Database type: postgreSQL
Datasource Description: This datasource is a historical dataset that contains information about the passengers who were on board the Titanic, which tragically sank on its maiden voyage after hitting an iceberg.

### Titanic datasource columns description
- Name: 'passenger_id' | Type: 'string' | Description: 'This is the unique identifier of a passenger.'
- Name: 'survived' | Type: 'string' | Description: 'This column informs whether the passenger survived the disaster or not.
A value of '1' means that the passenger survived. 
A value of '0' means that the passenger did not survive.'
- Name: 'title' | Type: 'string' | Description: 'The title of the passenger: the available titles are 'Mr', 'Miss', 'Mrs', 'Master' and 'Special'.'
- Name: 'sex' | Type: 'string' | Description: 'The gender of the passenger: 'male' or 'female'.'
- Name: 'age' | Type: 'double' | Description: 'The passenger's age during the disaster.'
- Name: 'family_size' | Type: 'bigint' | Description: 'The passenger's family size during the disaster.'
- Name: 'ticket_class' | Type: 'string' | Description: 'The passenger's class. The available classes are: 
- '1': The first class.
- '2': The second class.
- '3': The third class.'
- Name: 'fare' | Type: 'double' | Description: 'The amount of money a passenger paid for their ticket to travel'
- Name: 'cabin' | Type: 'string' | Description: 'The cabin number assigned to the passenger.'
- Name: 'port_of_embarkation' | Type: 'string' | Description: 'The port where the passenger boarded'
## -- End of Description --
"""

TITANIC_DATASOURCE_RAW_CONVERSATION = [
    {"Human": "How many passengers were on the boat ?",
     "Assistant": {
         'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'OPERATOR',
            'op': 'COUNT',
            'args': [{'type': 'COLUMN', 'name': '*'}]},
        'alias': 'nb_records'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [],
        'orderBy': [],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers. This requires searching for information in the SQL table.'
        }},
    {"Human": "What is the capital of France?",
     "Assistant": {
         'type': None,
        'with': None,
        'distinct': None,
        'selectList': None,
        'from': None,
        'join': None,
        'where': None,
        'having': None,
        'groupBy': None,
        'orderBy': None,
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is to know the capital of France. As it does not relates to the available datasource, this does not requires searching for information in the SQL table.'
        }},
    {"Human": "Hello!",
     "Assistant": {
         'type': None,
        'with': None,
        'distinct': None,
        'selectList': None,
        'from': None,
        'join': None,
        'where': None,
        'having': None,
        'groupBy': None,
        'orderBy': None,
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': "The user's input is a statement and does not require further information."
        }},
    {"Human": "What was the average age of the passengers that survived ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'OPERATOR',
            'op': 'AVG',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'average_age'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [{'type': 'OPERATOR',
        'op': 'EQ',
        'args': [{'type': 'COLUMN', 'name': 'survived'},
            {'type': 'CONSTANT', 'value': '1'}]}],
        'having': [],
        'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'survived'}}],
        'orderBy': [],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers, their age and their survival. This requires searching for information in the SQL table.'
        }},
    {"Human": "What was the average age of the passengers having the sex 'female' that survived ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'sex'}},
        {'expr': {'type': 'COLUMN', 'name': 'survived'}},
        {'expr': {'type': 'OPERATOR',
            'op': 'AVG',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'average_age'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [{'type': 'OPERATOR',
        'op': 'AND',
        'args': [{'type': 'OPERATOR',
            'op': 'EQ',
            'args': [{'type': 'COLUMN', 'name': 'survived'},
            {'type': 'CONSTANT', 'value': '1'}]},
            {'type': 'OPERATOR',
            'op': 'EQ',
            'args': [{'type': 'OPERATOR',
            'op': 'UPPER',
            'args': [{'type': 'COLUMN', 'name': 'sex'}]},
            {'type': 'CONSTANT', 'value': 'FEMALE'}]}]}],
        'having': [],
        'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'sex'}},
        {'expr': {'type': 'COLUMN', 'name': 'survived'}}],
        'orderBy': [],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers, their age, their sex and their survival. This requires searching for information in the SQL table.'
        }},
    {"Human": "Thank you",
     "Assistant": {
         'type': None,
        'with': None,
        'distinct': None,
        'selectList': None,
        'from': None,
        'join': None,
        'where': None,
        'having': None,
        'groupBy': None,
        'orderBy': None,
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': "The user's is thanking for the help given: this does not require further information."
        }},
    {"Human": "Compare the survival rate of the 'male' passengers with the 'female' passengers",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'sex'}},
        {'expr': {'type': 'OPERATOR',
            'op': 'COUNT',
            'args': [{'type': 'COLUMN', 'name': '*'}]},
        'alias': 'total_passengers'},
        {'expr': {'type': 'OPERATOR',
            'op': 'SUM',
            'args': [{'type': 'CASE',
            'items': [{'when': {'type': 'OPERATOR',
                'op': 'EQ',
                'args': [{'type': 'COLUMN', 'name': 'survived'},
                {'type': 'CONSTANT', 'value': '1'}]},
                'then': {'type': 'CONSTANT', 'value': 1}}],
            'elseValue': {'type': 'CONSTANT', 'value': 0}}]}},
        {'expr': {'type': 'OPERATOR',
            'op': 'DIV',
            'args': [{'type': 'OPERATOR',
            'op': 'TIMES',
            'args': [{'type': 'OPERATOR',
                'op': 'SUM',
                'args': [{'type': 'CASE',
                'items': [{'when': {'type': 'OPERATOR',
                    'op': 'EQ',
                    'args': [{'type': 'COLUMN', 'name': 'survived'},
                    {'type': 'CONSTANT', 'value': '1'}]},
                    'then': {'type': 'CONSTANT', 'value': 1}}],
                'elseValue': {'type': 'CONSTANT', 'value': 0}}]},
            {'type': 'CONSTANT', 'value': 1.0}]},
            {'type': 'OPERATOR',
            'op': 'COUNT',
            'args': [{'type': 'COLUMN', 'name': '*'}]}]},
        'alias': 'survival_rate'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'sex'}}],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'survival_rate'},
        'orderType': 'DESC'}],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers, their sex and their survival. This requires searching for information in the SQL table.'
        }},
    {"Human": "Can we identify a trend between the fare and the survival depending on the ticket class ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'}},
        {'expr': {'type': 'OPERATOR',
            'op': 'AVG',
            'args': [{'type': 'COLUMN', 'name': 'fare'}]},
        'alias': 'average_fare'},
        {'expr': {'type': 'OPERATOR',
            'op': 'DIV',
            'args': [{'type': 'OPERATOR',
            'op': 'TIMES',
            'args': [{'type': 'OPERATOR',
                'op': 'SUM',
                'args': [{'type': 'CASE',
                'items': [{'when': {'type': 'OPERATOR',
                    'op': 'EQ',
                    'args': [{'type': 'COLUMN', 'name': 'survived'},
                    {'type': 'CONSTANT', 'value': '1'}]},
                    'then': {'type': 'CONSTANT', 'value': 1}}],
                'elseValue': {'type': 'CONSTANT', 'value': 0}}]},
            {'type': 'CONSTANT', 'value': 1.0}]},
            {'type': 'OPERATOR',
            'op': 'COUNT',
            'args': [{'type': 'COLUMN', 'name': '*'}]}]},
        'alias': 'survival_rate'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'}}],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'},
        'orderType': 'ASC'}],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers survival and their class. This requires searching for information in the SQL table.'
        }},
    {"Human": "What is the age Distribution by survival status ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'}},
        {'expr': {'type': 'OPERATOR',
            'op': 'MIN',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'youngest_age'},
        {'expr': {'type': 'OPERATOR',
            'op': 'AVG',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'average_age'},
        {'expr': {'type': 'OPERATOR',
            'op': 'STDDEV_SAMP',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'age_standard_deviation'},
        {'expr': {'type': 'OPERATOR',
            'op': 'MAX',
            'args': [{'type': 'COLUMN', 'name': 'age'}]},
        'alias': 'oldest_age'}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'}}],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'ticket_class'},
        'orderType': 'ASC'}],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers age and their survival. This requires searching for information in the SQL table.'
        }},
    {"Human": "Tell me about all the passengers that were under 18 ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': '*'}}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [{'type': 'OPERATOR',
        'op': 'LT',
        'args': [{'type': 'COLUMN', 'name': 'age'},
            {'type': 'CONSTANT', 'value': 18}]}],
        'having': [],
        'groupBy': [],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'age'}, 'orderType': 'DESC'}],
        'limit': None,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers age. This requires searching for information in the SQL table.'
        }},
    {"Human": "Who was the oldest passenger ?",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'passenger_id'},
        'alias': 'oldest_passenger_id'},
        {'expr': {'type': 'COLUMN', 'name': 'age'}}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'age'}, 'orderType': 'DESC'}],
        'limit': 1,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers age. This requires searching for information in the SQL table.'
        }},
    {"Human": "Who was the oldest passenger ? Tell me more about him",
     "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'passenger_id'},
        'alias': 'oldest_passenger_id'},
        {'expr': {'type': 'COLUMN', 'name': 'survived'}},
        {'expr': {'type': 'COLUMN', 'name': 'title'}},
        {'expr': {'type': 'COLUMN', 'name': 'sex'}},
        {'expr': {'type': 'COLUMN', 'name': 'age'}},
        {'expr': {'type': 'COLUMN', 'name': 'family_size'}},
        {'expr': {'type': 'COLUMN', 'name': 'ticket_class'}},
        {'expr': {'type': 'COLUMN', 'name': 'fare'}},
        {'expr': {'type': 'COLUMN', 'name': 'cabin'}},
        {'expr': {'type': 'COLUMN', 'name': 'port_of_embarkation'}},
        {'expr': {'type': 'COLUMN', 'name': 'age'}}],
        'from': {'type': 'TABLE',
        'name': f'{TITANIC_DATASOURCE_NAME}',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [],
        'having': [],
        'groupBy': [],
        'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'age'}, 'orderType': 'DESC'}],
        'limit': 1,
        'comment': None,
        'alias': None,
        'justification': 'The request is about informations regarding the Titanic passengers age and their characteristics. This requires searching for information in the SQL table.'
        }}
]


LOGGING_DATASOURCE_NAME = "webapp_logs"
LOGGING_DATASOURCE_DESCRIPTION = f"""## SQL Table Description and Schema
Name: {LOGGING_DATASOURCE_NAME} 
SQL Database type: PostgreSQL
Datasource description: This table contains information about the usage of webapp API backend logging. 

## Columns description
- Name: 'datetime' | Type: 'date' | Description: 'Date and time of the call'
- Name: 'user_id' | Type: 'string' | Description: 'User id of the use that made the call.'
- Name: 'country' | Type: 'string' | Description: 'The country where the call is made from.'
- Name: 'model' | Type: 'string' | Description: 'Name of the model connection service that was used.'
- Name: 'token_count' | Type: 'int' | Description: 'Number of tokens used to make the call to the LLM endpoint. May not be accurate'
- Name: 'call_length_seconds' | Type: 'int' | Description: 'Time taken for the LLM call to return a response in seconds.
## -- End of Description --
"""


LOGGING_DATASOURCE_RAW_CONVERSATION = [
    {   
        "Human": "Which users have logged in within the last hour?",
        "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'user_id'}},
        {'expr': {'type': 'COLUMN', 'name': 'datetime'}}],
        'from': {'type': 'TABLE',
        'name': 'NEW_FEATURE_SQL_RET_llm_usage',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [{'type': 'OPERATOR',
        'op': 'GT',
        'args': [{'type': 'COLUMN', 'name': 'datetime'},
            {'type': 'INLINE_EXPRESSION', 'expr': "NOW() - INTERVAL '1 HOUR'"}]}],
        'having': [],
        'groupBy': [],
        'orderBy': [],
        'limit': 1,
        'comment': None,
        'alias': None,
        'justification': "The user requested information on recent logins within the last hour which requires searching for information in the SQL table."
        }
    },
    {   
        "Human": "Which users have made call from Malaysia or Germany?",
        "Assistant": {'type': 'QUERY',
        'with': [],
        'distinct': False,
        'selectList': [{'expr': {'type': 'COLUMN', 'name': 'user_id'}}, {'expr': {'type': 'COLUMN', 'name': 'country'}}],
        'from': {'type': 'TABLE',
        'name': 'NEW_FEATURE_SQL_RET_llm_usage',
        'catalog': None,
        'schema': 'public',
        'alias': None},
        'join': [],
        'where': [{'type': 'OPERATOR',
                'op': 'AND',
                'args': [{'type': 'OPERATOR',
                'op': 'OR',
                'args': [{'type': 'OPERATOR',
                    'op': 'EQ',
                    'args': [{'type': 'OPERATOR',
                    'op': 'UPPER',
                    'args': [{'type': 'COLUMN', 'name': 'country'}]},
                    {'type': 'CONSTANT', 'value': 'MALAYSIA'}]},
                    {'type': 'OPERATOR',
                    'op': 'EQ',
                    'args': [{'type': 'OPERATOR',
                    'op': 'UPPER',
                    'args': [{'type': 'COLUMN', 'name': 'country'}]},
                    {'type': 'CONSTANT', 'value': 'GERMANY'}]}]}]}],
        'having': [],
        'groupBy': [],
        'orderBy': [],
        'limit': 1,
        'comment': None,
        'alias': None,
        'justification': "The user requested information on recent logins within the last hour which requires searching for information in the SQL table."
        }
    }
]


MARKETPLACE_DATASOURCE_NAME = "marketplace_transactions"
MARKETPLACE_DATASOURCE_DESCRIPTION = f"""## SQL Table Description and Schema
Name: {MARKETPLACE_DATASOURCE_NAME} 
SQL Database type: PostgreSQL
Datasource description: This table records the transactions made by customers on our marketplace.
## Columns description
- Name: 'transaction_id' | Type: 'string' | Description: 'The identifier of a transaction made by a customer.'
- Name: 'transaction_timestamp' | Type: 'date' | Description: 'The timestamp when a customer made a transaction.'
- Name: 'product_id' | Type: 'string' | Description: 'The identifier of a product purchased by the customer within a transaction.'
- Name: 'purchased_items' | Type: 'bigint' | Description: 'The number of items (referring to the 'product_id') purchased by the customer during the transaction.'
- Name: 'item_unit_price' | Type: 'double' | Description: 'The price of a single item (referring to the 'product_id') at the moment of the transaction.'
- Name: 'customer_id' | Type: 'string' | Description: 'The identifier of a customer.'
- Name: 'customer_country' | Type: 'string' | Description: 'The living country of the customer, at the moment of the transaction.'
-- End of Description --
"""


MARKETPLACE_DATASOURCE_RAW_CONVERSATION = [
    {
        "Human": "How many transactions did we record daily in the last two weeks?",
        "Assistant": {'type': 'QUERY',
                      'with': [],
                      'distinct': False,
                      'selectList': [{'expr': {'type': 'OPERATOR',
                          'op': 'DATETRUNC',
                          'args': [{'type': 'COLUMN', 'name': 'transaction_timestamp'},
                          {'type': 'CONSTANT', 'value': 'DAY'}]},
                      'alias': 'date'},
                      {'expr': {'type': 'OPERATOR',
                          'op': 'COUNT',
                          'args': [{'type': 'OPERATOR',
                          'op': 'DISTINCT',
                          'args': [{'type': 'COLUMN', 'name': 'transaction_id'}]}]},
                      'alias': 'n_distinct_transactions'}],
                      'from': {'type': 'TABLE',
                      'name': 'CHATBOXPOC_transactions_uci_prepared',
                      'catalog': None,
                      'schema': 'public',
                      'alias': None},
                      'join': [],
                      'where': [],
                      'having': [],
                      'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'date'}}],
                      'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'date'},
                      'orderType': 'DESC'}],
                      'limit': 14,
                      'comment': None,
                      'alias': None,
                      'justification': 'The request is about informations regarding the amount of transactions over time. This requires searching for information in the SQL table.'
                      }
    },
    {
        "Human": "In which year did we earn the most important revenue?",
        "Assistant": {'type': 'QUERY',
                      'with': [],
                      'distinct': False,
                      'selectList': [{'expr': {'type': 'OPERATOR',
                         'op': 'DATEPART',
                         'args': [{'type': 'COLUMN', 'name': 'transaction_timestamp'},
                          {'type': 'CONSTANT', 'value': 'YEAR'}]},
                        'alias': 'year'},
                       {'expr': {'type': 'OPERATOR',
                         'op': 'SUM',
                         'args': [{'type': 'OPERATOR',
                           'op': 'TIMES',
                           'args': [{'type': 'COLUMN', 'name': 'purchased_items'},
                            {'type': 'COLUMN', 'name': 'item_unit_price'}]}]},
                        'alias': 'total_revenue'}],
                      'from': {'type': 'TABLE',
                       'name': 'CHATBOXPOC_transactions_uci_prepared',
                       'catalog': None,
                       'schema': 'public',
                       'alias': None},
                      'join': [],
                      'where': [],
                      'having': [],
                      'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'year'}}],
                      'orderBy': [{'expr': {'type': 'COLUMN', 'name': 'total_revenue'},
                        'orderType': 'DESC'}],
                      'limit': 100,
                      'comment': None,
                      'alias': None,
                      'justification': 'The request is about informations regarding revenue over years. This requires searching for information in the SQL table.'
                      }
        }

]


MARKETING_CAMPAIGN_EFFECTIVENESS_DATASOURCE_NAME = "marketing_campaign_effectiveness"
MARKETING_CAMPAIGN_EFFECTIVENESS_DATASOURCE_DESCRIPTION = f"""## SQL Table Description and Schema
Name: {MARKETING_CAMPAIGN_EFFECTIVENESS_DATASOURCE_NAME} 
SQL Database type: PostgreSQL
Datasource description: This table contains information about the effectiveness of marketing campaigns, including details about the campaigns, customer demographics, and purchase behavior.
## Columns description
- Name: 'campaign_id' | Type: 'string' | Description: 'Unique identifier for each marketing campaign.'
- Name: 'campaign_start_date' | Type: 'date' | Description: 'The start date of the marketing campaign.'
- Name: 'campaign_budget' | Type: 'int' | Description: 'The budget allocated for the marketing campaign in USD.'
- Name: 'campaign_product_category_focus' | Type: 'string' | Description: 'The product category that was the focus of the marketing campaign.'
- Name: 'customer_id' | Type: 'string' | Description: 'Unique identifier for each customer.'
- Name: 'customer_country' | Type: 'string' | Description: 'The country where the customer is located.'
- Name: 'customer_gender' | Type: 'string' | Description: 'The gender of the customer.'
- Name: 'customer_birth_date' | Type: 'date' | Description: 'The birth date of the customer.'
- Name: 'first_purchase_date' | Type: 'date' | Description: 'The date when the customer made their first purchase in response to the campaign.'
- Name: 'first_purchase_amount' | Type: 'float' | Description: 'The amount spent by the customer on their first purchase in response to the campaign in USD.'
## -- End of Description --
"""


MARKETING_CAMPAIGN_EFFECTIVENESS_RAW_CONVERSATION = [
    {
        "Human": "Which campains had the fastest customers engagement ?",
        "Assistant": {'type': 'QUERY',
                      'with': [],
                      'distinct': False,
                      'selectList': [{'expr': {'type': 'COLUMN', 'name': 'campaign_id'}},
                       {'expr': {'type': 'OPERATOR',
                         'op': 'AVG',
                         'args': [{'type': 'OPERATOR',
                           'op': 'DATEDIFF',
                           'args': [{'type': 'COLUMN', 'name': 'first_purchase_date'},
                            {'type': 'COLUMN', 'name': 'campaign_start_date'},
                            {'type': 'CONSTANT', 'value': 'DAY'}]}]},
                        'alias': 'average_days_to_first_purchase'}],
                      'from': {'type': 'TABLE',
                       'name': 'CHATBOXPOC_marketing_campaign_prepared',
                       'catalog': None,
                       'schema': 'public',
                       'alias': None},
                      'join': [],
                      'where': [],
                      'having': [],
                      'groupBy': [{'expr': {'type': 'COLUMN', 'name': 'campaign_id'}}],
                      'orderBy': [{'expr': {'type': 'COLUMN',
                         'name': 'average_days_to_first_purchase'},
                        'orderType': 'DESC'}],
                      'limit': None,
                      'comment': None,
                      'alias': None,
                      'justification': 'The request is about informations about marketing campain KPIs. This requires searching for information in the SQL table.'
                    }
        }
]



EXAMPLE_LIST = [
    {"data_description": TITANIC_DATASOURCE_DESCRIPTION,"example_conversations": TITANIC_DATASOURCE_RAW_CONVERSATION},
    {"data_description": LOGGING_DATASOURCE_DESCRIPTION,"example_conversations": LOGGING_DATASOURCE_RAW_CONVERSATION},
    {"data_description": MARKETPLACE_DATASOURCE_DESCRIPTION, "example_conversations": MARKETPLACE_DATASOURCE_RAW_CONVERSATION},
    {"data_description": MARKETING_CAMPAIGN_EFFECTIVENESS_DATASOURCE_DESCRIPTION, "example_conversations": MARKETING_CAMPAIGN_EFFECTIVENESS_RAW_CONVERSATION}, 
]