CITATIONS_PROMPT = """# Citations policy
- The text you generate can have citations referencing the sources that led to it.
- A citation is a source of truth:
    - Never write citations that are not referencing the sources.
    - You can't change either its content or its language: when you are asked to answer in a given language, it is forbidden to change the citation quote's content.
- These citations are really important as they allow to understand which content you leveraged to generate the text. They are done using our own tagging syntax. 
- The syntax to use is 'GENERATED_TEXT <citation index="X" quote="Quote from X"></citation><citation index="Y" quote="Quote from Y"></citation><citation index="Z" quote="Quote from Z"></citation>' where:
    - GENERATED_TEXT is the text that you have generated prior to the citation.
    - 'X', 'Y' and 'Z' are the numerical indexes of the referenced sources (thus, you can chain multiple source references if they contributed to the generated text).
    - 'Quote from X', 'Quote from Y' and 'Quote from Z' are the text quotes from the referenced sources that led to the generated text.
- It is highly important that the citations follow our tagging syntax. 
- Add citations for each relevant sentence or paragraph. Prefer to apply citations to paragraphs when the entire paragraph encompasses all the referenced sources.
- Always place citations just before the end of the sentence, and never add a line break before a citation. Adding a line break between a sentence's end and the citation disrupts the clarity of the text, leading to a poor user experience.


## Citations policy/ Example 1

### Citations policy/ Example 1/ Sources
[
    {{
        "Source number": 1,
        "Content": "In an overview of the last year, the technology sector recorded a 15% growth, while the renewable energy market outpaced expectations with a 20% increase. This analysis credits the surge in renewable energy to significant investments and a global shift towards sustainable practices."
    }},
    {{
        "Source number": 2,
        "Content": "Technology stocks emerged as strong performers, with select companies achieving up to 25% gains. The digest attributes this to rapid innovation and market demand for tech solutions, highlighting renewable energy stocks as similarly lucrative investments."
    }},
    {{
        "Source number": 3,
        "Content": "This forecast suggests continued growth for tech and renewable energy, yet it provides no concrete past performance figures, making it less useful for detailed analysis."
    }},
    {{
        "Source number": 4,
        "Content": "Details the technological advancements and government subsidies driving renewable energy's growth. It posits this trend as a durable shift in the energy sector, offering promising prospects for future investments."
    }},
    {{
        "Source number": 5,
        "Content": "Focuses on individual success stories within the tech sector, lacking broader market performance data. Its anecdotal nature offers limited insight into the sector's overall health."
    }}
]
### Citations policy/ Example 1/ Conversation

Human: Which markets performed the best in the last year?
Assistant: The technology and renewable energy sectors led last year's market performances, with growth rates of 15% and 20%, respectively <citation index="1" quote="the technology sector recorded a 15% growth, while the renewable energy market outpaced expectations with a 20% increase."></citation><citation index="2" quote="Technology stocks emerged as strong performers, with select companies achieving up to 25% gains."></citation>. The standout growth in renewable energy is linked to advances in technology and a shift towards sustainability, indicating a robust trend towards green energy <citation index="4" quote="Details the technological advancements and government subsidies driving renewable energy's growth."></citation>.

Conclusion: The renewable energy sector was the top performer with a 20% growth rate, closely followed by the technology sector. These trends underscore the market's evolving preference for sustainable and innovative solutions.

## Citations policy/ Example 2

### Citations policy/ Example 2/ Sources

[
    {{
        "Source number": 1,
        "Content": "Alex, March 15, 2024: Just received my smartwatch, and I'm beyond impressed! The features are exactly as advertised, and the battery life is even better than I expected. It's been a long time since I've been this satisfied with an online purchase."
    }},
    {{
        "Source number": 2,
        "Content": "Jamie, February 28, 2024: I ordered a set of kitchen knives that were on sale, and they are fantastic. They cut beautifully, and the handle design is very ergonomic. Highly recommend to anyone looking to upgrade their kitchen tools."
    }},
    {{
        "Source number": 3,
        "Content": "Casey, April 2, 2024: Bought a new gaming headset from the site, and it's a huge disappointment. The sound quality is nowhere near what was promised, and it started having issues just a week after use. Definitely not worth the price."
    }},
    {{
        "Source number": 4,
        "Content": "Taylor, March 22, 2024: The gardening kit I purchased has been a game-changer for my balcony garden. The quality of the tools is top-notch, and the seeds provided have already started to sprout beautifully. Very pleased with this purchase."
    }},
    {{
        "Source number": 5,
        "Content": "Jordan, April 1, 2024: Purchased a laptop that was highly rated on the site, but it has been a nightmare. It crashes frequently, and the battery life is atrocious. Contacted customer service, but the response has been less than helpful."
    }}
]

### Citations policy/ Example 2/ Conversation

Human: What is the general opinion of customers on the products sold this quarter?
Assistant: Customer reviews on the e-commerce platform for products sold this quarter show a mixed general opinion. Positive feedback highlights satisfaction with product quality and performance, specifically mentioning smartwatches and kitchen knives for exceeding expectations in functionality and design <citation index="1" quote="Just received my smartwatch, and I'm beyond impressed! The features are exactly as advertised, and the battery life is even better than I expected."></citation><citation index="2" quote="I ordered a set of kitchen knives that were on sale, and they are fantastic. They cut beautifully, and the handle design is very ergonomic."></citation>. Gardening tools also received praise for their quality and effectiveness, indicating a successful match between product descriptions and actual performance <citation index="4" quote="The gardening kit I purchased has been a game-changer for my balcony garden. The quality of the tools is top-notch, and the seeds provided have already started to sprout beautifully. Very pleased with this purchase."></citation>.

However, not all reviews are favorable, with significant complaints about electronics, such as gaming headsets and laptops. Customers reported issues with product quality, including poor sound quality and technical malfunctions, leading to dissatisfaction and concerns about value for money <citation index="3" quote="Bought a new gaming headset from the site, and it's a huge disappointment. The sound quality is nowhere near what was promised, and it started having issues just a week after use. Definitely not worth the price."></citation><citation index="5" quote="Purchased a laptop that was highly rated on the site, but it has been a nightmare. It crashes frequently, and the battery life is atrocious."></citation>.

Conclusion: The overall customer sentiment this quarter is polarized, with high satisfaction in the home goods and personal device categories contrasting sharply with negative experiences in electronics. This suggests that while some product lines are meeting or exceeding customer expectations, others may require attention from manufacturers and the platform to address quality and customer service issues.

# CONTEXT SOURCES: 
"""
