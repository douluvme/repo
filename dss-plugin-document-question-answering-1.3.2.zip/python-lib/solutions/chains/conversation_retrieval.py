import inspect
import json
from typing import Any, Dict, List, Optional, Tuple

from backend.utils.dataiku_api import dataiku_api
from langchain.callbacks.manager import CallbackManagerForChainRun
from langchain.chains import ConversationalRetrievalChain
from langchain.schema.document import Document
from langchain_core.prompt_values import PromptValue
from llm_assist.logging import logger
from solutions.knowledge_bank import get_knowledge_bank_schema
from solutions.prompts.conversations import CondensationChainHandler


class DKUConversationRetrievalChain(ConversationalRetrievalChain):
    """
    DKUConversationRetrievalChain is a subclass of ConversationalRetrievalChain 
    designed to tailor the conversational retrieval process with a specific 
    implementation for generating the final prompt based on chat history and 
    question modification, to be able to use it for the streaming
    It works only when the chain_type is "stuff"
    """

    def _extract_docs(self, inputs: Dict[str, Any], question: str, run_manager: CallbackManagerForChainRun) -> List[Document]:
        logger.debug(
            f"DKUConversationalChain, _extract_docs == question is: {question}")
        """Extract the documents from the inputs"""
        accepts_run_manager = "run_manager" in inspect.signature(
            self._get_docs).parameters
        if accepts_run_manager:
            docs = self._get_docs(question, inputs,
                                  run_manager=run_manager)
        else:
            docs = self._get_docs(question, inputs) # type: ignore[call-arg]
        return docs

    def _generate_new_quetion(self, question: str, run_manager: CallbackManagerForChainRun,  chat_history_str: Optional[str]) -> str:
        """Extract the chat history from the inputs and generate a new question if necessary"""
        new_question: str = question
        if chat_history_str:
            callbacks = run_manager.get_child()
            new_question = self.question_generator.run(
                question=question, chat_history=chat_history_str, callbacks=callbacks
            )            
        return new_question

    def _prepare_llm_inputs(self, inputs: Dict[str, Any], question: str, run_manager: CallbackManagerForChainRun, docs, chat_history_str: Optional[str], *, enable_llm_citations: bool = False) -> Dict[str, Any]:
        """ Build new inputs for the llm chain """
        new_inputs = inputs.copy()
        new_inputs["question"] = question
        new_inputs["chat_history"] = chat_history_str
        other_keys = {k: v for k, v in new_inputs.items() if k !=
                      "input_document"}
        # Get the inputs is only possible for chain_type "stuff"
        # if enable_llm_citations:
        documents_context = self.from_retriever_documents_to_structured_context(
            docs)
        final_inputs: Dict[str, Any] = {"question": question, "context": documents_context}
        # else:
        # final_inputs = self.combine_docs_chain._get_inputs(
        # docs, callbacks=run_manager.get_child(), **other_keys)
        final_inputs["chat_history"] = chat_history_str
        return final_inputs

    def prepare_final_answer_prompt(
        self,
        condensed_query: str,
        kb_query: str,
        inputs: Dict[str, Any],
        run_manager: Optional[CallbackManagerForChainRun] = None,
        enable_llm_citations: bool = False
    ) -> Tuple[List[PromptValue], Dict[str, Any]]:
        """
        Prepares a prompt for answer generation by using chat history to refine 
        the question and incorporating relevant documents for context.

        Parameters:
        - inputs (dictionary): Contains the initial question and chat history.
        - run_manager (CallbackManagerForChainRun, optional): Manages callbacks, defaults to a no-op manager.

        Returns:
        - (List[PromptValue], dictionary): The final prompt(s) and additional output details like 'source_documents'.

        Note:
        - Optimized for use in conversational retrieval chains where chat history impacts question formation and answer generation.
        - Accommodates both modified and unchanged questions influenced by chat history.
        """
        _run_manager = run_manager or CallbackManagerForChainRun.get_noop_manager()
        condensation_chain_handler = CondensationChainHandler()
        chat_history_str = condensation_chain_handler.format_chat_history_for_condensation(
            chat_history=inputs["chat_history"], dialogs_format="tuples")
        # Extract docs
        docs = self._extract_docs(
            inputs, question=kb_query, run_manager=_run_manager)
        final_inputs = self._prepare_llm_inputs(
            inputs, question=condensed_query,
            docs=docs, run_manager=_run_manager,
            chat_history_str=chat_history_str,
            enable_llm_citations=enable_llm_citations
        )
        # Generate the final prompt
        final_prompt = self.combine_docs_chain.llm_chain.prep_prompts(input_list=[final_inputs], run_manager=_run_manager) # type: ignore

        # Prepare the output
        question_info: Dict[str, Any] = {}

        if self.return_source_documents:
            question_info["source_documents"] = docs

        if self.return_generated_question:
            question_info["generated_question"] = condensed_query
        return final_prompt[0][0], question_info

    def from_retriever_documents_to_structured_context(self, list_of_documents: List[Document]) -> str:
        structured_documents = []

        metadata_fields = dataiku_api.webapp_config.get("knowledge_sources_context_metadata")

        knowledge_bank_id = dataiku_api.webapp_config.get("knowledge_bank_id")
        knowledge_bank_schema = get_knowledge_bank_schema(knowledge_bank_id)

        for document_index, document in enumerate(list_of_documents):
            if metadata_fields:
                filtered_metadata = [
                    {
                        "description": schema.get("comment", ""),
                        "name": schema["name"],
                        "value": document.metadata[schema["name"]]
                    }
                    for schema in knowledge_bank_schema if schema["name"] in document.metadata and schema["name"] in metadata_fields
                ]

                structured_document = {
                    "Source number": document_index + 1,
                    "Content": document.page_content,
                    "Metadata": filtered_metadata
                }
            else:
                structured_document = {
                    "Source number": document_index + 1,
                    "Content": document.page_content,
                }
            structured_documents.append(structured_document)

        documents_context = json.dumps(structured_documents, ensure_ascii=False, indent=4)
        return documents_context

    def from_retriever_documents_to_context(self, list_of_documents: List[Document]):
        indexed_documents = []
        for document_index, document in enumerate(list_of_documents):
            document_content = document.page_content
            indexed_documents.append(
                f'- Source n°{document_index+1}: {document_content}\n\n')
        documents_context = "".join(indexed_documents)
        return documents_context
