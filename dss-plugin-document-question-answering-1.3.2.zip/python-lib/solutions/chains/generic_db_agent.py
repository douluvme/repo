import json
import re
from abc import ABC, abstractmethod
from typing import Any, Dict

from langchain.prompts import ChatPromptTemplate
from llm_assist.logging import logger


class GenericDBAgent(ABC):
    # Abstract class for Knowledge Bank Agents
    # Implement the prompt property in the child class
    @property
    def formatted_errors(self):
        if len(self.previous_sql_errors) > 0:
            errors = ""
            for idx, error_response in enumerate(self.previous_sql_errors):
                errors += f"""Attempt {idx}:
                Response:
                {error_response['response']}
                Query:
                {error_response['query']}
                Error returned
                {error_response['error']}
                ---------------------------------
                """
            return errors
        logger.debug("errors: NO ERRORS!")
        return ""

    @property
    @abstractmethod
    def graph_prompt(self):
        pass

    @abstractmethod
    def update_graph(self, selected_graph: Dict[str, Any], justification: str):
        pass

    @property
    @abstractmethod
    def prompt(self):
        pass

    @property
    @abstractmethod
    def chosen_tables_and_columns(self):
        pass

    @property
    @abstractmethod
    def graph_justification(self):
        pass

    def get_retrieval_graph(self, llm, chat_history, user_input, max_retries=3):
        json_format_try_count = 0
        justification = ""
        final_graph_prompt = self.graph_prompt.format(chat_history=chat_history, last_user_input=user_input)
        logger.debug(f"DB Metadata identification FINAL PROMPT {final_graph_prompt}")
        logger.debug("Identifying necessary metadata for DB queries...")
        chain = self.graph_prompt | llm
        while json_format_try_count < max_retries:
            try:
                logger.debug(f"Attempt {json_format_try_count} to define DB queries information...")
                response = chain.invoke({"chat_history": chat_history, "last_user_input": user_input})
                logger.debug(f"Generated response for DB queries information: {response}")
                match = re.search(r"\{.*\}", response, re.DOTALL)
                if match:
                    json_str = match.group(0)
                    try:
                        response_json = json.loads(json_str)
                    except Exception as e:
                        logger.debug(f"Error in JSON load: {e}")
                        json_format_try_count += 1
                        continue
                    tables_and_columns = response_json.get("tables_and_columns")
                    suggested_joins = response_json.get("suggested_joins")
                    justification = response_json.get("justification")
                    if all(q is None for q in [tables_and_columns, suggested_joins]):
                        return self.update_graph({"tables_and_columns": None, "suggested_joins": None}, justification)
                    return self.update_graph(
                        {"tables_and_columns": tables_and_columns, "suggested_joins": suggested_joins}, justification
                    )
                else:
                    json_format_try_count += 1

            except json.JSONDecodeError as e:
                logger.debug(f"Error in get_retrieval_graph: {e}")
                json_format_try_count += 1
            except Exception as e:
                logger.debug(f"Error in get_retrieval_graph: {e}")
                return self.update_graph(None, justification)
        return self.update_graph(None, justification)

    def get_retrieval_query(self, llm, chat_history, user_input, max_retries=3, failed_response: dict = {}):
        json_format_try_count = 0
        justification = ""
        if self.chosen_tables_and_columns == "":
            return None, self.graph_justification
        while json_format_try_count < max_retries:
            try:
                logger.debug(f"Attempt {json_format_try_count} to generate prompt for LLM...")
                final_prompt = self.prompt.format(chat_history=chat_history, last_user_input=user_input)
                if not failed_response:
                    logger.debug(f"DB query FINAL PROMPT {final_prompt}")

                if failed_response:
                    logger.debug("Correcting query prompt ...")
                    response = self.fix_retrieval_query(llm, chat_history, user_input)
                else:
                    logger.debug("Creating initial query prompt ...")
                    chain = self.prompt | llm
                    response = chain.invoke({"chat_history": chat_history, "last_user_input": user_input})
                logger.debug(f"Generated response for DB query: {response}")
                match = re.search(r"\{.*\}", response, re.DOTALL)
                if match:
                    json_str = match.group(0)
                    try:
                        response_json = json.loads(json_str)
                    except Exception as e:
                        logger.debug(f"Error in JSON load: {e}")
                        json_format_try_count += 1
                        continue
                    with_ = response_json.get("with")
                    select_list = response_json.get("selectList")
                    from_ = response_json.get("from")
                    join = response_json.get("join")
                    where_ = response_json.get("where")
                    grp_by = response_json.get("groupBy")
                    having = response_json.get("having")
                    order_by = response_json.get("orderBy")
                    limit = response_json.get("limit")
                    justification = response_json.get("justification")

                    logger.debug(
                        f"with: {with_}, select list: {select_list}, from: {from_}, join: {join}, where: {where_}, group by: {grp_by}, having: {having}, order_by: {order_by}, limit: {limit}, Justification: {justification}"
                    )

                    if all(
                        q is None for q in [with_, select_list, from_, join, where_, grp_by, having, order_by, limit]
                    ):
                        return None, justification

                    query_dict = {
                        "with": with_,
                        "selectList": select_list,
                        "from": from_,
                        "join": join,
                        "where": where_,
                        "groupBy": grp_by,
                        "having": having,
                        "orderBy": order_by,
                        "limit": limit,
                    }
                    return query_dict, justification
                else:
                    json_format_try_count += 1

            except json.JSONDecodeError as e:
                json_format_try_count += 1
            except Exception as e:
                return None, justification
        return None, justification

    def fix_retrieval_query(self, llm, chat_history, user_input):
        assert self.user_error_prompt, "An error prompt must be assigned in order to correct query errors"
        logger.debug(f"DB query: attempting to fix previous errors  {self.previous_sql_errors}")

        error_system_prompt = f"""You are an expert in fixing SQL query errors. You help the query build to fix its errors.
        Look at  chat history, task and response and fix it. It is essential that your response in the same JSON format as the task.
        Provide the JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.
        Here the instructions that the query builder received 
        # Previous instructions:
        {self.query_system_prompt}
        """

        formatted_errors = ""
        for idx, error_response in enumerate(self.previous_sql_errors):
            formatted_errors += f"""Attempt {idx}:
            Response:
            {error_response['response']}
            Query:
            {error_response['query']}
            Error returned
            {error_response['error']}
            ---------------------------------
            """

        last_user_input = f"""The user asked: {user_input}
        This is the attempt history:
        {formatted_errors}
        Corrected response:
        """
        logger.debug(f"Error correction prompt: {self.user_error_prompt}")
        logger.debug(f"Error correct user user input: {last_user_input}")
        error_prompt = ChatPromptTemplate.from_messages(
            [("system", error_system_prompt), ("user", self.user_error_prompt)]
        )

        chain = error_prompt | llm
        response = chain.invoke({"chat_history": chat_history, "last_user_input": last_user_input})
        return response
