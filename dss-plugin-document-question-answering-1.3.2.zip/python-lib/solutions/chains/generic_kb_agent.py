import json
import re
from abc import ABC, abstractmethod

from llm_assist.logging import logger


class GenericKBAgent(ABC):
    # Abstract class for Knowledge Bank Agents
    # Implement the prompt property in the child class
    @property
    @abstractmethod
    def prompt(self):
        pass

    def get_retrieval_query(self, llm, chat_history, user_input, max_retries=3):
        justification = ""
        try_count = 0
        while try_count < max_retries:
            try:
                logger.debug("Generating prompt for LLM...")
                final_prompt = self.prompt.format(
                    chat_history=chat_history, last_user_input=user_input)
                logger.debug(
                    f"Knowledge Bank FINAL PROMPT {final_prompt}")

                chain = self.prompt | llm
                response = chain.invoke(
                    {"chat_history": chat_history, "last_user_input": user_input})
                logger.debug(
                    f"Generated response for knowledge bank: {response}")

                match = re.search(r'\{.*\}', response, re.DOTALL)
                if match:
                    json_str = match.group(0)
                    response_json = json.loads(json_str)
                    query = response_json.get("query")
                    justification = response_json.get("justification")
                    logger.debug(
                        f"Query: {query}, Justification: {justification}")
                    return query if query else None, justification
                else:
                    logger.error("No JSON object found in the response")
                    try_count += 1

            except json.JSONDecodeError as e:
                logger.exception("Failed to decode JSON response, retrying...")
                try_count += 1
            except Exception as e:
                logger.exception("Failed to build query for knowledge bank")
                return None, justification

        logger.error("Exceeded maximum retries for JSON decoding")
        return None, justification
    
