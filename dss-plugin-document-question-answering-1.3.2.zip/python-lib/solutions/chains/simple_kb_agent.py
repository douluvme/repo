from langchain.prompts import ChatPromptTemplate
from llm_assist.logging import logger
from solutions.chains.generic_kb_agent import GenericKBAgent


class SimpleKBAgent(GenericKBAgent):
    # Simple Agent that build a search query for kb based on the last user input
    # in the chat history unless it is a terminal statement.
    def __init__(self):
        # Define the prompt for the agent
        examples = """
        ### Example Scenarios:
            #### Example 1:
            CHAT HISTORY:
            [HumanMessage(content="Hello"),
            AIMessage(content="Hi there! How may I assist you today?")]
            Human: "What is our policy on remote work?"
            EXPECTED OUTPUT: {{
                "query": "Remote work policy at my company.",
                "justification": "The user is asking a question so it requires further information from knowledge bank."
            }}

            #### Example 2:
            CHAT HISTORY:
            [HumanMessage(content="Good morning"),
            AIMessage(content="Good morning! How may I assist you today?")]
            Human: "Just checking in, thanks!"
            EXPECTED OUTPUT: {{
                "query": null,
                "justification": "The user's input is a terminal statement and does not require further information."
            }}

            #### Example 3:
            CHAT HISTORY:
            [HumanMessage(content="Hello"),
            AIMessage(content="Hello! How may I assist you today?")]
            [HumanMessage(content="count to 20"),
            AIMessage(content="1, 2, 3, ..., 20"),
            Human:"Thanks!"
            EXPECTED OUTPUT: {{
                "query": null,
                "justification": "The user's input is a terminal statement and does not require further information."
            }}
        """

        system_prompt = f"""
        You are a search query builder for a knowledge bank. Your role is to analyze the chat history and user input
        and decide whether additional information retrieval is necessary from knowledge bank.

        # Knowledge Bank Overview
        The knowledge bank is a vector database designed to help in answering questions by providing relevant information.

        # Your Task
        Analyze the chat history and last user input. If the chat suggests the need for more information, 
        produce a search query based on the decision criteria outlined below. 
        Produce the response as a JSON object with two fields: 'query' and 'justification'.
        If no query is needed, 'query' should be null and 'justification' should explain why no query is necessary.
        Provide the JSON object only. Do not add any other explanations, decorations, or additional information.

        # Decision Criteria:
        - Inquiry: Generate a search query if the latest input from the user in the chat history implies a need for more information.
               
        - Response Protocol: If a last user input does not directly require information from the Knowledge Bank, the 'query' should be null.
        This is critical to ensure that the system remains focused and only retrieves or provides information when it is relevant to do so.

        - Terminal Input: If the last input from the user in the chat history is a brief greeting or a closure statement.
        {examples}
        """

        user_prompt = """
        Evaluate the following chat history to determine if a semantic search query should be generated.
        Generate the response as a JSON object with two fields: 'query' and 'justification'.
        Generate a search query only if there is a need for more information.
        If no query is needed, 'query' should be null and 'justification' should explain why no query is necessary.
        Provide the JSON object only. Do not add any other explanations, decorations, or additional information beyond the JSON object.

        # CHAT HISTORY:
        {chat_history}
        # --- END OF CHAT HISTORY ---
        Human: {last_user_input}
        Assistant:
        """

        self._prompt = ChatPromptTemplate.from_messages(
            [("system", system_prompt), ("user", user_prompt)])

        logger.debug(f"SimpleKBAgent prompt is : {self.prompt }")

    @property
    def prompt(self):
        return self._prompt