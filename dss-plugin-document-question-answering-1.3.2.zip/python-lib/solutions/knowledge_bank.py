from functools import lru_cache
from typing import Any, Dict, List, Optional, Union

import dataiku
from backend.utils.dataiku_api import dataiku_api
from backend.utils.dataiku_utils import find_recipe
from dataiku.core.dataset import Schema
from dataiku.core.knowledge_bank import KnowledgeBank
from dataikuapi.dss.knowledgebank import DSSKnowledgeBankListItem
from llm_assist.logging import logger

webapp_config = dataiku_api.webapp_config


def get_knowledge_bank_full_name(knowledge_bank_id):
    if knowledge_bank_id:
        knowledge_bank = KnowledgeBank(
            knowledge_bank_id, project_key=dataiku_api.default_project_key
        )
        return knowledge_bank.full_name
    else:
        return None

@lru_cache(maxsize=None)
def get_knowledge_bank_name(id: Optional[str]) -> Optional[str]:
    if id is None:
        return None
    project = dataiku_api.default_project

    short_id = id
    if "." in id:
        (project_key, short_id) = id.split(".", 1)
    for kb in project.list_knowledge_banks():
        item: DSSKnowledgeBankListItem = kb
        if item.id == short_id:
            name: str = kb.name
            return name
    return None


def get_knowledge_bank_retriever(knowledge_bank_id: Optional[str] = None, filters: Optional[Dict[str, List[Any]]] = None, search_type: Optional[str] = "") -> Any:
    from backend.utils.parameter_helpers import get_retriever_search_kwargs
    logger.debug(f'Search type: {search_type}')
    
    retriever = KnowledgeBank(
        knowledge_bank_id, project_key=dataiku_api.default_project_key
    ).as_langchain_retriever(
        search_type=search_type,
        search_kwargs=get_retriever_search_kwargs(filters=filters),
    )
    return retriever


@lru_cache(maxsize=None)
def get_vector_db_type(project, knowledge_bank_id: Optional[str] = None):
    if knowledge_bank_id:
        return project.get_knowledge_bank(knowledge_bank_id).as_core_knowledge_bank()._get()['vectorStoreType']
    return None


@lru_cache(maxsize=None)
def get_knowledge_bank_schema(knowledge_bank_id: str) -> Union[Any, Schema]:
    project = dataiku_api.default_project
    flow = project.get_flow()
    graph = flow.get_graph()
    recipe_json = find_recipe(graph.data, knowledge_bank_id)

    dataset_name = recipe_json.get("predecessors")[0]
    dataset = dataiku.Dataset(
        project_key=dataiku_api.default_project_key, name=dataset_name
    )

    schema = dataset.read_schema()
    return schema