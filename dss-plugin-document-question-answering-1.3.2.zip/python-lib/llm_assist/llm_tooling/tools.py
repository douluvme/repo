import re 
from typing import Any, List, Tuple

import dataiku
from backend.db.sql.queries import get_table_name_from_dataset
from backend.utils.dataiku_api import dataiku_api
from dataiku import SQLExecutor2
from dataiku.core.dataset import Dataset
from dataiku.sql import SelectQuery, toSQL
from langchain.tools import BaseTool
from llm_assist.logging import logger

DATASET_ID_TAG = "_DATASET_NAME_"

PROJECT_KEY = dataiku_api.default_project_key
SELECTED_CONN = dataiku_api.webapp_config.get("sql_retrieval_connection")
PROJECT = dataiku.api_client().get_project(PROJECT_KEY)


def get_table_from_dataset_name(dataset_name: str) -> str:
    return get_table_name_from_dataset(Dataset(dataset_name))[1:-1]


def format_table_description(dataset_name: str, connection_type: str, short_desc: str, schema: List) -> str:
    full_text = (
        f"Name: {dataset_name}{DATASET_ID_TAG}\n"
        f"SQL Database type: {connection_type}\n"
        f"Datasource description: {short_desc}\n\n"
        "## Columns description\n"
    )
    for col in schema:
        full_text += f"""
        - Name: '{col["name"]}' | Type: '{col["type"]}' | Description: '{col.get("comment")}'
        """
    full_text += "-- End of Description --\n"
    return full_text


def get_dataset_description(dataset_name: str) -> str:
    dataset = dataiku.Dataset(dataset_name, project_key=PROJECT_KEY)
    connection_type = dataset.get_config().get("type")
    has_comments = True

    dataset_config = dataset.get_config()
    short_desc = dataset_config.get("shortDesc")
    long_desc = dataset_config.get("description")
    if short_desc is None and long_desc is None:
        logger.warn(
            "Dataset must have description. Add one under details > short description / details > Long description"
        )

    schema = dataset_config.get("schema", {}).get("columns", {})
    for s in schema:
        if len(s.get("comment", "")) < 1:
            has_comments = False
    if not has_comments:
        logger.warn(
            "It is recommended that all columns have a description. click dataset > settings > schema then click on a column and edit the DESCRIPTION on the right hand side"
        )
    description = long_desc if long_desc is not None else short_desc
    full_text_table_description = format_table_description(dataset_name, connection_type, description, schema)

    return full_text_table_description


def get_all_dataset_descriptions() -> str:
    dataset_descriptions = ""
    sql_retrieval_table_list = dataiku_api.webapp_config.get("sql_retrieval_table_list", [])
    if len(sql_retrieval_table_list) > 0:
        for dataset in sql_retrieval_table_list:
            dataset_descriptions += get_dataset_description(dataset)
            dataset_descriptions += "---------------------------------- \n"
        return dataset_descriptions
    raise Exception("At least one SQL table is required.")


def get_all_suggested_joins() -> str:
    all_suggested_joins = ""
    sql_retrieval_suggested_joins = dataiku_api.webapp_config.get("sql_retrieval_suggested_joins", [])
    if len(sql_retrieval_suggested_joins) > 0:
        for suggestion in sql_retrieval_suggested_joins:
            left_dataset, left_column = suggestion["sql_left_column"].split(".")
            right_dataset, right_column = suggestion["sql_right_column"].split(".")
            all_suggested_joins += f"{left_dataset}{DATASET_ID_TAG}.{left_column} = {right_dataset}{DATASET_ID_TAG}.{right_column} \n"
        return all_suggested_joins
    return "None"


def correct_table_names(initial_query: str) -> Tuple[str, List]:
    tables_used = []
    pattern = rf"\b\w*{re.escape(DATASET_ID_TAG)}\b"
    if re.search(pattern, initial_query):

        def replace_and_collect(match):
            dataset_name = match.group(0).rsplit(DATASET_ID_TAG, 1)[0]
            tables_used.append(dataset_name)
            table_name = get_table_from_dataset_name(dataset_name)
            return table_name

        corrected_query = re.sub(pattern, replace_and_collect, initial_query)
    else:
        corrected_query = initial_query

    return corrected_query, tables_used

def get_dataset_descriptions_from_table_names(tables_used: List[str]) -> str:
    datasets = PROJECT.list_datasets()
    connection_datasets = [d["name"] for d in datasets if d["params"].get("connection", "") == SELECTED_CONN]
    used_datasets_descriptions = ""
    for table in tables_used:
        for dataset_name in connection_datasets:
            ds = Dataset(dataset_name)
            ds_table = ds.get_location_info()["info"]["table"]
            if table == ds_table:
                used_datasets_descriptions += get_dataset_description(dataset_name)
                used_datasets_descriptions += "---------------------------------- \n"
    return used_datasets_descriptions

class SqlRetrieverTool(BaseTool):
    name = "SQL retriever"
    description = "The SqlRetrieverTool is designed for retrieving data from SQL databases. It leverages filtering criteria to fetch specific records. It utilizes SQL queries to extract the first matching record based on the given filters."

    def _run(self, db_query: dict) -> Tuple[str, Any, List[List[dict[str, str]]], List]:
        connection_name = dataiku_api.webapp_config.get("sql_retrieval_connection")
        if connection_name is None:
            raise Exception("A SQL connection selection is required to run a query.")
        hard_sql_limit = dataiku_api.webapp_config.get("hard_sql_limit", 200)
        logger.debug(f"hard_sql_limit is set to {hard_sql_limit}")

        conn = dataiku.get_connection(connection_name)
        dialect = conn.conn_details["type"]
        executor = SQLExecutor2(connection=connection_name)
        select_query = SelectQuery()
        select_list = db_query["selectList"]

        if isinstance(select_list, List):
            select_query._query["selectList"] = select_list
        else:
            select_query._query["selectList"] = [{"expr": {"type": "COLUMN", "name": "*"}}]

        from_ = db_query["from"]
        if isinstance(from_, dict):
            select_query._query["from"] = from_
        else:
            raise Exception("A query must have 'from' statement")

        for key in ["with", "join", "where", "groupBy", "having", "orderBy"]:
            val = db_query[key]
            if isinstance(val, List):
                select_query._query[key] = val

        records = []
        limit = db_query["limit"]
        if isinstance(limit, int):
            if limit < hard_sql_limit:
                select_query._query["limit"] = limit
            else:
                records.append(
                    [
                        {
                            "WARNING!": f"The query exceeded the query limit of {hard_sql_limit}. Some information may be missing. Warn the user!"
                        }
                    ]
                )
                select_query._query["limit"] = hard_sql_limit
        else:
            select_query._query["limit"] = hard_sql_limit

        sql_query = toSQL(select_query, dialect=dialect)
        logger.debug(f"Initial query: {sql_query}")
        sql_query, tables_used = correct_table_names(sql_query)
        logger.debug(f"Running SQL Query {sql_query}")
        df = executor.query_to_df(query=sql_query)
        df.fillna("", inplace=True)
        records = df.to_dict("records")

        used_dataset_descriptions = get_dataset_descriptions_from_table_names(tables_used)
        context = f"""
        SQL query executed
        {sql_query}
        Dataset Descriptions
        {used_dataset_descriptions}
        
        >response
        {records}
        """
        return context, sql_query, records[:10], tables_used

    def _arun(self, filter_dict: dict) -> dict:  # type: ignore
        raise NotImplementedError("This tool does not support async")
