
from typing import Dict

import dataiku
from backend.utils.dataiku_api import dataiku_api
from llm_assist.logging import logger


def compare_versions(version1, version2):
    # Split the version strings into parts
    parts1 = map(int, version1.split('.'))
    parts2 = map(int, version2.split('.'))

    # Compare each part
    for part1, part2 in zip(parts1, parts2):
        if part1 < part2:
            return -1
        elif part1 > part2:
            return 1
    # If all parts are equal, the versions are equal
    return 0


def get_llm_capabilities() -> Dict[str, bool]:
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config["llm_id"]
    multi_modal, streaming = False, False
    client = dataiku.api_client()
    dss_version = client.get_instance_info().raw.get('dssVersion', '0.0.0')
    if dss_version == "0.0.0":
        logger.warn("Could not retrieve DSS version")
    # Split the llm_id to extract the connection type and model
    parts = llm_id.split(":")
    if len(parts) >= 3:
        connexion, _, model = parts[:3]
        streaming = (connexion == "openai" and model.startswith("gpt")) or (connexion == "bedrock" and any(
            model.startswith(prefix) for prefix in ["amazon.titan-", "anthropic.claude-"])) or (connexion == "azureopenai" and compare_versions(dss_version, "12.6.2") >= 0)
        multi_modal = (connexion == "openai" and (model == "gpt-4-vision-preview" or model == "gpt-4o")) or (
            connexion == "vertex" and model == "gemini-pro-vision") or (connexion == "bedrock" and model.startswith("anthropic.claude-3") and compare_versions(dss_version, "13.0.2") >= 0)
    if compare_versions(dss_version, "12.5.0") >= 0:
        return {"multi_modal": multi_modal, "streaming": streaming}
    else:
        return {"multi_modal": False, "streaming": False}


def get_llm_completion():
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id")
    llm = dataiku.api_client().get_default_project().get_llm(
        llm_id)
    completion = llm.new_completion()
    completion.settings["maxOutputTokens"] = 2048
    return completion
