from typing import Any

from backend.models.base import RETRIEVAL_MODE


class APIResponseProcessor:
    def __init__(self, api_response: dict):
        self.api_response = api_response
        self.validate_response()

    def validate_response(self):
        """Validates the structure and content of the incoming JSON."""
        if not isinstance(self.api_response, dict):
            raise ValueError("API response must be a dictionary.")

        # Check for required keys
        required_keys = ["query", "conversation_id"]

        for key in required_keys:
            if key not in self.api_response:
                raise ValueError(f"Missing key in API response: {key}")

    def extract_query(self) -> Any:
        """Extracts the main query from the API response."""
        return self.api_response.get("query", "")
    
    def extract_query_index(self) -> Any:
        """Extracts the discussion query index from the API response."""
        return self.api_response.get("query_index", "")

    def extract_conversation_id(self) -> Any:
        """Extract the current conversation id"""
        return self.api_response.get("conversation_id", None)

    def extract_record_id(self) -> Any:
        """Extract the current record id"""
        return self.api_response.get("record_id", None)

    def extract_filters(self) -> Any:
        return self.api_response.get("filters", None)

    def extract_file_path(self) -> Any:
        return self.api_response.get("file_path", None)

    def extract_user_profile(self) -> Any:
        return self.api_response.get("user_profile", None)
    
    def extract_knowledge_bank_id(self) -> Any:
        """Extracts the knowledge bank id from the API response."""
        # TODO: this is a temp fix for the current logging dataset schema
        retrieval_selection =  self.api_response.get("retrieval_selection")
        if retrieval_selection:
            kb_id = [ret.get("source") for ret in retrieval_selection if ret.get('type') == RETRIEVAL_MODE.KB.value]
            if len(kb_id) > 0:
                return kb_id[0]
        return None
    
    def extract_retrieval_enabled(self) -> Any:
        """Extracts if the knowledge bank is enabled or not from the API response."""
        return self.api_response.get("retrieval_enabled")
    
    def extract_answer(self) -> Any:
        return self.api_response.get("answer", "")
    
    def extract_sources(self) -> Any:
        return self.api_response.get("sources", [])

    def extract_retrieval_selection(self) -> Any:
        return self.api_response.get("retrieval_selection")


class APIConvTitleRequestProcessor:
    def __init__(self, api_response: dict):
        self.api_response = api_response
        self.validate_response()

    def validate_response(self):
        if not isinstance(self.api_response, dict):
            raise ValueError("API response must be a dictionary.")
        required_keys = ["query", "answer"]
        for key in required_keys:
            if key not in self.api_response:
                raise ValueError(f"Missing key in API response: {key}")

    def extract_query(self) -> Any:
        """Extracts the main query from the API response."""
        return self.api_response.get("query", "")

    def extract_answer(self) -> Any:
        return self.api_response.get("answer", "")


class APIGeneralFeedbackRequestProcessor:
    def __init__(self, api_response: dict):
        self.api_response = api_response
        self.validate_response()

    def validate_response(self):
        if not isinstance(self.api_response, dict):
            raise ValueError("API response must be a dictionary.")
        required_keys = ["message"]
        for key in required_keys:
            if key not in self.api_response:
                raise ValueError(f"Missing key in API response: {key}")

    def extract_message(self) -> Any:
        """Extracts the feedback message from the API response."""
        return self.api_response.get("message", "")

    def extract_knowledge_bank_id(self) -> Any:
        """Extracts the knowledge bank id from the API response."""
        return self.api_response.get("knowledge_bank_id", None)
