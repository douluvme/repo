import base64
import time
from typing import Dict

import dataiku
from backend.utils.dataiku_api import dataiku_api
from flask import Blueprint, g, request
from llm_assist.logging import logger
from werkzeug.utils import secure_filename

from ..utils import before_request, return_ko, return_ok

file_blueprint = Blueprint("file", __name__, url_prefix="/file")


@file_blueprint.before_request
def before_upload_request():
    before_request()


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_SIZE_MB = 15 # 15MB limit
MAX_CONTENT_LENGTH = MAX_SIZE_MB * 1024 * 1024  


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@file_blueprint.route("/upload", methods=["POST"])
def upload_file():
    """
    Upload file to a managed folder selected in webapp settings
    Returns:
        Response: A Flask response object containing the upload data.
    """
    logger.info(f"upload file")
    auth_identifier = g.get("authIdentifier")

    try:
        if 'image' not in request.files:
            raise Exception('No file part')

        file = request.files['image']   
  
        if file.filename == '':
            raise Exception('No selected file')

        if file and allowed_file(file.filename):
            config: Dict[str, str] = dataiku_api.webapp_config
            filename = secure_filename(
                f"{auth_identifier}_{int(time.time())}_{file.filename}")
            
            dataiku.Folder(config.get("upload_folder")
                           ).upload_stream(filename, file)
            file.seek(0)   
            file_data = file.read()
            b64_image = base64.b64encode(file_data).decode('utf-8')
            return return_ok(data={'file_path': filename, 
                                   'uploaded_image':f"data:image/png;base64,{b64_image}" }), 200

        raise Exception('Invalid file type or size')

    except Exception as e:
        logger.error(f"Error occurred wile uploading file: {e}")
        return return_ko(str(e)), 400


@file_blueprint.route("/delete", methods=["POST"])
def delete_file():
    # Delete a specific file from the managed folder
    request_as_json = request.get_json()
    try:
        file_path = request_as_json["file_path"]
        config: Dict[str, str] = dataiku_api.webapp_config
        upload_folder = config["upload_folder"]
        managedFolder = dataiku.Folder(upload_folder)
        managedFolder.delete_path(file_path)
        return return_ok(), 200
    except Exception as e:
        logger.error(f"Error occurred wile deleting file: {e}")
        return return_ko("Error occurred wile deleting file"), 400
