import json
from backend.utils.dataiku_api import dataiku_api
from typing import Any, List, Dict, Union, Optional
from backend.utils.source import map_sources
from langchain.chains import ConversationChain, ConversationalRetrievalChain
from llm_assist.logging import logger
from langchain.memory import ConversationBufferMemory, ConversationBufferWindowMemory
from backend.utils.dataiku_api import dataiku_api
from llm_assist.llm_api_handler import llm_setup
from langchain.schema.document import Document
from langchain.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate
)
from backend.models.base import LlmHistory, Source
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from .knowledge_bank import extract_knowldge_params
from dataiku.core.knowledge_bank import KnowledgeBank
from backend.db.base import CONVERSATION_DEFAULT_NAME
from backend.utils.knowledge_filters import get_current_filter_config
from functools import lru_cache
import dataiku
import base64
from dataikuapi.utils import DataikuException


class LLM_Question_Answering:
    """LLM_Question_Answering: A class to facilitate the question-answering process using LLM model"""

    def __init__(self, memory_max_token_limit, llm):
        self.project = dataiku_api.default_project
        self.memory_max_token_limit = (memory_max_token_limit,)
        self.llm = llm
        self.knowledge_params = extract_knowldge_params()

        self.memory = ConversationBufferMemory(
            max_token_limit=memory_max_token_limit, return_messages=True
        )

        self.filters_config = get_current_filter_config()

    def get_knwoledge_bank_full_name(self, knowledge_bank_id):
        if knowledge_bank_id:
            knwoledge_bank = KnowledgeBank(
                knowledge_bank_id, project_key=dataiku_api.default_project_key
            )
            return knwoledge_bank.full_name
        else:
            return None

    def update_memory(self, chat_history: List[LlmHistory]) -> None:
        self.memory.clear()
        for item in chat_history:
            inputs = {"input": item["input"]}
            outputs = {"output": item["output"]}

            logger.debug(f"The memory inputs {inputs}")
            logger.debug(f"The memory outputs {outputs}")

            self.memory.save_context(inputs, outputs)

    def __verify_filters(
        self, filters: Dict[str, List[Any]]
    ) -> Optional[Dict[str, List[Any]]]:
        if not filters or not self.filters_config:
            return None
        verified_columns = [
            col
            for col in filters.keys()
            if col in self.filters_config["filter_columns"]
        ]
        verified_filters = {}
        for col in verified_columns:
            verified_values = [
                value
                for value in filters[col]
                if value in self.filters_config["filter_options"][col]
            ]

            verified_filters[col] = verified_values[0] if len(
                verified_values) == 1 else verified_values

        return verified_filters

    def run_llm_with_media(self,
                           act_like_prompt: str,
                           user_question: str,
                           file_path: str,
                           chat_history: List[LlmHistory] = [],
                           filters: Optional[Dict[str, List[Any]]] = None,
                           knowledge_bank_id: str = None) -> Any:
        """
        Run the LLM with the provided query and file.

        Args:
            query (str): The query string.
            file_path (str): The file path uploaded into a managed folder

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        response = ""

        try:
            config: Dict[str, str] = dataiku_api.webapp_config
            upload_folder: str = config.get("upload_folder")
            file_folder = dataiku.Folder(upload_folder)
            with file_folder.get_download_stream(file_path) as stream:
                file_content = stream.read()
            base64_encoded = base64.b64encode(file_content)
            img_b64 = base64_encoded.decode('utf-8')
            llm_id = config.get("llm_id")
            llm = dataiku.api_client().get_default_project().get_llm(
                llm_id)
            completion = llm.new_completion()
            completion.cq["messages"].append({
                "role": "user",
                "parts": [
                    {"type": "TEXT", "text": user_question},
                    {"type": "IMAGE_INLINE", "inlineImage": img_b64}
                ]
            })
            completion.settings["maxOutputTokens"] = 2048
            resp = completion.execute()
            if resp.success:
                response = resp.text
            else:
                logger.error(f"Multimodal completion call failed: resp._raw")
                response = resp._raw
        except DataikuException as e:
            logger.error(f"Dataiku API Error: {e}")
        except FileNotFoundError:
            logger.error("File not found in the managed folder.")
        except IOError as e:
            logger.error(f"I/O Error: {e}")
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")

        return response

    def run_llm(
        self,
        act_like_prompt: str,
        user_question: str,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        knowledge_bank_id: str = None
    ) -> Any:
        """
        Run the LLM with the provided query and chat history.

        Args:
            act_like_prompt (str): The configured settings prompt.
            user_question (str): The user query string
            chat_history (List[LlmHistory], optional): List of chat histories,
                                                           where each chat history is
                                                           represented as a dictionary with
                                                           inputs and outputs. Defaults to [].
            filters (Optional[Dict[str, List[Any]]]): Selected filters to be applied
            knowledge_bank_id: The knowledge bank DSS id 

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        self.update_memory(chat_history=chat_history)

        logger.info(f"The act like prompt is: {act_like_prompt}")
        if not knowledge_bank_id:

            template = r"""The following is a friendly conversation between a human and an AI. The AI is talkative and provides lots of specific details from its context. If the AI does not know the answer to a question, it truthfully says it does not know.
            {act_like_prompt}
            Current conversation:
            {{history}}
            Human: {{input}}
            AI Assistant:""".format(act_like_prompt=act_like_prompt)
            qa_prompt = PromptTemplate(
                input_variables=["history", "input"], template=template)

            qa = ConversationChain(
                llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)
            return qa.predict(input=user_question)
        else:
            general_retrieval_template = r""" 
            {act_like_prompt}
            
            Given the following specific context, please give a short answer to the question at the end, If you don't know the answer, just say that you don't know, don't try to make up an answer. 
            ### CONTEXT
            ----
            {{context}}
            ----
            """.format(act_like_prompt=act_like_prompt)
            general_user_template = """
            This is the question I am asking provided the given context: 
            ### QUESTION:
            {question}
            """

            messages = [
                SystemMessagePromptTemplate.from_template(
                    general_retrieval_template),
                HumanMessagePromptTemplate.from_template(general_user_template)
            ]
            qa_prompt = ChatPromptTemplate.from_messages(messages)

            retriever = self.get_retriever(
                filters=filters, knowledge_bank_id=knowledge_bank_id)
            qa = ConversationalRetrievalChain.from_llm(
                llm=self.llm,
                retriever=retriever,
                return_source_documents=True,
                verbose=True,
                condense_question_llm=self.llm,
                chain_type="stuff",
                combine_docs_chain_kwargs={'prompt': qa_prompt}
            )
            formatted_history = [
                (item["input"], item["output"]) for item in chat_history
            ]
            logger.debug(f" user_question: {user_question}")
            response = qa(
                {"question": user_question, "chat_history": formatted_history})
            return response

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any]],
        filters: Optional[Dict[str, List[Any]]] = None,
    ) -> Dict[str, Any]:
        if isinstance(generated_answer, str):
            return {"answer": generated_answer, "sources": [], "filters": filters}
        else:
            if isinstance(generated_answer, dict):
                source_documents: List[Document] = generated_answer.get(
                    "source_documents", []
                )
                answer = generated_answer.get("answer", "")
                sources = [
                    dict(
                        Source(
                            excerpt=document.page_content, metadata=document.metadata
                        )
                    )
                    for document in source_documents
                ]

                sources = map_sources(sources)

                return {"answer": answer, "sources": sources, "filters": filters}
            else:
                return None

    def transform_filters_for_pinecone(self, filters):
        transformed_filters = []
        for key, value in filters.items():
            if isinstance(value, list):
                or_condition = {'$or': [{key: v} for v in value]}
                transformed_filters.append(or_condition)
            else:
                transformed_filters.append({key: value})

        return {'$and': transformed_filters} if len(transformed_filters) > 1 else transformed_filters[0]

    def transform_filters_for_chroma_db(self, filters):
        transformed_filters = []

        for key, value in filters.items():
            if isinstance(value, list):
                or_filter = {'$or': [{key: v} for v in value]}
                transformed_filters.append(or_filter)
            else:
                transformed_filters.append({key: value})

        if len(transformed_filters) > 1:
            return {'$and': transformed_filters}
        elif len(transformed_filters) == 1:
            return transformed_filters[0]
        else:
            raise ValueError("No valid filters provided.")

    def process_filters_for_db(self, filters, vector_db_type):
        logger.debug(f"processing filters for {vector_db_type}")
        if vector_db_type == 'CHROMA':
            return self.transform_filters_for_chroma_db(filters)
        elif vector_db_type == 'FAISS':
            return filters
        elif vector_db_type == 'PINECONE':
            return self.transform_filters_for_pinecone(filters)
        else:
            raise ValueError(
                f"Unsupported database type for filtering: {vector_db_type}")

    @lru_cache(maxsize=None)
    def get_vector_db_type(self, knowledge_bank_id: str = None):
        if knowledge_bank_id:
            return self.project.get_knowledge_bank(knowledge_bank_id).as_core_knowledge_bank()._get()['vectorStoreType']

        return None

    def get_answer_and_sources(
        self,
        prompt: str,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        knowledge_bank_id=None,
        file_path: str = None
    ) -> Any:
        """Extracts the answer and its corresponding sources for a given prompt.

        Args:
            prompt (str): The question or prompt string.
            chat_history (List[LlmHistory]): A list of prior interactions (optional). Each interaction
                is a dictionary with the question and response.
            filters (Optional[Dict[str, List[Any]]]): A dictionary of filters to apply to the knowledge bank.
            knowledge_bank_id (str): The knowledge bank DSS id
            file_path (str): The file path uploaded into a managed folder

        Returns:
            Dict[str, Union[str, Dict[str, Any]]]: A dictionary containing:
                - 'answer' (str): The generated answer to the prompt.
                - 'sources' (List[Dict]): A list of dict:
                    - 'excerpt' (str): The content of the source.
                    - 'metadata' (Dict[str, str]): Additional metadata about the source.
        """

        logger.info("Generating response")

        act_like_prompt = ""
        if knowledge_bank_id:
            act_like_prompt = dataiku_api.webapp_config.get(
                "knowledge_bank_prompt", "")
        else:
            act_like_prompt = dataiku_api.webapp_config.get(
                "primer_prompt", "")

        vector_db_type = self.get_vector_db_type(knowledge_bank_id)
        verified_filters = filters
        if vector_db_type and filters and len(filters) > 0:
            verified_filters = self.process_filters_for_db(
                self.__verify_filters(filters=filters), vector_db_type)
        logger.debug(
            f"vector_db_type:{vector_db_type}   / filters: {verified_filters}")

        if file_path:
            generated_response = self.run_llm_with_media(act_like_prompt=act_like_prompt,
                                                         user_question=prompt,
                                                         chat_history=chat_history,
                                                         filters=verified_filters,
                                                         knowledge_bank_id=knowledge_bank_id,
                                                         file_path=file_path)
        else:
            generated_response = self.run_llm(
                act_like_prompt=act_like_prompt,
                user_question=prompt,
                chat_history=chat_history,
                filters=verified_filters,
                knowledge_bank_id=knowledge_bank_id,
            )

        return self.get_as_json(generated_response, filters=verified_filters)

    def get_search_kwargs(self, filters: Dict[str, List[Any]] = None):
        search_type = self.knowledge_params["search_type"]
        if search_type == "mmr":
            result = {
                "k": self.knowledge_params["k"],
                "fetch_k": self.knowledge_params["mmr_k"],
                "lambda_mult": self.knowledge_params["mmr_diversity"],
            }
        elif search_type == "similarity_score_threshold":
            result = {
                "k": self.knowledge_params["k"],
                "score_threshold": self.knowledge_params["score_threshold"],
            }
        else:
            result = {"k": self.knowledge_params["k"]}
        if filters:
            result["filter"] = filters
        logger.info('Search kwargs: ', result)
        return result

    def get_retriever(self, filters: Dict[str, List[Any]] = None, knowledge_bank_id: str = None):
        search_type = self.knowledge_params["search_type"]
        logger.debug('Search type:', search_type)
        retriever = KnowledgeBank(
            knowledge_bank_id, project_key=dataiku_api.default_project_key
        ).as_langchain_retriever(
            search_type=search_type,
            search_kwargs=self.get_search_kwargs(filters=filters),
        )
        return retriever

    @staticmethod
    def get_conversation_title_prompt():
        template = """
            Given a user query and a generated answer, write a conversation title that is concise.

            The user query:
            {query}

            The generated text:
            {answer}

            Conditions:
            - Don't wirte a title that contains more than 6 words
        """
        prompt = PromptTemplate.from_template(template)
        return prompt

    def get_conversation_title(self, query: str, answer: str):
        chain = LLMChain(
            llm=self.llm, prompt=LLM_Question_Answering.get_conversation_title_prompt()
        )
        result = chain.run(query=query, answer=answer)
        json_answer = self.get_as_json(result)

        return json_answer.get("answer", CONVERSATION_DEFAULT_NAME)


memory_max_token_limit = int(
    dataiku_api.webapp_config.get("memory_token_limit", 2000))

llm_qa = LLM_Question_Answering(memory_max_token_limit, llm_setup.get_llm())
