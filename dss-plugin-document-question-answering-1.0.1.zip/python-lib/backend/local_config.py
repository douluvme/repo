from backend.utils.dataiku_api import dataiku_api
from logging.config import dictConfig
import os
import json
from datetime import datetime


year, date = datetime.now().strftime("%Y"), datetime.now().strftime("%Y-%m-%d")

# Replace by your default project key that you are working on in dev
DEFAULT_PROJECT_KEY = "CHATBOXPOC"
LOGGING_DATASET = "chat_logs"
FEEDBACK_DATASET = "general_feedbacks"
KNOWLEDGE_BANK_ID = "8v41yY7i"
UPLOAD_OLDER_ID = "Pqp7YkjT"

# TODO : Add dip_home to a .env file
CONFIG = {
    # put your webapp desired config
    "webapp_config": {
        "primer_prompt": f"You are a general purpose assistant, be as concise as possible, The current Year is {year}. The current Date is {date} ",
        "memory_token_limit": 8000,
        "web_app_title": "Ask directly questions to your document corpus",
        "web_app_subheading": "Answers are sourced from the processed documents, delivered in natural language and accompanied by the most relevant references.",
        "example_question_1": "What are the primary causes of the recent increase in global temperatures?",
        "example_question_2": "How does quantum computing differ from classical computing in terms of processing information?",
        "example_question_3": "Whats the most popular language globally?",
        "language": "en",
        "llm_configuration": {
            "mode": "PRESET",
            "name": "RL GPT 35"
        },
        "logging_dataset": LOGGING_DATASET,
        "feedback_positive_choices": [],
        "feedback_negative_choices": [],
        "general_feedback_dataset": FEEDBACK_DATASET,
        "knowledge_retrieval_k": 20,
        "knowledge_retrieval_search_type": "similarity",
        "knowledge_retrieval_mmr_k": 20,
        "knowledge_retrieval_mmr_diversity": 0.25,
        "knowledge_retrieval_score_threshold": 0.8,
        "web_app_input_placeholder": "Ask your question",
        "knowledge_bank_id": KNOWLEDGE_BANK_ID,
        "activate_knowledge_bank": False,
        "knowledge_bank_prompt": f"""You are RL Chat, an AI Assistant for RalphLauren built by the RL Analytics Team! You are built to help the Procurement team with queries related to contracts and also provide general information outside of the context for other vendors and companies that RL may contract with from your knowledge. You can also respond to general queries related to the procurement process and provide language support. You can also access information about companies other than Ralph Lauren. 
Guidelines for you to strictly follow based on user queries. The current Year is {year}. The current Date is {date} .
1. Your responses should be specific to the questions and respond professionally.
2. Avoid any Personally Identifiable Info like names in your responses. 
3. If you don't have the info say "You don't have it". Do not apologize for not having information.
4. Avoid preambles like "Based on the context provided" instead jump straight to the response.
5. You do not have access to the web/internet and you do not have information on real-time events, news, and weather.""",
        "llm_id": "openai:solutions-openai:gpt-4-vision-preview",
        "knowledge_sources_filters": ["file"],
        "knowledge_sources_displayed_metas": ["file"],
        "knowledge_source_url": False,
        "knowledge_source_title": False,
        "knowledge_source_thumbnail": False,
        "permanent_delete": True,
        "upload_folder": UPLOAD_OLDER_ID,
        'log_level': 'INFO',
        "disclaimer": "This application is powered by a Large Language Model. Review proposed outcomes in context with \u003cspan style\u003d\"color: #267cfb; text-decoration: underline\"\u003eResponsible AI\u003c/span\u003e considerations",
        "http_headers": [
            {
                "from": "Content-Security-Policy",
                "to": "frame-ancestors \u0027self\u0027;"
            },
            {
                "from": "Strict-Transport-Security",
                "to": "max-age\u003d31536000; includeSubDomains"
            },
            {
                "from": "X-Frame-Options",
                "to": "SAMEORIGIN"
            },
            {
                "from": "X-Content-Type-Options",
                "to": "nosniff"
            }
        ],
        "filter_logged_sources": True,
        "n_top_sources_to_log": 10

    },
    "default_project_key": DEFAULT_PROJECT_KEY,
}


os.environ["DKU_CURRENT_PROJECT_KEY"] = CONFIG.get("default_project_key")
os.environ["DKU_CUSTOM_WEBAPP_CONFIG"] = json.dumps(
    CONFIG.get("webapp_config"))


def get_setup_for_dataiku_client():
    return {
        "webapp_config": CONFIG.get("webapp_config"),
        "default_project_key": CONFIG.get("default_project_key"),
    }


dictConfig(
    {
        "version": 1,
        "formatters": {
            "default": {
                "format": "[%(asctime)s] %(levelname)s in %(module)s: %(message)s",
            }
        },
        "handlers": {
            "wsgi": {
                "class": "logging.StreamHandler",
                "stream": "ext://flask.logging.wsgi_errors_stream",
                "formatter": "default",
            }
        },
        "root": {"level": "INFO", "handlers": ["wsgi"]},
    }
)


def setup_dataiku_client():
    dataiku_setup = get_setup_for_dataiku_client()
    dataiku_api.setup(**dataiku_setup)
