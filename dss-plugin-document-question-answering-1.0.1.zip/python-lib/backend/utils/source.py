from llm_assist.logging import logger
from backend.models.base import Source
from backend.utils.dataiku_api import dataiku_api
from backend.utils.metas_utils import is_string_list_representation, convert_to_list


def map_sources(sources):
    new_sources = []
    config = dataiku_api.webapp_config

    for source in sources:
        # Initialize default values for title, url, and thumbnail
        source_title = ""
        source_url = ""
        source_thumbnail_url = ""
              
        if config["knowledge_source_title"] in source["metadata"]:
            source_title = source["metadata"][config["knowledge_source_title"]]

        if config["knowledge_source_url"] in source["metadata"]:
            source_url = source["metadata"][config["knowledge_source_url"]]

        if config["knowledge_source_thumbnail"] in source["metadata"]:
            source_thumbnail_url = source["metadata"][config["knowledge_source_thumbnail"]]

        new_source = Source(
            excerpt= source["excerpt"],
            metadata= {"source_title": source_title,
                       "source_url": source_url,
                       "source_thumbnail_url": source_thumbnail_url,
                       "tags": []
                       }
        )

        for meta in config["knowledge_sources_displayed_metas"]:
            value = source["metadata"].get(meta, None)
            if value is not None:
                if is_string_list_representation(value):
                    value = convert_to_list(value)
                    value_type = "list"
                else:
                    value_type = "string"

                new_source["metadata"]["tags"].append({
                    "name": meta,
                    "value": value,
                    "type": value_type
                })

        new_sources.append(new_source)

    return new_sources


def filter_sources_for_chat_logs(initial_sources: list, n_sources_to_keep: int=-1, varchar_limit: int=None):
    """
    Filters the sources passed to the Chat logs dataset, in order to prevent database varachar limit issues and/or optimize storage.

    :param initial_sources: list: The initial soucres passed to the function.
    :param n_sources_to_keep: int: The number of sources to filter from the initial sources. Set '-1' to keep all the sources.
    :param varchar_limit: int: The varchar limit of the connection used in the context of the webapp.

    :returns: final_sources: list: The sources filtered from the initial_sources.
    :returns: sources_has_been_filtered: bool: Precises whether some sources has been filtered or not
    """

    def get_sources_column_size_in_chat_logs_dataset(sources_to_format):
        sources_column_size = len(str({"sources": sources_to_format}))
        return sources_column_size
    
    n_initial_sources = len(initial_sources)

    if n_sources_to_keep == -1:
        final_sources = initial_sources
    else:
        final_sources = [
            source for loop_index, source in enumerate(initial_sources)
            if loop_index < n_sources_to_keep
            ]
    
    if isinstance(varchar_limit, int):
        sources_column_size = get_sources_column_size_in_chat_logs_dataset(final_sources)
        if sources_column_size >= varchar_limit:
            final_sources_respecting_characters_limit = []
            for source in final_sources:
                sources_column_size = get_sources_column_size_in_chat_logs_dataset(final_sources_respecting_characters_limit+[source])
                if sources_column_size < varchar_limit:
                    final_sources_respecting_characters_limit.append(source)
            final_sources = final_sources_respecting_characters_limit

    n_final_sources = len(final_sources)
    n_sources_filtered = n_initial_sources - n_final_sources
    sources_has_been_filtered = (n_sources_filtered >0)
    if sources_has_been_filtered:
        logger.info(f"{n_sources_filtered}/{n_initial_sources} sources has been filtered for the chat logs dataset.")
    else:
        logger.info(f"No sources has been filtered for the chat logs dataset.")

    return final_sources, sources_has_been_filtered