def load_n_top_sources_to_log(config):
    """
    Loads the parameter 'n_top_sources_to_log' based on the webapp configuration.

    :param config: dict: Webapp configuration.

    :returns: n_top_sources_to_log: int: The number of sources to log based on the webapp configuration
    """
    filter_logged_sources = config["filter_logged_sources"]
    if filter_logged_sources:
        n_top_sources_to_log = config["n_top_sources_to_log"]

    else:
        n_top_sources_to_log = -1
    return n_top_sources_to_log