from flask import Flask, g, request
from flask_cors import CORS
from backend.utils.dataiku_api import dataiku_api
from llm_assist.logging import logger


def run_create_app(app: Flask):
    from backend.routes import api

    CORS(app)

    app.register_blueprint(api)

    @app.after_request
    def apply_security_headers(response):
        config = dataiku_api.webapp_config
        http_headers = config.get("http_headers", [])
        for header in http_headers:
            response.headers[header["from"]] = header["to"]
        return response
    return app
