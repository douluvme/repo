from flask import Blueprint, Response, request
from typing import Dict, List, Union, Any
from backend.utils.dataiku_api import dataiku_api
from backend.utils.knowledge_filters import get_current_filter_config, get_knowledge_bank_name
from ..utils import return_ok
from llm_assist.logging import logger
import dataiku
import dataikuapi
import requests
config_blueprint = Blueprint("config", __name__, url_prefix="/config")


def format_feedback_choices(choices: List[Any]):
    choices_final = []
    for choice in choices:
        try:
            choices_final.append(str(choice))
        except Exception as e:
            logger.warning("choice can't be parsed to str")
    return choices_final

def compare_versions(version1, version2):
    # Split the version strings into parts
    parts1 = map(int, version1.split('.'))
    parts2 = map(int, version2.split('.'))
    
    # Compare each part
    for part1, part2 in zip(parts1, parts2):
        if part1 < part2:
            return -1
        elif part1 > part2:
            return 1
    # If all parts are equal, the versions are equal
    return 0
def get_llm_capabilities() -> Dict[str, bool]:
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id")
    multi_modal, streaming = False, False
    # Split the llm_id to extract the connection type and model
    parts = llm_id.split(":")
    settings = dataiku.get_dss_settings()
    dss_version = settings["version"]["product_version"]

    if len(parts) >= 3:
        connexion, _, model = parts[:3]
        streaming = connexion == "openai" or (connexion == "bedrock" and any(
            model.startswith(prefix) for prefix in ["amazon.titan-", "anthropic.claude-"]))
        multi_modal = (connexion == "openai" and model == "gpt-4-vision-preview") or (
            connexion == "vertex" and model == "gemini-pro-vision")
    if compare_versions(dss_version, "12.5.0") >= 0:
        return {"multi_modal": multi_modal, "streaming": streaming}
    else:
        return {"multi_modal": False, "streaming": False}


def get_user(headers):
    try:
        auth_info = dataiku.api_client().get_auth_info_from_browser_headers(headers)
        user = auth_info["authIdentifier"]
    except (dataikuapi.utils.DataikuException, requests.exceptions.HTTPError) as e:
        print(f"Exception occurred: {str(e)}")
        user = "user_not_found"
    return user


@config_blueprint.route("/get_ui_setup", methods=["GET"])
def get_ui_setup() -> Response:
    """
    Fetches the configuration settings for UI setup from Dataiku and returns them.

    Returns:
        Response: A Flask response object containing the UI setup data.
    """
    config: Dict[str, str] = dataiku_api.webapp_config
    examples: List[str] = [
        config.get("example_question_1"),
        config.get("example_question_2"),
        config.get("example_question_3"),
    ]
    title: str = config.get("web_app_title")
    subtitle: str = config.get("web_app_subheading")
    lang: str = config.get("language", "en")
    placeholder: str = config.get("web_app_input_placeholder", "")
    feedback_positive_choices: List[str] = format_feedback_choices(
        config.get("feedback_positive_choices", [])
    )
    feedback_negative_choices: List[str] = format_feedback_choices(
        config.get("feedback_negative_choices", [])
    )
    filters_config = get_current_filter_config()
    knowledge_bank_id = config.get("knowledge_bank_id", None)
    activate_knowledge_bank = config.get("activate_knowledge_bank", True)

    knowledge_bank_name = get_knowledge_bank_name(knowledge_bank_id)
    knowledge_bank_custom_name = config.get("knowledge_bank_custom_name", None)
    llm_caps = get_llm_capabilities()
    headers = dict(request.headers)
    disclaimer = config.get("disclaimer", "")
    result: Dict[str, Union[str, List[str], bool]] = {
        "examples": examples,
        "title": title,
        "subtitle": subtitle,
        "language": lang,
        "input_placeholder": placeholder,
        "project": dataiku_api.default_project_key,
        "upload_folder_id": config.get("upload_folder"),
        "feedback_negative_choices": feedback_negative_choices,
        "feedback_positive_choices": feedback_positive_choices,
        "filters_config": filters_config,
        "knowledge_bank": {"knowledge_bank_id": knowledge_bank_id, "knowledge_bank_name": knowledge_bank_name, "activate": activate_knowledge_bank, "knowledge_bank_custom_name": knowledge_bank_custom_name} if knowledge_bank_id else None,
        "llm_capabilities": llm_caps,
        "llm_id": config.get("llm_id"),
        "user": get_user(headers),
        "allow_general_feedback": config.get("allow_general_feedback", False),
        "disclaimer": disclaimer,
    }
    return return_ok(data=result)
