from flask import Blueprint, request, g
from ..utils import return_ok, before_request
from .api_response_handler import APIResponseProcessor
from backend.utils.dataiku_api import dataiku_api
import dataiku
from llm_assist.logging import logger
from flask import Blueprint, request, Response
from typing import Dict, Union, List, Any
from solutions.service import llm_qa
from typing import Optional
from backend.models.base import LlmHistory, QuestionData
from backend.db.base import conversation_sql_manager, CONVERSATION_DEFAULT_NAME
from backend.models.base import ConversationInfo

answer_blueprint = Blueprint("answer", __name__, url_prefix="/answer")


@answer_blueprint.before_request
def before_answer_request():
    before_request()


@answer_blueprint.route("/get_answer", methods=["POST"])
def get_answer() -> Response:
    """
    Extracts the user query from the request payload and returns an appropriate answer.

    Returns:
        Response: A Flask response object containing the answer data.
    """

    request_json: Dict[str, Union[str, List[str]]] = request.get_json()
    logger.info(f"Payload from the front end is {request_json}")

    api_response_handler: APIResponseProcessor = APIResponseProcessor(
        api_response=request_json
    )

    auth_identifier = g.get("authIdentifier")
    conversation_id: Optional[str] = api_response_handler.extract_conversation_id(
    )
    query: str = api_response_handler.extract_query()

    filters: Optional[Dict[str, List[Any]]
                      ] = api_response_handler.extract_filters()

    file_path: Optional[str] = api_response_handler.extract_file_path()
    
    # Get Llm history from cache
    history: List[LlmHistory] = []
    if conversation_id:
        history = conversation_sql_manager.get_conversation_history(
            auth_identifier=auth_identifier, conversation_id=conversation_id
        )

    knowledge_bank_id: Optional[str] = api_response_handler.extract_knowledge_bank_id(
    )

    result: Dict[str, str] = llm_qa.get_answer_and_sources(
        query, history, filters=filters, knowledge_bank_id=knowledge_bank_id, file_path=file_path
    )

    # update cache onversation
    new_history_record = QuestionData(
        id=len(history),
        query=query,
        filters=filters,
        file_path=file_path,
        answer=result["answer"],
        sources=result["sources"],
        feedback=None,
    )
    conversation_name = CONVERSATION_DEFAULT_NAME

    if not conversation_id:
        conversation_name = llm_qa.get_conversation_title(
            new_history_record["query"], new_history_record["answer"]
        )

    knwoldge_bank_full_id = llm_qa.get_knwoledge_bank_full_name(
        knowledge_bank_id)
    
    ## Get llm id
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id", None)

    record_id, conversation_infos = conversation_sql_manager.add_record(
        dict(new_history_record),
        auth_identifier,
        conversation_id,
        conversation_name,
        knwoldge_bank_full_id,
        llm_id

    )

    return return_ok(
        data={
            "answer": new_history_record["answer"],
            "sources": new_history_record["sources"],
            "filters": new_history_record["filters"],
            "conversation_infos": conversation_infos,
            "record_id": record_id,
        }
    )
