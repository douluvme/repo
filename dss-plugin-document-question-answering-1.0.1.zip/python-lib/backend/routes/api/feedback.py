from datetime import datetime
import traceback
from flask import Blueprint, request, g
from ..utils import return_ok, before_request, return_ko
from .api_response_handler import APIGeneralFeedbackRequestProcessor, APIResponseProcessor
from backend.utils.dataiku_api import dataiku_api
import dataiku
from llm_assist.logging import logger
from flask import Blueprint, request, Response
from typing import Dict, Union, List, Any
from typing import Optional
from backend.db.general_feedback import feedbacks_sql_manager
from solutions.service import llm_qa

general_feedback_blueprint = Blueprint(
    "general_feedback", __name__, url_prefix="/general_feedback")


@general_feedback_blueprint.before_request
def before_general_feedback_request():
    before_request()


@general_feedback_blueprint.route("/submit", methods=["POST"])
def submit_general_feedback() -> Response:
    """
    Submits a general feedback from a user into feedbacks dataset

    Returns:
        Response: A Flask response object containing feedback submission status.
    """

    request_json: Dict[str, Union[str, List[str]]] = request.get_json()
    logger.info(f"Payload from the front end is {request_json}")

    api_response_handler: APIGeneralFeedbackRequestProcessor = APIGeneralFeedbackRequestProcessor(
        api_response=request_json
    )

    auth_identifier = g.get("authIdentifier")
    message: str = api_response_handler.extract_message()
    knowledge_bank_id: Optional[str] = api_response_handler.extract_knowledge_bank_id(
    )

    knwoldge_bank_full_id = llm_qa.get_knwoledge_bank_full_name(
        knowledge_bank_id)

    # Get llm id
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id", None)
    current_utc_timestamp = datetime.utcnow()

    try:
        feedbacks_sql_manager.add_feedback(
            current_utc_timestamp, auth_identifier, message, knwoldge_bank_full_id, llm_id)
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        traceback.print_exc()  # Print the full traceback
        return return_ko(f"An error occurred: {e}")
    return return_ok(
        data={"status": "ok"}
    )
