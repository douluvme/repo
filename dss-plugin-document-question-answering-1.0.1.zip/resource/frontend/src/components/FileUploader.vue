<template>
  <div style="display: inline-block">
    <q-icon :name="imageIconName" class="cursor-pointer" @click="triggerFileInput" size="sm">
      <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
       {{ $t('tooltip_image') }}
      </BsTooltip></q-icon
    >
    <input
      type="file"
      ref="fileInput"
      @change="handleFileChange"
      accept="image/png, image/jpeg"
      style="display: none"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import ImageIcon from '@/assets/icons/image-icon.svg'
import { useI18n } from 'vue-i18n';
const { t } = useI18n()

const imageIconName = `img:${ImageIcon}`

const emits = defineEmits(['update:status', 'uploadFile'])

const fileInput = ref<HTMLInputElement | null>(null)

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileChange = async (event: Event) => {
  const target = event.target as HTMLInputElement
  const file = target.files ? target.files[0] : null
  if (file) {
    // Validate file type (allow only PNG and JPEG)
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
      emits('update:status', {
        type: 'error',
        msg: 'invalid_file_type'
      })
      return
    }
    // Validate file size (no more than 1MB)
    if (file.size > 1048576) {
      // 1MB in bytes
      emits('update:status', { type: 'error', msg: 'too_large_file' })
      return
    }

    await uploadImage(file)
  }
}

const clearFileInput = () => {
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}
const uploadImage = async (file: File) => {
  const formData = new FormData()
  formData.append('image', file)
  emits('uploadFile', formData)
}

// Expose the clearFileInput method
defineExpose({
  clearFileInput
})
</script>
