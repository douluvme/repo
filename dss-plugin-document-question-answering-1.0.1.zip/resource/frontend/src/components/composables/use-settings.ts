import type { FilterConfig } from '@/models'
import { useLocalStorage } from './use-local-storage'

const { data: filtersSelections } = useLocalStorage<Record<string, any[]>>(`selected-filters`, {})
const { data: knowledgeBankSelection } = useLocalStorage<string>('selected-knowledge-bank', null)
export function useSettings() {
  function updateSettings(
    knowledgeBank?: { id: string; label: string } | null,
    filtersConfig?: FilterConfig | null
    ) {
    if (
      !knowledgeBank ||
      (knowledgeBankSelection.value &&
        knowledgeBank.id !== knowledgeBankSelection.value)
    ) {
      //Knowledge bank has changed we delete previously saved selection of filters and knowledge bank
      filtersSelections.value = null
      knowledgeBankSelection.value = null
    } else if (filtersSelections.value && filtersConfig) {
      let shouldBreak = false
      for (let key of Object.keys(filtersSelections.value)) {
        if (!filtersConfig.filter_columns.includes(key)) {
          // Filter has changed, delete previously saved selections
          filtersSelections.value = {}
          shouldBreak = true // Set flag to break the outer loop
          break
        } else {
          for (let op of filtersSelections.value[key]) {
            if (!filtersConfig.filter_options[key].includes(op)) {
              // Filter has changed, delete previously saved selections
              filtersSelections.value = {}
              shouldBreak = true // Set flag to break the outer loop
              break
            }
          }
          if (shouldBreak) break // Break the outer loop if needed
        }
      }
    }
  }
  return {
    filtersSelections,
    knowledgeBankSelection,
    updateSettings
  }
}
