import { ServerApi } from '@/api/server_api'
import i18n from '@/i18n'
import { ref, onMounted } from 'vue'
import type { FilterConfig } from '@/models'
import { useSettings } from './use-settings'
import { WT1iser } from '@/common/wt1'


interface UISetup {
  examples: string[]
  title?: string
  subtitle?: string
  questionPlaceholder?: string
  language?: string
  projectKey?: string
  docsFolderId?: string
  uploadFolderId?: string
  feedbackPositiveChoices?: string[]
  feedbackNegativeChoices?: string[]
  llmCapabilities?: { streaming: boolean; multiModal: boolean}
  llmId?: string
  filtersConfig?: FilterConfig | null
  knowledgeBank?: { id: string; label: string, activate: boolean, customLabel?: string } | null
  user?: string
  allowGeneralFeedback?: boolean
  disclaimer?: string
}

const infoTextOne = '“Lorem ipsum dolor sit amet, consectetur adipiscing elit”'
const infoTextTwo =
  '“Fusce pulvinar augue quis commodo pharetra, quisque mattis, diam ut tempor egestas”'
const infoTextThree =
  '“Maecenas augue nunc, fermentum ac placerat sed, eleifend eget odio. Nunc ut cursus felis”'

const initExamples = [infoTextOne, infoTextTwo, infoTextThree]

const initUISeup: UISetup = {
  examples: initExamples
}

const setup = ref<UISetup>(initUISeup)

export function useUI() {
  async function initializeUI() {
    try {
      const response = await ServerApi.getUISetup()
      if (response && response.data) {
        const uiSetup: UISetup = {
          examples: response.data.examples || [],
          title: response.data.title,
          subtitle: response.data.subtitle,
          questionPlaceholder: response.data.input_placeholder,
          projectKey: response.data.project,
          docsFolderId: response.data.docs_folder_id,
          uploadFolderId: response.data.upload_folder_id,
          feedbackPositiveChoices: response.data.feedback_positive_choices,
          feedbackNegativeChoices: response.data.feedback_negative_choices,
          filtersConfig: response.data.filters_config,
          knowledgeBank: response.data.knowledge_bank
            ? {
                id: response.data.knowledge_bank.knowledge_bank_id,
                label: response.data.knowledge_bank.knowledge_bank_name,
                activate: response.data.knowledge_bank.activate,
                customLabel: response.data.knowledge_bank.knowledge_bank_custom_name
              }
            : null,
          llmCapabilities: {
            streaming: response.data.llm_capabilities.streaming,
            multiModal: response.data.llm_capabilities.multi_modal,
          },
          llmId: response.data.llm_id,
          user: response.data.user,
          allowGeneralFeedback: response.data.allow_general_feedback,
          disclaimer: response.data.disclaimer,
          //filtersConfig: filtersConfigTest
        }
        if (Object.keys(i18n.global.messages).includes(response.data.language)) {
          // @ts-ignore
          i18n.global.locale = response.data.language
        }
        setup.value = uiSetup
      } else {
        throw new Error('Error initializing UI')
      }
    } catch (error) {
      WT1iser.actionError('initializeUI', null, 0, 'Error initializing UI')// TODO: Add error message
    }
  }
  function isSmallScreen() {
    return (
      window.innerWidth <= 600 ||
      (screen.orientation.type.indexOf('landscape') >= 0 &&
        window.innerWidth <= 1000 &&
        window.innerHeight <= 600)
    )
  }
  onMounted(async () => {
    await initializeUI()
    // Needed to update local storage settings when knowledge bank has changed
    useSettings().updateSettings(setup.value.knowledgeBank, setup.value.filtersConfig)
  })

  return {
    initializeUI,
    setup,
    isSmallScreen
  }
}
