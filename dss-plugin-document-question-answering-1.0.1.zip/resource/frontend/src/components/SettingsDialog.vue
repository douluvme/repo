<template>
  <div :class="containerClass" v-if="!noKnowledgeBankSetup">
    <div
      class="bs-font-medium-3-semi-bold text-primary"
      style="padding-left: 8px; margin-right: 8px"
    >
      <span style="margin-right: -8px">
        {{ !knowledgeBankCustomLabel ? $t('use_knowledge_bank') : $t('use') + ' ' + knowledgeBankCustomLabel }}
      </span>
      <QToggle
        :size="containerClass === 'col' ? 'sm' : 'md'"
        v-model="useKnowledgeBank"
        :disable="noKnowledgeBankSetup"
        :class="noKnowledgeBankSetup ? 'disabled' : ''"
      ></QToggle>
    </div>
    <q-btn
      flat
      dense
      no-caps
      no-wrap
      color="primary"
      @click="openSettingsDialog = true"
      size="md"
      class="bs-font-medium-3-normal"
      v-if="useKnowledgeBank"
    >
      <q-icon size="18px" style="margin-right: 2px" color="primary">
        <SettingsIcon color="#3B99FC" />
      </q-icon>

      {{ $t('filters') }}
      <q-icon size="16px" v-if="selectedknowledgeBankId" style="margin-left: 4px">
        <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
          {{ $t('tooltip_knowledge_bank') }} {{ badgeLabel > 0 ? $t('tooltip_with_filters') : '' }}
        </BsTooltip>
        <DbIcon color="#3B99FC" />
      </q-icon>
      <q-badge
        v-if="selectedknowledgeBankId"
        rounded
        floating
        color="#2B66FF"
        style="font-size: 10px"
      >
        {{ badgeLabel }}
      </q-badge>
      <q-dialog persistent :model-value="openSettingsDialog">
        <q-card style="width: 600px">
          <q-card-section>
            <div class="row items-center justify-between">
              <div class="row items-center no-wrap q-gutter-x-sm">
                <q-icon size="21px">
                  <SettingsIcon />
                </q-icon>
                <div class="dku-grand-title">{{ t('filters') }}</div>
              </div>
              <q-icon size="21px" name="close" style="cursor: pointer" @click="cancel"></q-icon>
            </div>
          </q-card-section>
          <q-separator />
          <q-card-section>
            <template v-if="setup.filtersConfig">
              <div class="row items-center no-wrap q-gutter-x-sm">
                <q-icon size="24px" v-if="selectedknowledgeBankId">
                  <DbIcon />
                </q-icon>
                <div class="bs-font-medium-4-semi-bold">{{ t('knowledge_bank') }}</div>
              </div>
              <div style="margin-top: 10px">
                {{ $t('use') }}: {{ setup.knowledgeBank?.customLabel ?? setup.knowledgeBank?.label }}
              </div>
              <div class="flex-column-20" v-if="useKnowledgeBank">
                <div class="row items-center no-wrap q-gutter-x-sm" style="margin-top: 10px">
                  <q-icon size="20px">
                    <FilterIcon />
                  </q-icon>
                  <div class="bs-font-medium-4-semi-bold">{{ t('filters') }}</div>
                </div>
                <div
                  style="overflow-y: scroll"
                  v-if="Object.keys(setup.filtersConfig.filter_options).length"
                >
                  <BSMultiSelect
                    v-for="(options, column) in setup.filtersConfig.filter_options"
                    :key="column"
                    :label="t('select_label', { item: column })"
                    :all-options="options"
                    :model-value="filters[column]"
                    @update:model-value="(event) => updateSelectedOption(column, event)"
                  >
                  </BSMultiSelect>
                </div>
                <BsWarning type="info" :text="t('empty_filters_text')" v-else> </BsWarning>
              </div>
            </template>

            <template v-else>
              <BsWarning type="info" :text="t('no_filters_text')"> </BsWarning>
            </template>
          </q-card-section>
          <q-card-actions align="right">
            <bs-button class="bs-btn-flat-danger dku-text" unelevated flat @click="cancel">
              {{ t('cancel') }}</bs-button
            >
            <bs-button class="bs-btn-flat dku-text" unelevated flat @click="apply">{{
              t('apply')
            }}</bs-button>
          </q-card-actions>
        </q-card>
      </q-dialog>
    </q-btn>
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { ref, computed } from 'vue'
import BsWarning from './BsWarning.vue'
import BSMultiSelect from './BsMultiSelect.vue'
import { useSettings } from './composables/use-settings'
import { useUI } from './composables/use-ui'
import FilterIcon from './icons/FilterIcon.vue'
import SettingsIcon from './icons/SettingsIcon.vue'
import DbIcon from './icons/DbIcon.vue'
import { QToggle } from 'quasar'
import { watch } from 'vue'
import { isEqual, set } from 'lodash'
import { toRefs } from 'vue'
const { t } = useI18n()
const props = defineProps<{
  containerClass: string
}>()

const { containerClass } = toRefs(props)
const openSettingsDialog = ref(false)
const { setup } = useUI()
const { filtersSelections: selectedFilters, knowledgeBankSelection: selectedknowledgeBankId } =
  useSettings()
const useKnowledgeBank = ref(selectedknowledgeBankId.value ? true : false)
const filters = ref({ ...selectedFilters.value })
function updateSelectedOption(column: string, newVal: string[]) {
  filters.value[column] = newVal
}

watch(setup, (newVal, oldVal) => {
  if (isEqual(newVal.knowledgeBank, oldVal.knowledgeBank)) {
    return
  }
  if (setup.value.knowledgeBank) {
    if (setup.value.knowledgeBank.activate) {
      selectedknowledgeBankId.value = setup.value.knowledgeBank!.id
      useKnowledgeBank.value = true
    } else {
      useKnowledgeBank.value = selectedknowledgeBankId.value ? true : false
    }
  } else {
    selectedknowledgeBankId.value = null
  }
  if (!selectedknowledgeBankId.value) {
    useKnowledgeBank.value = setup.value.knowledgeBank?.activate || false
  }
})
const noKnowledgeBankSetup = computed(() => {
  return !setup.value.knowledgeBank
})
const knowledgeBankCustomLabel = computed(() => {
  return setup.value.knowledgeBank?.customLabel
})
const badgeLabel = computed(() => {
  if (!useKnowledgeBank.value) return 0
  let count = 0
  for (const key in selectedFilters.value) {
    if (selectedFilters.value[key] && selectedFilters.value[key].length > 0) count++
  }
  return count
})
watch(useKnowledgeBank, (newVal) => {
  if (!newVal) {
    selectedknowledgeBankId.value = null
  } else {
    selectedknowledgeBankId.value = setup.value.knowledgeBank!.id
  }
})
const cancel = () => {
  useKnowledgeBank.value = selectedknowledgeBankId.value !== null
  filters.value = { ...selectedFilters.value }
  openSettingsDialog.value = false
}
const apply = () => {
  if (useKnowledgeBank.value) {
    selectedknowledgeBankId.value = setup.value.knowledgeBank!.id
  } else {
    selectedknowledgeBankId.value = null
  }
  selectedFilters.value = { ...filters.value }
  openSettingsDialog.value = false
}
</script>

<style scoped lang="scss">
.flex-column-20 {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.disabled {
  color: grey;
  opacity: 0.7 !important;
}
</style>
