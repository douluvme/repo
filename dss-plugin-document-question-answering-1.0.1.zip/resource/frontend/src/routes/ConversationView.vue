<template>
  <div
    ref="contentContainerRef"
    class="column items-center justify-center content-container"
    :class="{ loading: loadingQuestion }"
  >
    <div class="scroll-area" ref="scrollAreaRef">
      <div class="items-center justify-center">
        <div
          v-for="(item, index) in currentConversation?.data"
          :key="item.id"
          class="history items-center justify-center"
        >
          <QuestionCard :query="item.query" :letter-icon="userNameFirstLetter">
            <FilePreview
              :file-path="item.file_path"
              v-if="item.file_path"
              :height="'70%'"
              :width="'100%'"
              style="margin-top: 4px"
            ></FilePreview>
            <Filters :filters="item.filters" v-if="item.filters" />
          </QuestionCard>
          <AnswerCard
            v-if="item.query && item.query !== ''"
            :answer="item.answer ? item.answer: index < currentConversation!.data.length-1 ? t('error_message') : ''"
            :feedback="item.feedback"
            :feedback-options-negative="setup.feedbackNegativeChoices ?? []"
            :feedback-options-positive="setup.feedbackPositiveChoices ?? []"
            @update:feedback="(value) => logFeedback(item.id, item, value)"
            :typing-effect-on="false"
            :error-state="errorState"
          >
            <Sources
              class="self-start"
              :sources="item.sources"
              :project-key="setup.projectKey"
              :folder-id="setup.docsFolderId"
              v-if="item.sources && item.sources.length > 0"
              @update:expanded="(value) => handleSourceExpanded(index, value)"
            />
          </AnswerCard>
        </div>
      </div>
    </div>

    <div class="footer-section">
      <UserInput
        ref="userInputAreaRef"
        id="user-query-container"
        :input-placeholder="inputPlaceholder"
        :value="currentData.query"
        :loading="loadingQuestion"
        :file-path="currentData.file_path"
        :file-input-enabled="enableFileUpload"
        @send="submitQuery"
        @enterkey="submitQuery"
        @uploadFile="uploadFile"
        @deleteFile="deleteFile"
        @update:value="
          (value) => {
            currentData.query = value
          }
        "
        @size-change="resizeScrollArea"
        @file-change="handleFileChange"
      />
      <Disclaimer id="disclaimer-container" />
    </div>

    <q-btn
      v-if="!isNew && currentConversation?.data && currentConversation.data.length > 0"
      flat
      dense
      no-caps
      no-wrap
      color="primary"
      class="clear-history-btn"
      id="clear-history-btn"
      @click="openDeleteDialog = true"
      size="md"
    >
      <q-icon :name="`img:${trashIcon}`" size="18px" style="margin-right: 2px"></q-icon
      >{{ $t('clearHistory') }}

      <DeleteDialog
        :open="openDeleteDialog"
        :title="t('clear_history_dialog_title')"
        :text="t('clear_history_dialog_text')"
        @confirm="clearHistoryFromDialog"
        @cancel="openDeleteDialog = false"
      />
    </q-btn>
  </div>
</template>

<script setup lang="ts">
import { toRefs, computed, ref, onMounted, onUnmounted } from 'vue'
import { useConversation } from '@/components/composables/use-conversation'
import QuestionCard from '@/components/QuestionCard.vue'
import AnswerCard from '@/components/AnswerCard.vue'
import Sources from '@/components/Sources.vue'
import { useUI } from '@/components/composables/use-ui'
import { useI18n } from 'vue-i18n'
import trashIcon from '@/assets/icons/trash.svg'
import DeleteDialog from '@/components/DeleteDialog.vue'
import UserInput from '@/components/UserInput.vue'
import { watch } from 'vue'
import Filters from '@/components/Filters.vue'
import FilePreview from '@/components/FilePreview.vue'
import Disclaimer from '@/components/Disclaimer.vue'
import { useSettings } from '@/components/composables/use-settings'

const { t } = useI18n()

const openDeleteDialog = ref(false)

const props = defineProps<{
  id: string
}>()

const { id } = toRefs(props)

const scrollAreaRef = ref<HTMLElement>()
const contentContainerRef = ref<HTMLElement>()
const {
  currentData,
  currentConversation,
  errorState,
  loadingQuestion,
  sendQuestion,
  isNew,
  clearHistory,
  logFeedback,
  uploadFile,
  deleteFile
} = useConversation(id)
async function clearHistoryFromDialog() {
  await clearHistory()
  openDeleteDialog.value = false
}

const { setup, isSmallScreen } = useUI()

const enableFileUpload = computed(() => {
  return setup.value?.llmCapabilities?.multiModal
})

const userNameFirstLetter = computed(() => {
  return setup.value?.user?.length ? setup.value?.user[0].toLocaleUpperCase() : '?'
})

watch(id, scrollToBottom)

function debounce<F extends (...args: any[]) => void>(
  func: F,
  delay: number
): (...args: Parameters<F>) => void {
  let debounceTimer: ReturnType<typeof setTimeout>
  return function (...args: Parameters<F>) {
    clearTimeout(debounceTimer)
    debounceTimer = setTimeout(() => func(...args), delay)
  }
}

const debouncedScrollToBottom = debounce(() => {
  if (scrollAreaRef.value) {
    scrollAreaRef.value.scrollTop = scrollAreaRef.value.scrollHeight
  }
}, 200)

function scrollToBottom() {
  debouncedScrollToBottom()
}

function handleSourceExpanded(index: number, newVal: string) {
  if (
    newVal &&
    currentConversation.value?.data.length &&
    index === currentConversation.value.data.length - 1
  ) {
    scrollToBottom()
  }
}

const inputPlaceholder = computed(() => {
  return setup.value.questionPlaceholder || t('questionPlaceholder')
})

function submitQuery() {
  scrollToBottom()
  sendQuestion()
}
const { knowledgeBankSelection: selectedknowledgeBankId } = useSettings()
watch(selectedknowledgeBankId, (newVal, oldVal) => {
  if (newVal !== oldVal) {
    setTimeout(() => {
      resizeScrollArea()
    }, 0)
  }
})
function handleFileChange() {
  setTimeout(() => {
    resizeScrollArea()
  }, 0)
}

function resizeScrollArea() {
  if (!scrollAreaRef.value || !contentContainerRef.value) return
  const userInputArea = document.getElementById('user-query-container')
  if (!userInputArea) return
  const textareaHeight = userInputArea.offsetHeight
  const disclaimerHeight = document.getElementById('disclaimer-container')?.offsetHeight ?? 0
  const disclaimerComputedHeight = Math.min(disclaimerHeight, 50)
  // These values depend on wether the settings btn are displayed in a row or a col.
  // if a row we consider 45 for height otherwise 65
  const settingsBtnHeight = document.body.classList.contains('settings-col') ? 65 : 45
  const settingsBtnComputedHeight = Math.min(settingsBtnHeight + 5, 70)
  //here we are setting the height of the scroll area to the remaining height of the screen
  // after accounting for the height of the header, the textarea, and the disclaimer
  // adding 30px to account for the margins and paddings
  //TODO be imporved in the future
  scrollAreaRef.value.style.height = `calc(100% - ${settingsBtnComputedHeight}px - ${textareaHeight}px - ${disclaimerComputedHeight}px)`
}

onUnmounted(() => {
  // Remove event listener when component is destroyed/unmounted
  window.removeEventListener('resize', resizeScrollArea)
})
onMounted(() => {
  resizeScrollArea()
  window.addEventListener('resize', resizeScrollArea)

  debounce(() => {
    scrollToBottom()
  }, 0)
})
</script>

<style scoped>
.content-container {
  margin-top: 8px;
  height: 100%;
  max-height: 99%;
  /* max-height: 95%; */
  width: 100%;
  justify-content: end;
}
@media (min-width: 1500px) {
  .content-container {
    max-width: 1000px;
  }
}
.footer-section {
  width: 100%;
  margin-top: 5px;
}

.scroll-area {
  max-height: calc(100% - 100px);
  /* min-height: calc(100% - 200px); */
  margin-bottom: 10px;
  margin-top: 0px;
  width: 100%;
  overflow-y: scroll;
  max-height: 100%;
}

.history {
  display: flex;
  gap: 16px;
  flex-direction: column;
  margin-bottom: 16px;
}

.history:first-child {
  padding-top: 0px !important;
}

.history:first-child {
  border-top: none;
}
</style>
