<template>
  <BsLayoutDefault ref="layout">
    <BsDrawer>
      <BsButton
        flat
        round
        class="close-side-drawer-btn"
        size="15px"
        @click="closeSideDrawer"
        :icon="mdiArrowLeft"
      >
        <BsTooltip>Close sidebar</BsTooltip>
      </BsButton>
      <q-scroll-area style="height: 100vh; max-width: 100%">
        <div class="q-pt-md q-pb-md" style="overflow-x: hidden">
          <div
            class="q-pl-md q-pr-md row fit no-wrap items-center q-gutter-x-sm"
            style="margin-bottom: 10px"
          >
            <span class="bs-font-medium-3-semi-bold all-title">{{ t('all_conversations') }}</span>
          </div>
          <div
            class="q-pl-md q-pr-md flex row"
            style="justify-content: space-between; margin-top: 10px"
          >
            <q-btn
              flat
              dense
              color="primary"
              style="padding-left: 0; margin-bottom: 3px"
              @click="newConversation"
              no-caps
              class="bs-font-medium-3-normal"
              ><q-icon :name="`img:${addSquareIcon}`" size="18px" style="margin-right: 2px"></q-icon
              >{{ t('new_chat') }}
            </q-btn>
            <q-btn
              flat
              dense
              color="primary"
              style="padding-left: 0; margin-bottom: 3px"
              @click="deleteAllOpen = true"
              no-caps
              class="bs-font-medium-3-normal"
              v-if="conversations.length"
            >
              <q-icon
                :name="`img:${trashIcon}`"
                size="16px"
                style="cursor: pointer"
                @click="deleteAllOpen = true"
              >
              </q-icon>
              {{ t('delete_all_conv_title') }}
              <DeleteDialog
                :open="deleteAllOpen"
                :title="t('delete_all_conv_title')"
                :text="t('delete_all_conv_warning')"
                @cancel="deleteAllOpen = false"
                @confirm="deleteAllItems"
              >
                {{ t('delete_all_conv_message') }}
              </DeleteDialog>
            </q-btn>
          </div>

          <div
            class="column no-wrap justify-center align-center"
            v-if="!loadingConversations && !errorConversations"
          >
            <ConversationCard
              v-for="(item, index) in conversations"
              :title="item.name"
              :date="item.timestamp"
              :id="item.id"
              :is-selected="isSelected(item.id)"
              @update:conv="(id) => navigateToConv(id)"
              @delete:conv="(id) => deleteItem(id)"
            />
          </div>
          <div v-else-if="errorConversations">
            <div>ERROR</div>
          </div>
          <div v-else>
            <q-spinner color="primary" size="3em"></q-spinner>
          </div>
        </div>
      </q-scroll-area>
    </BsDrawer>
    <BsContent>
      <BsButton
        flat
        class="open-side-drawer-btn"
        size="15px"
        @click="closeSideDrawer"
        :icon="mdiArrowRight"
        v-if="!layout?.drawerOpen"
      >
        <BsTooltip>Open sidebar</BsTooltip>
      </BsButton>
      <BsDocumentationNew v-if="allowGeneralFeedback"></BsDocumentationNew>
      <div class="absolute-center content-wrapper">
        <div class="column items-center doc-intelligence-content">
          <SettingsDialog
            class="settings-btn"
            id="settings-dialog-btn"
            :container-class="settingsBtnClass"
          />
          <RouterView />
        </div>
      </div>
    </BsContent>
  </BsLayoutDefault>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useUI } from '@/components/composables/use-ui'
import { useConversations } from '@/components/composables/use-conversations'
import { useConversation } from '@/components/composables/use-conversation'
import { useRouter } from 'vue-router'
import DeleteDialog from '@/components/DeleteDialog.vue'
import trashIcon from '@/assets/icons/trash.svg'
import addSquareIcon from '@/assets/icons/add_square.svg'
import ConversationCard from '@/components/ConversationCard.vue'
import { BsButton, type BsLayoutDefault } from 'quasar-ui-bs'
import { mdiArrowLeft, mdiArrowRight } from '@quasar/extras/mdi-v6'
import { onMounted, onUnmounted } from 'vue'
import SettingsDialog from '@/components/SettingsDialog.vue'
import BsDocumentationNew from '@/components/BsDocumentationNew.vue'
import { computed, watch, ref } from 'vue'
import { useSettings } from '@/components/composables/use-settings'
import { WT1iser } from '@/common/wt1'

const router = useRouter()
const id = ref<string | null>(null)

const { reset } = useConversation(id)

const { setup, isSmallScreen } = useUI()
const { t } = useI18n()

function isSelected(itemId: string) {
  const route = useRoute()
  const converationId = route.params.id
  return itemId === converationId
}
const isEmptyState = ref<boolean>(false)
watch(useRoute(), (to) => {
  isEmptyState.value = to.path === '/new'
  handleScreenSizeChange()
})
const deleteAllOpen = ref<boolean>(false)

const layout = ref<InstanceType<typeof BsLayoutDefault> | null>(null)
const { knowledgeBankSelection: selectedknowledgeBankId } = useSettings()

const {
  conversations,
  loading: loadingConversations,
  error: errorConversations,
  deleteConversation,
  deleteAllConversations
} = useConversations()


let openEvenetSent = false

watch(setup, () => {
  const llmId = setup.value?.llmId
  if (llmId && !openEvenetSent) {
    openEvenetSent = true
    WT1iser.init(llmId)
    WT1iser.open(
      router.currentRoute.value.name,
    )
  }
  
}, { deep: true })

async function newConversation() {
  WT1iser.action(
    'newConversation',
    router.currentRoute.value.name,
    0
  )
  await reset()
  await router.push({ path: '/new' })
  closeSideBarForSmallScreen()
}

async function deleteItem(id: string) {
  WT1iser.action(
    'deleteItem',
    router.currentRoute.value.name,
    0// TODO: this might not be 0
  )
  await deleteConversation(id)
  await router.push({ path: '/new' })
  await reset()
}

async function deleteAllItems() {
  WT1iser.action(
    'deleteAllItems',
    router.currentRoute.value.name,
    0
  )
  await deleteAllConversations()
  await router.push({ path: '/new' })
  await reset()
  deleteAllOpen.value = false
}
function closeSideBarForSmallScreen() {
  // If we are on a small screen we close the side bar
  // and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px) to match css breakpoints
  if (isSmallScreen()) {
    closeSideDrawer()
  }
}
function navigateToConv(id: string) {
  router.push({ path: `/conversation/${id}` })
  closeSideBarForSmallScreen()
}
function closeSideDrawer() {
  if (layout.value) {
    layout.value.drawerOpen = !layout.value.drawerOpen
  }
}
const allowGeneralFeedback = computed(() => {
  return setup.value.allowGeneralFeedback
})
const settingsBtnClass = ref('row')
function handleScreenSizeChange() {
  const contentWidth = document.getElementsByClassName('doc-intelligence-content').length
    ? document.getElementsByClassName('doc-intelligence-content')[0].clientWidth
    : 0
  const minConversationWidth = 500
  const minEmptyStateWidth = 450
  const isSmallScreen =
    contentWidth <= (isEmptyState.value ? minEmptyStateWidth : minConversationWidth)
  document.body.classList.toggle('small-screen', isSmallScreen)
  document.body.classList.toggle('knowledge-bank-on', selectedknowledgeBankId.value !== null)
  settingsBtnClass.value =
    contentWidth <= 450 && selectedknowledgeBankId.value && !isEmptyState.value ? 'col' : 'row'
  document.body.classList.toggle(
    'settings-col',
    window.innerWidth <= 450 && selectedknowledgeBankId.value !== null
  )
}
watch(selectedknowledgeBankId, (newVal, oldVal) => {
  if (newVal !== oldVal) {
    setTimeout(() => {
      handleScreenSizeChange()
    }, 0)
  }
})
watch(allowGeneralFeedback, (val) => {
  document.body.classList.toggle('general-feedback-on', val)
})

onMounted(() => {
  closeSideBarForSmallScreen()
  isEmptyState.value = router.currentRoute.value.path === '/new'
  setTimeout(() => {
    handleScreenSizeChange()
  }, 0)
  window.addEventListener('resize', handleScreenSizeChange)
})
onUnmounted(() => {
  // Remove event listener when component is destroyed/unmounted
  window.removeEventListener('resize', handleScreenSizeChange)
})
</script>
<style lang="scss">
.q-scrollarea__content {
  max-width: 100% !important;
}
.close-side-drawer-btn,
.open-side-drawer-btn {
  color: var(--q-primary);
  position: absolute;
  z-index: 1000;
}
.close-side-drawer-btn {
  top: 7px;
  right: 10px;
}
.open-side-drawer-btn {
  top: 9px;
  left: 10px;
  transform: translate(1%, 0%);
  -ms-transform: translateX(1%);
  color: white;
  background-color: var(--q-primary);
  padding: 24px 4px;
  box-shadow: 0px 2px 6px 2px rgba(0, 0, 0, 0.3);
  border-radius: 0px 8px 8px 0px;
}
.toggle-left-button {
  visibility: hidden !important;
}
.all-title {
  color: #333e48;
}
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 200, 'GRAD' 0, 'opsz' 24;
}

.active {
  background-color: #66666615;
}

body,
div {
  font-family: 'SourceSansPro' !important;
}
:root {
  --bg-brand: #e6f7f6; //#b3e8e5;
  --bg-examples-brand: rgba(230, 247, 246, 0.31);
  --bg-examples-borders: #b3e8e5;
  --bg-examples-question-marks: rgb(1, 178, 170);
  --bg-examples-text: black;
  --brand: #2ab1ad;
  --text-brand: #444;
}

.bs-select__popup {
  width: auto !important;
  max-width: none !important;
  .q-item__label {
    padding-left: 1rem;
  }
}
.q-item {
  padding-left: 0 !important;
}

.q-item__section--side {
  padding-right: 0 !important;
}

.q-item__section--avatar {
  min-width: 20px !important;
}

.disabled.filters-selectors {
  cursor: pointer;
  .q-field__inner {
    background: #f5f5f5;
  }
}
.bs-font-medium-2-normal {
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}
.bs-font-medium-1-normal {
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 20px;
}
.bs-font-medium-2-semi-bold {
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 22px; /* 157.143% */
}
.bs-font-medium-3-semi-bold {
  font-size: 16px;
  font-style: normal;
  font-weight: 600;
  line-height: 22px;
}
.bs-font-medium-4-normal {
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: 32px;
}
.bs-font-medium-4-semi-bold {
  color: #333e48;
  font-size: 20px;
  font-style: normal;
  font-weight: 600;
  line-height: 32px; /* 160% */
}
.bs-font-medium-3-normal {
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}
.dds-caption-400 {
  font-family: SourceSansPro;
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 15px;
}
.bs-alert-notification {
  border-radius: 4px;
  box-shadow: none;
}
.q-notification__icon--additional {
  margin-right: 8px;
}
.text-positive-alert {
  color: green !important;
}
.bg-positive-alert {
  background-color: #d7f0d6 !important;
}
.text-negative-alert {
  color: red !important;
}
.bg-negative-alert {
  background-color: #f9e3e5 !important;
}
.bs-font-medium-1-semi-bold {
  font-size: 12px;
  font-style: normal;
  font-weight: 600;
  line-height: 20px;
}
.content-wrapper {
  display: flex;
  flex-direction: column;
  height: 100%;
  max-height: 100%;
  width: 100%;
  justify-content: center;
  align-items: center;
  overflow-y: hidden;
}

.doc-intelligence-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  max-height: 100%;
}

.doc-intelligence-content,
.column.items-center {
  width: 80%;
  margin-top: 0px;
}

.doc-intelligence-content,
.column.items-center.loading {
  padding-top: 15px;
}

.dku-medium-title {
  width: 100%;
  max-width: 100%;
}

.filters-autoFilter .q-pa-sm {
  padding: 0px;
  margin-left: -15px;
}
.filters-autoFilter {
  margin-top: 21px;
}

.q-field__control-container {
  align-items: center !important;
}
.q-field__native {
  padding: 0px !important;
}

.bs-toggle__content__active {
  background: #3b99fc !important;
}

.q-field--outlined {
  .q-field__control {
    &:before {
      border: none !important;
    }
    &:after {
      border: 1px solid #cccccc;
    }
    &:hover {
      &:before,
      &:after {
        border: 1px solid #999999;
      }
    }
  }
  &.q-field--highlighted {
    .q-field__control:after {
      border: 1px solid var(--brand);
    }
  }
}

.q-item {
  min-height: 20px;
  height: auto;
}
footer {
  width: 100%;
  padding: 20px;
  text-align: center;
}

.navigation-container {
  position: absolute;
  top: 20px;
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
}

.navigation-container span {
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 20px;
  color: #666666;
}

.navigation-container .q-icon {
  margin-left: 5px;
}
.clear-history-btn {
  right: 16px;
}
.clear-history-btn,
.settings-btn {
  top: 18px;
  cursor: pointer;
  z-index: 1;
  position: absolute;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: 22px;
}
.clear-history-btn {
  top: 21px;
}

.general-feedback-on {
  .clear-history-btn {
    right: 190px;
  }
}

.small-screen.general-feedback-on .content-container {
  margin-top: 0px !important;
}
.knowledge-bank-on .content-container.file-preview {
  margin-top: 42px !important;
}
.small-screen .content-container.file-preview {
  margin-top: 32px !important;
}

.small-screen.knowledge-bank-on .content-container.file-preview {
  margin-top: 52px !important;
}
.small-screen.general-feedback-on .content-container {
  max-height: 95% !important;
}

.settings-btn {
  left: 50px;
  right: unset;
}

.clear-history-btn .q-icon,
.drawer-btn .q-icon,
.settings-btn {
  font-size: 18px;
}

.query-input {
  width: 100%;
}
.q-textarea.q-field--dense .q-field__control,
.q-textarea.q-field--dense .q-field__native {
  min-height: 28px !important;
  height: 28px;
  max-height: 300px;
}
@media (max-width: 450px) {
  .settings-btn {
    flex: 10000 1 0%;
  }
}
@media (min-width: 450px) {
  .settings-btn {
    display: flex;
    flex-wrap: wrap;
  }
}
@mixin common-small-screen-styles {
  .btn-solution {
    bottom: 0px;
    top: unset !important;
    border: none !important;
  }
  .q-btn--outline::before {
    border: none !important;
  }
  .clear-history-btn {
    top: 10px;
    right: 16px !important;
  }
  .settings-btn {
    top: 8px;
  }
  .open-side-drawer-btn {
    top: 4px;
  }
  footer {
    padding: 8px;
  }
}
.small-screen {
  @include common-small-screen-styles;
}
@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 600px) {
  /* Styles for phone screens */
  @include common-small-screen-styles;
  /* Adjusted width for smaller screens so that side bar takes all the screen */
  div.q-layout.q-layout--standard.bg-white {
    --bs-drawer-width: 100% !important;
  }
  .q-drawer.q-drawer--left.q-drawer--bordered.q-drawer--standard {
    width: 100% !important;
  }
}
.doc-footer__icon {
  padding-bottom: 6px !important;
  padding-top: 5px !important;
  border-bottom: 1px solid #f2f2f2;
}
.doc-footer__text {
  border-left: none !important;
  border-bottom: 1px solid #f2f2f2;
}

@media screen and (orientation: landscape) and (max-height: 600px) and (max-width: 1000px),
  (max-width: 767px) {
  /* Styles for phone screens */
  .doc-intelligence-content,
  .column.items-center {
    max-height: 100%;
    overflow-x: hidden;
  }
  .dku-medium-title {
    font-size: 16px;
  }
  .dku-grand-title-sb {
    font-size: 18px;
  }
  .doc-intelligence-content,
  .column.items-center {
    width: 100%;
    padding: 8px;
  }
  .navigation-container {
    top: 16px;
  }
  .btn-solution-text {
    font-size: 10px !important;
  }
}
</style>
