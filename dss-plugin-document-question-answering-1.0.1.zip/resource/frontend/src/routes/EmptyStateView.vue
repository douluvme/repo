<template>
  <div class="items-center q-gutter-y-md empty-state">
    <q-scroll-area style="height: 100vh; width: 100%">
      <div class="q-gutter-y-md">
        <q-icon :name="logoName" size="117px" class="logo-icon" style="width: 100%"></q-icon>
        <div class="dku-grand-title-sb" style="color: #666666; text-align: center">
          {{ setup.title }}
        </div>
        <div class="dku-medium-title" style="text-align: center; color: #666666">
          {{ setup.subtitle }}
        </div>
        <UserInput
          :input-placeholder="inputPlaceholder"
          :value="currentData.query"
          :loading="loadingQuestion"
          :file-path="currentData.file_path"
          :file-input-enabled="enableFileUpload"
          @send="sendQuestion"
          @enterkey="sendQuestion"
          @uploadFile="uploadFile"
          @deleteFile="deleteFile"
          @update:value="(value) => (currentData.query = value)"
        />
      </div>
      <div class="title_with_lines">{{ $t('examples') }}</div>
      <div class="row no-wrap q-gutter-x-md examples">
        <InfoCard
          v-for="text in setup.examples"
          :text="text"
          style="cursor: pointer"
          @click="currentData.query = text"
        />
      </div>
    </q-scroll-area>
    <Disclaimer />
  </div>
</template>
<script lang="ts" setup>
import InfoCard from '@/components/InfoCard.vue'
import logoWithBackground from '@/assets/icons/logo-with-background.svg'
import { useUI } from '@/components/composables/use-ui'
import { useConversation } from '@/components/composables/use-conversation'
import { toRefs, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import UserInput from '@/components/UserInput.vue'
import Disclaimer from '@/components/Disclaimer.vue'
const props = defineProps<{
  id: string | null
}>()

const { t } = useI18n()

const { id } = toRefs(props)

const { currentData, sendQuestion, loadingQuestion, uploadFile, deleteFile } = useConversation(id)
const { setup } = useUI()
const logoName = `img:${logoWithBackground}`
const emits = defineEmits<{
  (e: 'example-clicked', text: string): void
}>()

const inputPlaceholder = computed(() => {
  return setup.value.questionPlaceholder || t('questionPlaceholder')
})
const enableFileUpload = computed(() => {
  return setup.value?.llmCapabilities?.multiModal
})
</script>

<style scoped lang="scss">
.title_with_lines {
  line-height: 20px;
  text-align: center;
  color: var(--brand);
  font-size: 13px;
  margin-bottom: 19px;
  margin-top: 36px;
}
.title_with_lines {
  display: inline-block;
  position: relative;
  width: 100%;
}
.title_with_lines:before,
.title_with_lines:after {
  content: '';
  position: absolute;
  overflow: hidden;
  height: 10px;
  border-bottom: 1px solid var(--brand);
  top: 0;
  width: calc(50% - 50px);
}
.title_with_lines:before {
  right: 50%;
  margin-right: 50px;
}
.title_with_lines:after {
  left: 50%;
  margin-left: 50px;
}
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 800px;
  height: 100vh;
  margin-top: 30px;
  overflow: hidden;
}

// Mixin for common styles for small screens */
@mixin common-styles {
  .empty-state {
    width: 100% !important;
    margin-top: 25px;
    margin-bottom: 25px;
  }
  .examples {
    display: flex; /* Enable Flexbox */
    flex-wrap: wrap;
    justify-content: space-between; /* Spread the items equally apart */
    gap: 10px;
    justify-content: center;
    margin-left: 0px;
    max-width: 100%;
  }
  .info-card {
    max-width: 90%;
    margin-left: 0px;
  }
  .logo-icon {
    font-size: 100px !important;
  }
}
@media screen and (orientation: landscape) and (max-height: 500px) and (max-width: 1000px),
  (max-width: 767px) {
  /* Styles for phone screens */
  @include common-styles;
}
.small-screen {
  @include common-styles;
  .empty-state {
    margin-top: 45px;
  }
}
</style>
