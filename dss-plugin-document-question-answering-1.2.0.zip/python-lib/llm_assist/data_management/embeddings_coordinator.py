from llm_assist.data_management.embeddings_handler import embedding_handler
from llm_assist.dku_handler import dku_handler

    
class EmbeddingCoordinator:
    def __init__(self, embedding_generator, dataiku_handler):
        self.embedding_generator = embedding_generator
        self.dataiku_handler = dataiku_handler
    
    def process(self, folder_containing_embeddings):
        dku_folder_info = self.dataiku_handler.read_from_folder(folder_containing_embeddings)
        faiss_embeddings =  self.embedding_generator.reload_embeddings_from_dku_folder(dku_folder_info)
        # Add more processing as needed
        return faiss_embeddings

embedding_coordinator = EmbeddingCoordinator(embedding_handler, dku_handler)
