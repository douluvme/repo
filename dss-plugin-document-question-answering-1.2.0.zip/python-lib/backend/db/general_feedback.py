from datetime import datetime
from backend.utils.dataiku_api import dataiku_api
from llm_assist.logging import logger
from dataiku import SQLExecutor2, Dataset
from dataiku.sql import Dialects, toSQL
from dataiku.sql import Dialects, toSQL
import pandas as pd
from typing import Optional, Literal
from werkzeug.exceptions import BadRequest
from backend.db.sql.sql_timing import log_query_time

from backend.db.sql.queries import (
    InsertQueryBuilder,
    get_post_queries
)

COLUMNS = [
    "date",
    "user",
    "message",
    "knowledgebank",
    "llm"
]

FEEDBACK_DATASET_CONF_ID = "general_feedback_dataset"

DIALECT_VALUES = [
    getattr(Dialects, attr)
    for attr in dir(Dialects)
    if not callable(getattr(Dialects, attr)) and not attr.startswith("__")
]


class GeneralFeedbackSQL:
    def __init__(self):
        self.config = dataiku_api.webapp_config
        self.dataset_name = self.config.get(FEEDBACK_DATASET_CONF_ID, None)
        if not self.config.get("allow_general_feedback", False):
            return
        self.__verify()
        self.dataset = Dataset(
            project_key=dataiku_api.default_project_key, name=self.dataset_name
        )
        self.__init_dataset()
        self.executor = SQLExecutor2(dataset=self.dataset)

    def __verify(self):
        if self.dataset_name is None or self.dataset_name == "":
            logger.error("Feedbacks Dataset name should not be null")
            raise ValueError("Feedbacks Dataset name should not be null")
        self.__check_dataset_exists()
        self.__check_supported_dialect()

    def __check_dataset_exists(self):
        project = dataiku_api.client.get_project(
            dataiku_api.default_project_key)
        data = project.list_datasets()
        datasets = [item.name for item in data]
        logger.debug(
            f"Searching for {self.dataset_name} in this project datasets: {datasets}"
        )
        if self.dataset_name in datasets:
            return True
        else:
            logger.error("Feedbacks dataset does not exist")
            raise ValueError("Feedbacks dataset does not exist")

    def __check_supported_dialect(self):
        # TODO: Limit dialects here is needed
        dataset = Dataset(
            project_key=dataiku_api.default_project_key, name=self.dataset_name
        )
        dataset_type = dataset.get_config().get("type")
        result = dataset_type in DIALECT_VALUES
        if result:
            return
        else:
            logger.error(f"Dataset Type {dataset_type} is not supported")
            raise ValueError(f"Dataset Type {dataset_type} is not supported")

    def __init_dataset(self):
        try:
            self.dataset.read_schema(raise_if_empty=True)
        except Exception as e:
            logger.info("Initializing the feedback dataset schema")
            df = GeneralFeedbackSQL.get_init_df()
            self.dataset.write_with_schema(df=df)

    @staticmethod
    def get_init_df():
        data = {col: [] for col in COLUMNS}
        return pd.DataFrame(data=data, columns=COLUMNS, dtype=str)

    def execute(
        self,
        query_raw,
        format_: Literal["dataframe", "iter"] = "dataframe",
    ):
        try:
            query = toSQL(query_raw, dataset=self.dataset)
        except Exception as err:
            raise BadRequest(f"Error when generating SQL query: {err}")

        if format_ == "dataframe":
            try:
                query_result = self.executor.query_to_df(
                    query=query).fillna("")
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when generating SQL query: {err}")
        elif format_ == "iter":
            try:
                query_result = self.executor.query_to_iter(
                    query=query).iter_tuples()
                return query_result
            except Exception as err:
                raise BadRequest(f"Error when executing SQL query: {err}")

    def execute_commit(self):
        return

    @log_query_time
    def add_feedback(
        self,
        timestamp: datetime,
        user: str,
        message: str,
        knowledge_bank_id: Optional[str] = None,
        llm_id: Optional[str] = None
    ):
        record_value = [
            timestamp.isoformat(),
            user,
            message,
            knowledge_bank_id if not knowledge_bank_id is None else "",
            llm_id if not llm_id is None else ""
        ]
        insert_query = (
            InsertQueryBuilder(self.dataset)
            .add_columns(COLUMNS)
            .add_values(values=[record_value])
            .build()
        )
        self.executor.query_to_df(
            insert_query, post_queries=get_post_queries(self.dataset))


feedbacks_sql_manager = GeneralFeedbackSQL()
