import time
from llm_assist.logging import logger


def log_query_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        logger.debug(
            f"SQL function '{func.__name__}' took {round(end_time - start_time, 3)} seconds to execute.")
        return result
    return wrapper
