import traceback
from flask import g
from flask_socketio import send, disconnect, emit
from llm_assist.logging import logger
from backend.utils.dataiku_api import dataiku_api
from backend.utils.streaming_utils import TaggedTextStreamHandler, clean_text_tags
from typing import Dict, Union, List, Any
from backend.routes.api.api_response_handler import APIResponseProcessor
from backend.db.base import conversation_sql_manager, CONVERSATION_DEFAULT_NAME
from backend.models.base import LlmHistory, QuestionData
import json
from ..utils import before_request, return_ok, return_ko
from typing import Optional
from solutions.service import llm_qa


def extract_request_info(request_json: Dict[str, Union[str, List[str]]]) -> Dict[str, Union[str, List[Any]]]:
    """Parses a JSON payload to extract necessary details as IDs, query, filters,
    and history using global context and SQL management systems. 

    Parameters:
        request_json (dictionary): JSON request data.

    Returns:
        dictionary: Key information like query, filters, and IDs.

    Note:
        Requires global authentication and APIResponseProcessor for processing.
    """
    auth_identifier = g.get("authIdentifier")
    api_response_handler: APIResponseProcessor = APIResponseProcessor(
        api_response=request_json
    )
    conversation_id: Optional[str] = api_response_handler.extract_conversation_id(
    )
    query: str = api_response_handler.extract_query()

    query_index: int = api_response_handler.extract_query_index()

    filters: Optional[Dict[str, List[Any]]
                      ] = api_response_handler.extract_filters()

    file_path: Optional[str] = api_response_handler.extract_file_path()
    knowledge_bank_id: Optional[str] = api_response_handler.extract_knowledge_bank_id(
    )

    # Get Llm history from cache
    history: List[LlmHistory] = []
    if conversation_id:
        history = conversation_sql_manager.get_conversation_history(
            auth_identifier=auth_identifier, conversation_id=conversation_id
        )
    answer: str = request_json.get("answer", "")
    sources: List = request_json.get("sources", [])
    return {
        "query": query,
        "query_index": query_index,
        "filters": filters,
        "file_path": file_path,
        "knowledge_bank_id": knowledge_bank_id,
        "history": history,
        "answer": answer,
        "sources": sources,
        "conversation_id": conversation_id
    }


def record_conversation(request_json: Dict[str, Union[str, List[str]]]):
    """
    Extracts data from a JSON request for DB updating purposes. It also includes additional details 
    like conversation name and knowledge bank identifiers when necessary.

    Parameters:
    - request_json (dict): The JSON data of the request with potential keys for query, filters, answer, etc.

    Notes:
    - Successfully updates the logging database with new interaction information and confirms with a success message.
    - Used to track user interactions and LLM responses during specific events such as new queries or at conversation closure.
    """
    try:
        auth_identifier = g.get("authIdentifier")
        info = extract_request_info(request_json=request_json)
        # Update cache onversation
        new_history_record = QuestionData(
            id=len(info["history"]),
            query=info["query"],
            filters=info["filters"],
            file_path=info["file_path"],
            answer=info["answer"],
            sources=info["sources"],
            feedback=None,
        )
        conversation_name = CONVERSATION_DEFAULT_NAME

        if not info["conversation_id"]:
            conversation_name = llm_qa.get_conversation_title(
                new_history_record["query"], new_history_record["answer"]
            )

        knowledge_bank_full_id = llm_qa.get_knowledge_bank_full_name(
            info["knowledge_bank_id"])

        # Get llm id
        config: Dict[str, str] = dataiku_api.webapp_config
        llm_id = config.get("llm_id", None)
        record_id, conversation_infos = conversation_sql_manager.add_record(
            dict(new_history_record),
            auth_identifier,
            info["conversation_id"],
            conversation_name,
            knowledge_bank_full_id,
            llm_id

        )
        logger.debug(f"Successfully created record in DB")
        emit("log_query_complete", return_ok(data={
            "answer": new_history_record["answer"],
            "sources": new_history_record["sources"],
            "filters": new_history_record["filters"],
            "conversation_infos": conversation_infos,
            "record_id": record_id,
            "query": new_history_record["query"],
        }))

    except Exception as e:
        logger.error(f"Error processing log message {e}")
        emit("log_query_complete", return_ko(
            message="Error processing log message"))
    disconnect()


def process_and_stream_answer(request: str):
    """
    Handles a request by streaming llm answers and logging the query process.

    This function processes a JSON request to provide streaming answers and log interactions. 
    It concludes by saving the query in the logging database.

    Parameters:
    - request (str): The JSON string of the request, which should include the query, and may include filters, knowledge bank ID, and file path.

    Key Steps:
    1. Parse the JSON request.
    2. Extract request details like query and optional parameters.
    3. Retrieve and stream llm answer parts.
    4. Log the completed query in the database.

    Error handling ensures clients are informed of any issues during the process.
    """
    def finalize_answer(request_json):
        """
        Finalizes the answer by storing query request into the Logging DB.

        Parameters:
        - request_json (Dict[str, Union[str, List[str]]]): The request information including the answer.
        """
        record_conversation(request_json)
        logger.debug("Successfully sent event to log query")

    answer = ""
    try:
        request_json: Dict[str, Union[str, List[str]]] = json.loads(request)
        logger.debug(f"Payload from the front end is {request_json}")
        request_info = extract_request_info(request_json=request_json)
        query_index = request_info["query_index"]

        tagged_text_stream_handler = TaggedTextStreamHandler([  # "<gcb>",
            "<source_citations>"],
            [  # "</gcb>",
            "</source_citations>"],
            clean_text_tags)
        for chunk in llm_qa.get_answer_and_sources(
            request_info["query"], query_index, request_info["history"], filters=request_info[
                "filters"], knowledge_bank_id=request_info["knowledge_bank_id"], file_path=request_info["file_path"]
        ):
            chunk_type = get_answer_chunk_type(request_json, chunk)
            if "streaming" in chunk_type:
                # Case streaming:
                if chunk_type == "streaming_completion_chunk":
                    text_chunk = chunk.data['text']
                    processed_text = tagged_text_stream_handler.process_text_chunk(
                        text_chunk)
                    answer += processed_text
                    send(return_ok(data={"answer": processed_text}))

                # In case of streaming last chunk is the end of the answer
                elif chunk_type == "streaming_completion_footer":
                    request_json["answer"] = answer
                    logger.debug(f"Final answer is : {answer}")

                    # In case of streaming with knowledge bank, we need to wait for additional message which contains sources and filters
                    if not request_info["knowledge_bank_id"]:
                        finalize_answer(request_json=request_json)

            elif chunk_type == "dictionary":
                # Case no streaming:
                answer = answer + chunk.get("answer")
                logger.debug(f"chunck answer {answer}")
                send(return_ok(data=chunk))

                request_json.update({
                    "answer": answer,
                    "sources": chunk.get(
                        "sources"),
                    "filters": chunk.get(
                        "filters"),
                })
                finalize_answer(request_json=request_json)
    except Exception as e:
        # Handle exceptions gracefully
        logger.error(f"Got exception -----: {e}")
        logger.error(f"Error trace   -----: {traceback.format_exc()}")
        send(return_ko(message="Error processing your request"))
        # TODO should this be different message
        request_json["answer"] = "Error processing your request"
        finalize_answer(request_json=request_json)


def setup_socketio_answer_event_handlers(socketio):
    """
    Registers event handlers for a socket.io server to handle client connections, 
    messages, logging queries, disconnections, and connection errors. 
    This function sets up the necessary event listeners for the socket.io server 
    to interact with clients, for streaming answers.

    Parameters:
    - socketio: The socket.io server instance to which the event handlers are to be registered.

    Notes:
    - The event handlers include actions for client connect and disconnect events, 
      message receipt, log query messages, and handling connection errors.
    """
    @socketio.on('connect')
    def handle_connect():
        before_request()
        logger.debug('Client connected')

    @socketio.on('message')
    def handle_message(msg):
        before_request()
        process_and_stream_answer(msg)

    @socketio.on('log_query')
    def handle_log_query(request: str):
        before_request()
        request_json: Dict[str, Union[str, List[str]]] = json.loads(request)
        logger.info(f"Payload from the front end is {request_json}")
        logger.info('Client sent a message to log')
        record_conversation(request_json)

    @socketio.on('disconnect')
    def handle_disconnect():
        before_request()
        logger.info('Client disconnected')
        # disconnect()

    @socketio.on('connect_error')
    def handle_error():
        logger.error('Failed to connect to client')


def get_answer_chunk_type(request_json, answer_chunk):
    if answer_chunk is not None:
        if isinstance(answer_chunk, dict):
            answer_chunk_type = "dictionary"
        else:
            chunk_as_string = str(answer_chunk)
            if "completion-chunk:" in chunk_as_string:
                answer_chunk_type = "streaming_completion_chunk"
            elif "completion-footer:" in chunk_as_string:
                answer_chunk_type = "streaming_completion_footer"
    else:
        answer_chunk_type = None
        logger.info(f"The query {request_json['query']} led to a 'None' chunk")
    return answer_chunk_type
