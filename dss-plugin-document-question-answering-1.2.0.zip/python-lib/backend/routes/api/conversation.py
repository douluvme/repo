from flask import Blueprint, request, g
from ..utils import return_ok, before_request
from llm_assist.logging import logger
from backend.models.base import QuestionData, Feedback
from backend.db.base import conversation_sql_manager


conversation_blueprint = Blueprint(
    "conversation", __name__, url_prefix="/conversation")


@conversation_blueprint.before_request
def before_conversation_request():
    before_request()


@conversation_blueprint.route("/conversations", methods=["GET"])
def get_user_conversations():
    auth_identifier = g.get("authIdentifier")
    conversations = conversation_sql_manager.get_user_conversations(
        auth_identifier)
    return return_ok(conversations)


@conversation_blueprint.route("/conversations", methods=["DELETE"])
def delete_all_user_conversations():
    auth_identifier = g.get("authIdentifier")
    conversation_sql_manager.delete_all_user_conversations(
        auth_identifier=auth_identifier
    )
    return return_ok()


@conversation_blueprint.route("/<string:id>", methods=["GET"])
def get_user_conversation(id: str):
    auth_identifier = g.get("authIdentifier")
    conversation = conversation_sql_manager.get_conversation(
        auth_identifier, id)
    return return_ok(conversation)


@conversation_blueprint.route("/<string:id>", methods=["DELETE"])
def delete_user_conversation(id: str):
    auth_identifier = g.get("authIdentifier")
    conversation_sql_manager.delete_user_conversation(
        auth_identifier=auth_identifier, conversation_id=id
    )
    return return_ok()


@conversation_blueprint.route("/<string:id>/history", methods=["DELETE"])
def clear_conversation_history(id: str):
    auth_identifier = g.get("authIdentifier")
    conversation_sql_manager.clear_conversation_history(
        auth_identifier=auth_identifier, conversation_id=id
    )
    return return_ok()


@conversation_blueprint.route(
    "/<string:id>/records/<int:order>/log_feedback", methods=["POST"]
)
def log_feedback(id: str, order: int):
    """Saves feedback to cache and logs it to the db"""

    auth_identifier = g.get("authIdentifier")
    conversation_id = id
    record_order = order
    request_as_json: QuestionData = QuestionData(**request.get_json())
    query = request_as_json["query"]
    feedback = request_as_json["feedback"]
    answer = request_as_json["answer"]

    if feedback is None:
        return

    # Update feedback in cache
    conversation_sql_manager.update_feedback(
        auth_identifier=auth_identifier,
        conversation_id=conversation_id,
        message_id=record_order,
        feedback=Feedback(
            value=feedback["value"],
            message=feedback["message"],
            choice=feedback["choice"],
        ),
    )

    logger.debug(f"Successfully recorded feedback: {feedback}")

    return return_ok()
