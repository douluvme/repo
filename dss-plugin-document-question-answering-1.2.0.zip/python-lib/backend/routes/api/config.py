from flask import Blueprint, Response, request
from typing import Dict, List, Union, Any
from backend.utils.dataiku_api import dataiku_api
from backend.utils.knowledge_filters import get_current_filter_config, get_knowledge_bank_name
from backend.utils.llm_utils import get_llm_capabilities
from backend.utils.fonts_utils import convert_font_to_base64
from ..utils import return_ok
from llm_assist.logging import logger
import dataiku
import dataikuapi
import requests
import mimetypes

config_blueprint = Blueprint("config", __name__, url_prefix="/config")


def format_feedback_choices(choices: List[Any]):
    choices_final = []
    for choice in choices:
        try:
            choices_final.append(str(choice))
        except Exception as e:
            logger.warning("choice can't be parsed to str")
    return choices_final


def get_user(headers):
    try:
        auth_info = dataiku.api_client().get_auth_info_from_browser_headers(headers)
        user = auth_info["authIdentifier"]
    except (dataikuapi.utils.DataikuException, requests.exceptions.HTTPError) as e:
        print(f"Exception occurred: {str(e)}")
        user = "user_not_found"
    return user

def build_image_url(path, content_type):
    project = dataiku_api.default_project_key
    return f"/dip/api/projects/folder-edition/preview-image?projectKey={project}&type=LIB&path={path}&contentType={content_type}"
def get_all_images(item, imgs):
    if "list" in dir(item):
        for child in item.list():
            get_all_images(child, imgs)
    else:
        imgs.append(item.path)
def find_image_file(library, images, image_name_prefix):
    for file_path in images:
        if image_name_prefix in file_path and mimetypes.guess_type(file_path)[0].startswith('image'):
            return library.get_file(file_path)
    return None
    
def get_advanced_ui_customization():
    client = dataiku.api_client()
    project = client.get_project(dataiku_api.default_project_key)
    library = project.get_library()
    answer_folder = library.get_folder("answer")
    logo_img = None
    icon_img = None
    css_file = None
    converted_fonts = None
    if answer_folder:
        folder = library.get_folder("/answer/images")
        if folder:
            images = []
            get_all_images(folder, images)
            logo_img = find_image_file(library, images, "logo")
            icon_img = find_image_file(library, images, "answer-icon")
        css_file = library.get_file("/answer/custom.css")
        font_folder_path = "/answer/fonts"
        fonts_css = library.get_file(f"{font_folder_path}/fonts.css") 
        if fonts_css:
            converted_fonts = convert_font_to_base64(font_folder_path, library, fonts_css.read())
    return {
        "logo_img": build_image_url(path=logo_img.path, content_type=mimetypes.guess_type(logo_img.path)[0]) if logo_img else None,
        "answer_icon": build_image_url(path=icon_img.path, content_type=mimetypes.guess_type(icon_img.path)[0]) if icon_img else None,
        "css": css_file.read() if css_file else None,
        "fonts": converted_fonts if converted_fonts else None
    }


@config_blueprint.route("/get_ui_setup", methods=["GET"])
def get_ui_setup() -> Response:
    """
    Fetches the configuration settings for UI setup from Dataiku and returns them.

    Returns:
        Response: A Flask response object containing the UI setup data.
    """
    config: Dict[str, str] = dataiku_api.webapp_config
    examples: List[str] = config.get("example_questions",[])
    title: str = config.get("web_app_title")
    subtitle: str = config.get("web_app_subheading")
    lang: str = config.get("language", "en")
    placeholder: str = config.get("web_app_input_placeholder", "")
    feedback_positive_choices: List[str] = format_feedback_choices(
        config.get("feedback_positive_choices", [])
    )
    feedback_negative_choices: List[str] = format_feedback_choices(
        config.get("feedback_negative_choices", [])
    )
    filters_config = get_current_filter_config()
    knowledge_bank_id = config.get("knowledge_bank_id", None)
    activate_knowledge_bank = config.get("activate_knowledge_bank", True)

    knowledge_bank_name = get_knowledge_bank_name(knowledge_bank_id)
    knowledge_bank_custom_name = config.get("knowledge_bank_custom_name", None)
    llm_caps = get_llm_capabilities()
    headers = dict(request.headers)
    disclaimer = config.get("disclaimer", "")
    result: Dict[str, Union[str, List[str], bool]] = {
        "examples": examples,
        "title": title,
        "subtitle": subtitle,
        "language": lang,
        "input_placeholder": placeholder,
        "project": dataiku_api.default_project_key,
        "upload_folder_id": config.get("upload_folder"),
        "feedback_negative_choices": feedback_negative_choices,
        "feedback_positive_choices": feedback_positive_choices,
        "filters_config": filters_config,
        "knowledge_bank": {"knowledge_bank_id": knowledge_bank_id, 
                           "knowledge_bank_name": knowledge_bank_name, 
                           "activate": activate_knowledge_bank, 
                           "knowledge_bank_custom_name": knowledge_bank_custom_name} if knowledge_bank_id else None,
        "llm_capabilities": llm_caps,
        "llm_id": config.get("llm_id", ""),
        "user": get_user(headers),
        "allow_general_feedback": config.get("allow_general_feedback", False),
        "disclaimer": disclaimer,
        "ui_customization": get_advanced_ui_customization(),
    }
    return return_ok(data=result)
