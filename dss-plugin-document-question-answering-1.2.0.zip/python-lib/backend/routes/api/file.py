from flask import Blueprint, request, g
from ..utils import return_ok, before_request, return_ko
from backend.utils.dataiku_api import dataiku_api
import dataiku
from llm_assist.logging import logger
from flask import Blueprint, request, Response
from typing import Dict, Any
from werkzeug.utils import secure_filename
import time

file_blueprint = Blueprint("file", __name__, url_prefix="/file")


@file_blueprint.before_request
def before_upload_request():
    before_request()


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_CONTENT_LENGTH = 1 * 1024 * 1024  # 1MB limit


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@file_blueprint.route("/upload", methods=["POST"])
def upload_file() -> Response:
    """
    Upload file to a manged folder selected in webapp settings
    Returns:
        Response: A Flask response object containing the upload data.
    """
    logger.info(f"upload file")
    auth_identifier = g.get("authIdentifier")

    try:
        if 'image' not in request.files:
            raise Exception('No file part')

        file = request.files['image']

        if file.filename == '':
            raise Exception('No selected file')

        if file and allowed_file(file.filename):
            config: Dict[str, str] = dataiku_api.webapp_config
            filename = secure_filename(
                f"{auth_identifier}_{int(time.time())}_{file.filename}")
            dataiku.Folder(config.get("upload_folder")
                           ).upload_stream(filename, file)
            return return_ok(data={'file_path': filename}), 200

        raise Exception('Invalid file type or size')

    except Exception as e:
        logger.error(f"Error occured wile uploading file: {e}")
        return return_ko(str(e)), 400


@file_blueprint.route("/delete", methods=["POST"])
def delete_file() -> Response:
    # Delete a specific file from the managed folder
    request_as_json = request.get_json()
    try:
        file_path = request_as_json["file_path"]
        config: Dict[str, str] = dataiku_api.webapp_config
        upload_folder: str = config.get("upload_folder")
        managedFolder = dataiku.Folder(upload_folder)
        managedFolder.delete_path(file_path)
        return return_ok(), 200
    except Exception as e:
        logger.error(f"Error occured wile deleting file: {e}")
        return return_ko("Error occured wile deleting file"), 400
