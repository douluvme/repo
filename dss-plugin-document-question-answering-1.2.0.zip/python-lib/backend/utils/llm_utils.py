
from typing import Dict
from backend.utils.dataiku_api import dataiku_api
import dataiku


def compare_versions(version1, version2):
    # Split the version strings into parts
    parts1 = map(int, version1.split('.'))
    parts2 = map(int, version2.split('.'))
    
    # Compare each part
    for part1, part2 in zip(parts1, parts2):
        if part1 < part2:
            return -1
        elif part1 > part2:
            return 1
    # If all parts are equal, the versions are equal
    return 0

def get_llm_capabilities() -> Dict[str, bool]:
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id")
    multi_modal, streaming = False, False
    settings = dataiku.get_dss_settings()
    dss_version = settings["version"]["product_version"]
    # Split the llm_id to extract the connection type and model
    parts = llm_id.split(":")
    if len(parts) >= 3:
        connexion, _, model = parts[:3]
        streaming = (connexion == "openai" and model.startswith("gpt")) or (connexion == "bedrock" and any(
            model.startswith(prefix) for prefix in ["amazon.titan-", "anthropic.claude-"]))
        multi_modal = (connexion == "openai" and model == "gpt-4-vision-preview") or (
            connexion == "vertex" and model == "gemini-pro-vision")
    if compare_versions(dss_version, "12.5.0") >= 0:
        return {"multi_modal": multi_modal, "streaming": streaming}
    else:
        return {"multi_modal": False, "streaming": False}

def get_llm_completion():
    config: Dict[str, str] = dataiku_api.webapp_config
    llm_id = config.get("llm_id")
    llm = dataiku.api_client().get_default_project().get_llm(
    llm_id)
    completion = llm.new_completion()
    completion.settings["maxOutputTokens"] = 2048
    return completion