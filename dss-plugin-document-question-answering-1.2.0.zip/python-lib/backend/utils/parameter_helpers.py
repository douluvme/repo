
import dataiku
from .knowledge_filters import get_knowledge_dataset_and_filter_columns
from solutions.prompts import CODE_GENERATION_PROMPT


def get_knowledge_bank_metas_choices(config, is_multi_select=False):
    knowledge_bank_id = config.get("knowledge_bank_id")
    filer_config = get_knowledge_dataset_and_filter_columns(
        knowledge_bank_id, False)
    
    choices = {
            "choices": [{"value": meta, "label": meta} for meta in filer_config['filter_columns']]
        }
    if is_multi_select:
        return choices
    choices["choices"].extend([{"value": "", "label": "None"}])
    return choices


def do(payload, config, plugin_config, inputs):
    parameter_name = payload["parameterName"]
    client = dataiku.api_client()
    current_project = client.get_default_project()

    if parameter_name == "llm_id":

        return {
            "choices": [
                {"value": llm.get("id"), "label": llm.get("friendlyName")} for llm in current_project.list_llms() if llm.get('type') != 'RETRIEVAL_AUGMENTED'
            ]
        }
    elif parameter_name == "knowledge_bank_id":
        return {
            "choices": [{"value": "", "label": "None"}] + [
                {"value": kb.get("id"), "label": kb.get("name")} for kb in current_project.list_knowledge_banks()
            ]
        }
    elif parameter_name == "knowledge_sources_filters":
        return get_knowledge_bank_metas_choices(config, is_multi_select=True)
    elif parameter_name == "knowledge_sources_displayed_metas":
        return get_knowledge_bank_metas_choices(config, is_multi_select=True)
    elif parameter_name == "knowledge_source_url":
        return get_knowledge_bank_metas_choices(config)
    elif parameter_name == "knowledge_source_title":
        return get_knowledge_bank_metas_choices(config)
    elif parameter_name == "knowledge_source_thumbnail":
        return get_knowledge_bank_metas_choices(config)

    else:
        return {
            "choices": [
                {
                    "value": "wrong",
                    "label": f"Problem getting the name of the parameter.",
                }
            ]
        }


def load_n_top_sources_to_log(config):
    """
    Loads the parameter 'n_top_sources_to_log' based on the webapp configuration.

    :param config: dict: Webapp configuration.

    :returns: n_top_sources_to_log: int: The number of sources to log based on the webapp configuration
    """
    DEFAULT_N_SOURCES_TO_LOG = -1
    filter_logged_sources = config.get("filter_logged_sources", True)
    if filter_logged_sources:
        n_top_sources_to_log = config.get("n_top_sources_to_log", DEFAULT_N_SOURCES_TO_LOG)
    else:
        n_top_sources_to_log = DEFAULT_N_SOURCES_TO_LOG
    return n_top_sources_to_log


def load_code_generation_prompt(config):
    code_generation_prompt = CODE_GENERATION_PROMPT
    show_advanced_settings = config.get("show_advanced_settings", False)
    override_code_generation_prompt = config.get("override_code_generation_prompt", False)
    config_code_generation_prompt = config.get("code_generation_prompt", "")
    if (show_advanced_settings) and (override_code_generation_prompt) and (len(config_code_generation_prompt)>0):
        code_generation_prompt = config_code_generation_prompt
    return code_generation_prompt
