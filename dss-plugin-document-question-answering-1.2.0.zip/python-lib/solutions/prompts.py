CITATIONS_PROMPT = """### Citations policy:
- The text you generate must have citations referencing the sources that led to it.
- These citations are really important as they allow to understand which content you leveraged to generate the text. They are done using our own tagging syntax. 
- The syntax to use is '<source_citations><source_index>X</source_index><source_quote>Quote from X</source_quote><source_index>Y</source_index><source_quote>Quote from Y</source_quote><source_index>Z</source_index><source_quote>Quote from Z</source_quote></source_citations>' where:
--> 'X', 'Y' and 'Z' are the numerical indexes of the referenced sources (thus, you can chain several source references when they allowed you to generate the text).
--> 'Quote from X', 'Quote from Y' and 'Quote from Z' are the text quotes from the referenced sources that led to the text generated.
- It is highly important that the citations follow our tagging syntax. Never use other methods such as <sup>source_index</sup> or [source_index]. Keeping our syntax is the only way for us to handle your output.
- Do citations for each sentence or paragraph: choose to apply citations on paragraphs rather than on sentences when the paragraph is a whole that encompasses all the sources that you reference.
- A citation is a source of truth. You can't change neither it's content nor it's language: then, when you are asked to answer in a given language, it is forbidden to change the citation quote's content.


Below are several examples of a texts generated following our citations policy: 

```
<example_citations_1> 
----
- <source index="1">In an overview of the last year, the technology sector recorded a 15% growth, while the renewable energy market outpaced expectations with a 20% increase. This analysis credits the surge in renewable energy to significant investments and a global shift towards sustainable practices.</source>

- <source index="2">Technology stocks emerged as strong performers, with select companies achieving up to 25% gains. The digest attributes this to rapid innovation and market demand for tech solutions, highlighting renewable energy stocks as similarly lucrative investments.<source>

- <source index="3">This forecast suggests continued growth for tech and renewable energy, yet it provides no concrete past performance figures, making it less useful for detailed analysis.</source>

- <source index="4">Details the technological advancements and government subsidies driving renewable energy's growth. It posits this trend as a durable shift in the energy sector, offering promising prospects for future investments.</source>

- <source index="5">Focuses on individual success stories within the tech sector, lacking broader market performance data. Its anecdotal nature offers limited insight into the sector's overall health.</source>
----

Human: Which markets performed the best in the last year?
AI: The technology and renewable energy sectors led last year's market performances, with growth rates of 15% and 20%, respectively <source_citations><source_index>1</source_index><source_quote>the technology sector recorded a 15% growth, while the renewable energy market outpaced expectations with a 20% increase.</source_quote><source_index>2</source_index><source_quote>Technology stocks emerged as strong performers, with select companies achieving up to 25% gains.</source_quote></source_citations>. The standout growth in renewable energy is linked to advances in technology and a shift towards sustainability, indicating a robust trend towards green energy <source_citations><source_index>4</source_index><source_quote>Details the technological advancements and government subsidies driving renewable energy's growth.</source_quote></source_citations>.

Conclusion: The renewable energy sector was the top performer with a 20% growth rate, closely followed by the technology sector. These trends underscore the market's evolving preference for sustainable and innovative solutions.
</example_citations_1>

<example_citations_2> 
----
- <source index="1">Alex, March 15, 2024: Just received my smartwatch, and I'm beyond impressed! The features are exactly as advertised, and the battery life is even better than I expected. It's been a long time since I've been this satisfied with an online purchase.</source>

- <source index="2">Jamie, February 28, 2024: I ordered a set of kitchen knives that were on sale, and they are fantastic. They cut beautifully, and the handle design is very ergonomic. Highly recommend to anyone looking to upgrade their kitchen tools.</source>

- <source index="3">Casey, April 2, 2024: Bought a new gaming headset from the site, and it's a huge disappointment. The sound quality is nowhere near what was promised, and it started having issues just a week after use. Definitely not worth the price.</source>

- <source index="4">Taylor, March 22, 2024: The gardening kit I purchased has been a game-changer for my balcony garden. The quality of the tools is top-notch, and the seeds provided have already started to sprout beautifully. Very pleased with this purchase.</source>

- <source index="5">Jordan, April 1, 2024: Purchased a laptop that was highly rated on the site, but it has been a nightmare. It crashes frequently, and the battery life is atrocious. Contacted customer service, but the response has been less than helpful.</source>
----

Human: What is the general opinion of customers on the products sold this quarter?
AI: Customer reviews on the e-commerce platform for products sold this quarter show a mixed general opinion. Positive feedback highlights satisfaction with product quality and performance, specifically mentioning smartwatches and kitchen knives for exceeding expectations in functionality and design <source_citations><source_index>1</source_index><source_quote>Just received my smartwatch, and I'm beyond impressed! The features are exactly as advertised, and the battery life is even better than I expected.</source_quote><source_index>2</source_index><source_quote>I ordered a set of kitchen knives that were on sale, and they are fantastic. They cut beautifully, and the handle design is very ergonomic.</source_quote></source_citations>. Gardening tools also received praise for their quality and effectiveness, indicating a successful match between product descriptions and actual performance <source_citations><source_index>4</source_index><source_quote>The gardening kit I purchased has been a game-changer for my balcony garden. The quality of the tools is top-notch, and the seeds provided have already started to sprout beautifully. Very pleased with this purchase.</source_quote></source_citations>.

However, not all reviews are favorable, with significant complaints about electronics, such as gaming headsets and laptops. Customers reported issues with product quality, including poor sound quality and technical malfunctions, leading to dissatisfaction and concerns about value for money <source_citations><source_index>3</source_index><source_quote>Bought a new gaming headset from the site, and it's a huge disappointment. The sound quality is nowhere near what was promised, and it started having issues just a week after use. Definitely not worth the price.</source_quote><source_index>5</source_index><source_quote>Purchased a laptop that was highly rated on the site, but it has been a nightmare. It crashes frequently, and the battery life is atrocious.</source_quote></source_citations>.

Conclusion: The overall customer sentiment this quarter is polarized, with high satisfaction in the home goods and personal device categories contrasting sharply with negative experiences in electronics. This suggests that while some product lines are meeting or exceeding customer expectations, others may require attention from manufacturers and the platform to address quality and customer service issues.
</example_citations_2>
```

### CONTEXT SOURCES: 
"""

CODE_GENERATION_PROMPT = """### Code generation policy:
Only generate code when it is implied in the question and, when you do:
- The code you generate must be wrapped around <gcb> tags. This is important as it allows to differentiate the code from the text and to ensure that the code is properly formatted.
- The code tagging syntax to use is then '<gcb>language_name Code here</gcb>' where:
--> 'language_name' is the programming language of the code snippet.
--> 'Code here' is the code you generated.
--> The code should be valid and runnable.
--> The code should be concise and relevant to the context.
--> The code should not contain any sensitive information.
 
Below are several examples of code generated following our code generation policy: 
```
Human: Can you provide me with a code snippet to print "Hello, World!" in Python?
AI: Sure, here is the code snippet:
<gcb>python print("Hello, World!")</gcb>
Human: Can you give me the equivalent code in Js?
AI: Here is the code snippet:
<gcb>python console.log("Hello, World!");</gcb>
Human: Give me a vue template to display a list of items.
AI: Here is the code snippet:
<gcb>vue <template> <ul> <li v-for="item in items" :key="item.id"> {{ item.name }} </li> </ul> </template></gcb>
```
"""