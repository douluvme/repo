import json
from backend.utils.dataiku_api import dataiku_api
from typing import Any, List, Dict, Union, Optional
from backend.utils.rag_sources import map_rag_sources
from langchain.chains import ConversationChain
from llm_assist.logging import logger
from langchain.memory import ConversationBufferMemory
from llm_assist.llm_api_handler import llm_setup
from langchain.schema.document import Document
from langchain.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate
)
from backend.models.base import LlmHistory, Source
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from .knowledge_bank import extract_knowldge_params
from dataiku.core.knowledge_bank import KnowledgeBank
from backend.db.base import CONVERSATION_DEFAULT_NAME
from backend.utils.knowledge_filters import get_current_filter_config
from backend.utils.language_management import get_language_rephrasing_prompt
from backend.utils.parameter_helpers import load_code_generation_prompt
from functools import lru_cache
import dataiku
import base64
from dataikuapi.utils import DataikuException
from backend.utils.llm_utils import get_llm_capabilities, get_llm_completion
from langchain_core.prompt_values import PromptValue
from solutions.dku_conversational_chain import DKUConversationRetrievalChain
from solutions.prompts import CITATIONS_PROMPT#, CODE_GENERATION_PROMPT


class LLM_Question_Answering:
    """LLM_Question_Answering: A class to facilitate the question-answering process using LLM model"""

    def __init__(self, memory_max_token_limit, llm):
        self.project = dataiku_api.default_project
        self.memory_max_token_limit = (memory_max_token_limit,)
        self.llm = llm
        self.knowledge_params = extract_knowldge_params()

        self.memory = ConversationBufferMemory(
            max_token_limit=memory_max_token_limit, return_messages=True
        )

        self.filters_config = get_current_filter_config()

    def get_knowledge_bank_full_name(self, knowledge_bank_id):
        if knowledge_bank_id:
            knowledge_bank = KnowledgeBank(
                knowledge_bank_id, project_key=dataiku_api.default_project_key
            )
            return knowledge_bank.full_name
        else:
            return None

    def update_memory(self, chat_history: List[LlmHistory]) -> None:
        self.memory.clear()
        for item in chat_history:
            inputs = {"input": item["input"]}
            outputs = {"output": item["output"]}

            logger.debug(f"The memory inputs {inputs}")
            logger.debug(f"The memory outputs {outputs}")

            self.memory.save_context(inputs, outputs)

    def __verify_filters(
        self, filters: Dict[str, List[Any]]
    ) -> Optional[Dict[str, List[Any]]]:
        if not filters or not self.filters_config:
            return None
        verified_columns = [
            col
            for col in filters.keys()
            if col in self.filters_config["filter_columns"]
        ]
        verified_filters = {}
        for col in verified_columns:
            verified_values = [
                value
                for value in filters[col]
                if value in self.filters_config["filter_options"][col]
            ]

            verified_filters[col] = verified_values
            # verified_values[0] if len(
            # verified_values) == 1 else verified_values

        return verified_filters

    def b64encode_image_from_path(self, file_path: str):
        """
            Encodes an image from a specified file path to a base64-encoded string.

            Parameters:
            - file_path (str): The path to the image file to be encoded. This path must point to a valid
            image file in the managed folder configured in the webapp.

            Returns:
            - str: A base64-encoded string representing the image. This string can be directly used in data URIs
                or for storage in text-based formats.
        """
        config: Dict[str, str] = dataiku_api.webapp_config
        upload_folder: str = config.get("upload_folder")
        file_folder = dataiku.Folder(upload_folder)
        with file_folder.get_download_stream(file_path) as stream:
            file_content = stream.read()
        base64_encoded = base64.b64encode(file_content)
        img_b64 = base64_encoded.decode('utf-8')
        return img_b64

    def run_llm_with_media(self,
                           act_like_prompt: str,
                           system_prompt: str,
                           user_question: str,
                           query_index: int,
                           file_path: str,
                           chat_history: List[LlmHistory] = []) -> Any:
        """
        Run the LLM with the provided query and file.

        Args:
            act_like_prompt (str): The configured settings prompt.
            system_prompt (str): The system prompt for the LLM
            user_question (str): The user query string
            query_index: int: The index of the query within the conversation. 
            file_path (str): File path of the image uploaded to a managed folder
            chat_history (List[LlmHistory], optional): List of chat histories,
                                                           where each chat history is
                                                           represented as a dictionary with
                                                           inputs and outputs. Defaults to [].

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        response = ""

        try:
            img_b64 = self.b64encode_image_from_path(file_path)
            self.update_memory(chat_history=chat_history)
            conv_chain = self.create_conversation_chain(
                act_like_prompt=act_like_prompt, system_prompt=system_prompt)
            computed_prompt = self.compute_prompt_for_streaming(
                conv_chain=conv_chain, user_question=user_question)
            completion = get_llm_completion()
            completion.cq["messages"].append({
                "role": "user",
                "parts": [
                    {"type": "TEXT", "text": computed_prompt.to_string()},
                    {"type": "IMAGE_INLINE", "inlineImage": img_b64}
                ]
            })
            # Check if it handles streaming or not
            llm_capabilities = get_llm_capabilities()
            if (llm_capabilities["streaming"]):
                for chunk in completion.execute_streamed():
                    yield chunk
            else:
                resp = completion.execute()
            if resp.success:
                response = resp.text
            else:
                logger.error(f"Multimodal completion call failed: resp._raw")
                response = resp._raw
        except DataikuException as e:
            logger.error(f"Dataiku API Error: {e}")
        except FileNotFoundError:
            logger.error("File not found in the managed folder.")
        except IOError as e:
            logger.error(f"I/O Error: {e}")
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")

        yield response

    def create_conversation_chain(
            self,
            act_like_prompt: str,
            system_prompt: str) -> ConversationChain:
        """
            Initializes a ConversationChain with a custom prompt template for generating detailed and friendly AI-human interactions.

            Parameters:
            - act_like_prompt (str): A descriptive string guiding the AI's behavior and language style.
            - system_prompt (str): A system prompt for the AI to follow.

            Returns:
            - ConversationChain: An instance configured with a tailored prompt template, leveraging the provided `act_like_prompt`.
        """
        template = r"""{system_prompt}
        {code_generation_prompt}
        {act_like_prompt}
        Current conversation:
        {{history}}
        Human: {{input}}
        AI Assistant:""".format(act_like_prompt=act_like_prompt, system_prompt=system_prompt, code_generation_prompt=load_code_generation_prompt(dataiku_api.webapp_config))
        qa_prompt = PromptTemplate(
            input_variables=["history", "input"], template=template)

        chain = ConversationChain(
            llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)
        return chain

    def create_conversational_retrieval_chain(self,
                                              act_like_prompt: str,
                                              system_prompt: str,
                                              filters: Optional[Dict[str,
                                                                     List[Any]]] = None,
                                              knowledge_bank_id: str = None) -> DKUConversationRetrievalChain:
        enable_llm_citations = dataiku_api.webapp_config.get(
            "enable_llm_citations", False)
        context_prompt = CITATIONS_PROMPT if enable_llm_citations else "### CONTEXT"
        general_retrieval_template = r""" 
        {act_like_prompt}
        
        {system_prompt}

        {code_generation_prompt}

        {context_prompt}

        ----
        {{context}}
        ----
        """.format(act_like_prompt=act_like_prompt, system_prompt=system_prompt, context_prompt=context_prompt, code_generation_prompt=load_code_generation_prompt(dataiku_api.webapp_config))
        if enable_llm_citations:
            question_prefix = "Leveraging the context sources and our citations policy, "
            question_suffix = " Apply citations referencing the sources folowing the citations policy."
        else:
            question_prefix = "Given the context, "
            question_suffix = ""
        general_user_template = question_prefix + \
            "{question}"+question_suffix+"\nAssistant: "

        logger.debug("Building general_user_template")
        messages = [
            SystemMessagePromptTemplate.from_template(
                general_retrieval_template),
            HumanMessagePromptTemplate.from_template(
                general_user_template)

        ]
        qa_prompt = ChatPromptTemplate.from_messages(messages)
        retriever = self.get_retriever(
            filters=filters, knowledge_bank_id=knowledge_bank_id)
        dku_chain = DKUConversationRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever,
            return_source_documents=True,
            verbose=True,
            condense_question_llm=self.llm,
            chain_type="stuff",
            combine_docs_chain_kwargs={'prompt': qa_prompt},
        )
        return dku_chain

    def compute_prompt_for_streaming(self, conv_chain: ConversationChain,  user_question: str) -> PromptValue:
        """
        Generates a prompt for streaming by processing the user's question and conversation history.

        Steps:
        1. Prepares inputs from the user's question and history.
        2. Builds and returns the final prompt based on these inputs

        Parameters:
        - conv_chain (ConversationChain): Used for input preparation and prompt generation.
        - user_question (str): The user's current question.

        Returns:
        - PromptValue: The generated prompt for the given question.
        """
        inputs = conv_chain.prep_inputs(
            {"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(
            input_list=[{"input": user_question, "history": inputs["history"]}])
        logger.debug(f"Final prompt: {computed_prompt[0][0].to_string()}")
        return computed_prompt[0][0]

    def prepare_qa_chain(self, act_like_prompt: str, system_prompt: str, knowledge_bank_id: str = None,
                         filters: Optional[Dict[str, List[Any]]] = None):
        if not knowledge_bank_id:
            return self.create_conversation_chain(act_like_prompt=act_like_prompt, system_prompt=system_prompt)
        else:
            return self.create_conversational_retrieval_chain(act_like_prompt=act_like_prompt,
                                                              system_prompt=system_prompt,
                                                              filters=filters, knowledge_bank_id=knowledge_bank_id)

    def run_with_capabilities(self, llm_capabilities: Dict[str, bool],
                              qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                              user_question: str,
                              query_index: str,
                              knowledge_bank_id: str = None,
                              filters: Optional[Dict[str, List[Any]]] = None,
                              chat_history: Optional[Any] = None):
        if (llm_capabilities["streaming"]):
            return self.run_streaming_mode(qa_chain=qa_chain, user_question=user_question, query_index=query_index,
                                           knowledge_bank_id=knowledge_bank_id, filters=filters, chat_history=chat_history)
        else:
            return self.run_non_streaming_mode(qa_chain=qa_chain, user_question=user_question, query_index=query_index,
                                               knowledge_bank_id=knowledge_bank_id, filters=filters, chat_history=chat_history)

    def format_history(self, chat_history):
        return [
            (item["input"], item["output"]) for item in chat_history
        ]

    def run_streaming_mode(self, qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                           user_question: str,
                           query_index: str,
                           knowledge_bank_id: str = None,
                           filters: Optional[Dict[str, List[Any]]] = None,
                           chat_history: Optional[Any] = None):
        question_context = None
        if not knowledge_bank_id:
            computed_prompt = self.compute_prompt_for_streaming(
                conv_chain=qa_chain, user_question=user_question)
        else:
            [computed_prompt, question_context] = qa_chain.prepare_final_answer_prompt(
                inputs={"question": user_question, "chat_history": self.format_history(chat_history)})

        logger.debug(
            f"Final prompt:  {computed_prompt.to_string()}")
        completion = get_llm_completion()
        completion.cq["messages"].append({
            "role": "user",
            "parts": [
                {"type": "TEXT",
                    "text": computed_prompt.to_string()},
            ]
        })
        for chunk in completion.execute_streamed():
            yield chunk
        if knowledge_bank_id:
            # Send sources and filters at the end of the streaming
            yield self.get_as_json(question_context, filters=filters)

    def run_non_streaming_mode(self,
                               qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                               user_question: str,
                               query_index: str,
                               chat_history: List[LlmHistory] = [],
                               knowledge_bank_id: str = None,
                               filters: Optional[Dict[str, List[Any]]] = None):
        if not knowledge_bank_id:
            yield self.get_as_json(qa_chain.predict(input=user_question), filters=filters)
        else:
            response = qa_chain(
                {"question": user_question, "chat_history": self.format_history(chat_history)})
            yield self.get_as_json(response, filters=filters)

    def run_llm(
        self,
        act_like_prompt: str,
        system_prompt: str,
        user_question: str,
        query_index: int,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        knowledge_bank_id: str = None,
    ) -> Any:
        """
        Run the LLM with the provided query and chat history.

        Args:
            act_like_prompt (str): The configured settings prompt.
            system_prompt (str): The system prompt for the LLM
            user_question (str): The user query string
            query_index: int: The index of the query within the conversation. 
            chat_history (List[LlmHistory], optional): List of chat histories,
                                                           where each chat history is
                                                           represented as a dictionary with
                                                           inputs and outputs. Defaults to [].
            filters (Optional[Dict[str, List[Any]]]): Selected filters to be applied
            knowledge_bank_id: The knowledge bank DSS id

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        self.update_memory(chat_history=chat_history)

        logger.debug(f"The act like prompt is: {act_like_prompt}")
        logger.debug(f"The system prompt is: {system_prompt}")
        try:
            llm_capabilities = get_llm_capabilities()
            qa_chain = self.prepare_qa_chain(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                knowledge_bank_id=knowledge_bank_id,
                filters=filters)
            return self.run_with_capabilities(llm_capabilities=llm_capabilities,
                                              qa_chain=qa_chain,
                                              user_question=user_question,
                                              query_index=query_index,
                                              knowledge_bank_id=knowledge_bank_id,
                                              filters=filters,
                                              chat_history=chat_history)
        except Exception as e:
            logger.error(f"Service Got exception:{e}")
            return "ERROR"

    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any]],
        filters: Optional[Dict[str, List[Any]]] = None,
        query_index: int = 0
    ) -> Dict[str, Any]:
        if isinstance(generated_answer, str):
            return {"answer": generated_answer, "sources": [], "filters": filters}
        else:
            if isinstance(generated_answer, dict):
                source_documents: List[Document] = generated_answer.get(
                    "source_documents", []
                )
                answer = generated_answer.get("answer", "")
                sources = []
                for document in source_documents:
                    source_content = document.page_content
                    source_metadata = document.metadata

                    sources.append(dict(
                        Source(
                            excerpt=source_content, metadata=source_metadata
                        )))

                sources = map_rag_sources(sources)
                return {"answer": answer, "sources": sources, "filters": filters}
            else:
                return None

    def transform_filters_for_pinecone(self, filters):
        transformed_filters = []
        for key, value in filters.items():
            if isinstance(value, list) and len(value) >= 2:
                or_filter = {'$or': [{key: v} for v in value]}
                transformed_filters.append(or_filter)
            elif len(value) == 1:
                transformed_filters.append({key: value[0]})
            else:
                raise ValueError("No valid filters provided.")

        return {'$and': transformed_filters} if len(transformed_filters) > 1 else transformed_filters[0]

    def transform_filters_for_chroma_db(self, filters):
        transformed_filters = []

        for key, value in filters.items():
            if isinstance(value, list) and len(value) >= 2:
                or_filter = {'$or': [{key: v} for v in value]}
                transformed_filters.append(or_filter)
            elif len(value) == 1:
                transformed_filters.append({key: value[0]})
            else:
                raise ValueError("No valid filters provided.")

        if len(transformed_filters) > 1:
            return {'$and': transformed_filters}
        elif len(transformed_filters) == 1:
            return transformed_filters[0]
        else:
            raise ValueError("No valid filters provided.")

    def process_filters_for_db(self, filters, vector_db_type):
        logger.debug(f"processing filters for {vector_db_type}")
        if vector_db_type == 'CHROMA':
            return self.transform_filters_for_chroma_db(filters)
        elif vector_db_type == 'FAISS':
            return filters
        elif vector_db_type == 'PINECONE':
            return self.transform_filters_for_pinecone(filters)
        else:
            raise ValueError(
                f"Unsupported database type for filtering: {vector_db_type}")

    @lru_cache(maxsize=None)
    def get_vector_db_type(self, knowledge_bank_id: str = None):
        if knowledge_bank_id:
            return self.project.get_knowledge_bank(knowledge_bank_id).as_core_knowledge_bank()._get()['vectorStoreType']

        return None

    def get_answer_and_sources(  # TODO
        self,
        query: str,
        query_index: int,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        knowledge_bank_id=None,
        file_path: str = None
    ) -> Any:
        """Extracts the answer and its corresponding sources for a given prompt.

        Args:
            query (str): The user query.
            query_index: int: The index of the query within the conversation.
            chat_history (List[LlmHistory]): A list of prior interactions (optional). Each interaction
                is a dictionary with the question and response.
            filters (Optional[Dict[str, List[Any]]]): A dictionary of filters to apply to the knowledge bank.
            knowledge_bank_id (str): The knowledge bank DSS id
            file_path (str): The file path uploaded into a managed folder

        Returns:
            Dict[str, Union[str, Dict[str, Any]]]: A dictionary containing:
                - 'answer' (str): The generated answer to the prompt.
                - 'sources' (List[Dict]): A list of dict:
                    - 'excerpt' (str): The content of the source.
                    - 'metadata' (Dict[str, str]): Additional metadata about the source.
        """
        logger.debug("Generating response")
        act_like_prompt = ""
        system_prompt = ""
        if knowledge_bank_id:
            act_like_prompt = dataiku_api.webapp_config.get(
                "knowledge_bank_prompt", "")
            system_prompt = dataiku_api.webapp_config.get(
                "knowledge_bank_system_prompt", "Given the following specific context, please give a short answer to the question at the end, If you don't know the answer, just say that you don't know, don't try to make up an answer.")
        else:
            act_like_prompt = dataiku_api.webapp_config.get(
                "primer_prompt", "")
            system_prompt = dataiku_api.webapp_config.get(
                "system_prompt", "The following is a friendly conversation between a human and an AI. The AI is talkative and provides lots of specific details from its context. If the AI does not know the answer to a question, it truthfully says it does not know.")

        vector_db_type = self.get_vector_db_type(knowledge_bank_id)
        verified_filters = filters
        if vector_db_type and filters and len(filters) > 0:
            verified_filters = self.process_filters_for_db(
                self.__verify_filters(filters=filters), vector_db_type)
        logger.debug(
            f"vector_db_type:{vector_db_type}   / filters: {verified_filters}")

        answer_in_question_language = dataiku_api.webapp_config.get(
            "answer_in_question_language", False)
        logger.debug(
            f"answer_in_question_language is set to :{answer_in_question_language}")
        query_prompt = get_language_rephrasing_prompt(
            query, answer_in_question_language=answer_in_question_language)
        if file_path:
            return self.run_llm_with_media(act_like_prompt=act_like_prompt,
                                           system_prompt=system_prompt,
                                           user_question=query_prompt,
                                           chat_history=chat_history,
                                           file_path=file_path,
                                           query_index=query_index
                                           )
        else:
            return self.run_llm(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                user_question=query_prompt,
                query_index=query_index,
                chat_history=chat_history,
                filters=verified_filters,
                knowledge_bank_id=knowledge_bank_id
            )

    def get_search_kwargs(self, filters: Dict[str, List[Any]] = None):
        search_type = self.knowledge_params["search_type"]
        if search_type == "mmr":
            result = {
                "k": self.knowledge_params["k"],
                "fetch_k": self.knowledge_params["mmr_k"],
                "lambda_mult": self.knowledge_params["mmr_diversity"],
            }
        elif search_type == "similarity_score_threshold":
            result = {
                "k": self.knowledge_params["k"],
                "score_threshold": self.knowledge_params["score_threshold"],
            }
        else:
            result = {"k": self.knowledge_params["k"]}
        if filters:
            result["filter"] = filters
        logger.debug('Search kwargs: ', result)
        return result

    def get_retriever(self, filters: Dict[str, List[Any]] = None, knowledge_bank_id: str = None):
        search_type = self.knowledge_params["search_type"]
        logger.debug(f'Search type: {search_type}')

        retriever = KnowledgeBank(
            knowledge_bank_id, project_key=dataiku_api.default_project_key
        ).as_langchain_retriever(
            search_type=search_type,
            search_kwargs=self.get_search_kwargs(filters=filters),
        )
        return retriever

    @staticmethod
    def get_conversation_title_prompt():
        template = """
            Given a user query and a generated answer, write a conversation title that is concise.

            The user query:
            {query}

            The generated text:
            {answer}

            Conditions:
            - Don't wirte a title that contains more than 6 words
        """
        prompt = PromptTemplate.from_template(template)
        return prompt

    def get_conversation_title(self, query: str, answer: str):
        chain = LLMChain(
            llm=self.llm, prompt=LLM_Question_Answering.get_conversation_title_prompt()
        )
        result = chain.run(query=query, answer=answer)
        json_answer = self.get_as_json(result)

        return json_answer.get("answer", CONVERSATION_DEFAULT_NAME)


memory_max_token_limit = int(
    dataiku_api.webapp_config.get("memory_token_limit", 2000))

llm_qa = LLM_Question_Answering(memory_max_token_limit, llm_setup.get_llm())
