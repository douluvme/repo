from backend.utils.dataiku_api import dataiku_api
from llm_assist.logging import logger
from typing import TypedDict

class KnowledgeParams(TypedDict):
    k: int
    search_type: str
    mmr_k: int
    mmr_diversity: float
    score_threshold: float


def extract_knowldge_params():
    prefix = "knowledge_retrieval_"
    config = dataiku_api.webapp_config
    logger.debug('knowledge bank config')
    logger.debug(config)
    
    keys = KnowledgeParams.__annotations__.keys()
    result = {}
    for key in keys:
        if isinstance(key, str):
            key_value = config.get(prefix + key)
            result[key] = key_value
    logger.debug(result)
    return KnowledgeParams(**result)