<template>
  <div class="query-container q-pa-sm self-start" v-if="query">
    <div class="column query-section">
      <div class="row no-wrap">
        <q-avatar color="query-avatar" text-color="white" size="sm" style="font-weight: 500;">
          {{ letterIcon }}
        </q-avatar>
        <div style="margin-left: 0.5rem;">
          <span class="bs-font-medium-3-normal query-text" v-html="queryEl"></span>
          <slot></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import CodeDisplay from './CodeDisplay.vue'

export default defineComponent({
  props: {
    query: {
      type: String,
      required: true
    },
    letterIcon :{
      type: String,
      default: "?"
    }
  },
  methods: {
    escapeHTML(str: string) {
      return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;')
    }
  },
  computed: {
    queryEl() {
      // Detect URLs and make them clickable
      const urlRegex = /(https?:\/\/|www\.)[^\s]+/g
      return this.escapeHTML(this.query)
        .replace(
          urlRegex,
          (url) => `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`
        )
        .replace(/\n/g, '<br>')
    }
  },
  components: { CodeDisplay }
})
</script>
<style>
.bg-brand {
  background: var(--brand);
}
.bg-query-avatar{
  background: var(--bg-query-avatar);
}
.query-container {
  background: var(--bg-query);
  /* background: rgba(4,30,58, 0.5); */
  border-radius: 6px;
  max-width: 95%;
  width: auto;
  align-self: flex-end;
  color: var(--text-brand);
  word-wrap: break-word;
}

.query-section {
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
/* For portrait */
@media (max-width: 767px) {
  .query-container {
    max-width: 90%;
  }
}
.query-text {
  overflow-x: hidden;
  white-space: pre-wrap;
}
</style>
