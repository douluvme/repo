<template>
  <footer class="dku-tiny-text" id="disclaimer">
    <div v-html="disclaimerText"></div>
  </footer>
</template>
<script lang="ts">
import { useUI } from '@/components/composables/use-ui'
import DOMPurify from 'dompurify';
export default {
  computed: {
    disclaimerText() {
      // use dompurify to sanitize the html
      return DOMPurify.sanitize(useUI().setup.value.disclaimer || '');
    }
  },
}
</script>
