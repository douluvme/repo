<template>
  <q-btn unelevated outline no-caps no-wrap class="btn-solution absolute" square>
    <div class="row items-center q-gutter-x-xs">
      <img src="@/assets/icons/dataiku.png" width="15" height="16" />
      <span class="btn-solution-text">Share Your Thoughts</span>
    </div>
    <FeedbackProxyPopup
      :feedback-value="feedbackValue"
      :feedback-options="[]"
      :submit-on-hide="false"
      @save="submitFeedback"
    />
  </q-btn>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import { FeedbackValue, type Feedback } from '@/models'
import { ServerApi } from '@/api/server_api'
import { useSettings } from './composables/use-settings'
const { knowledgeBankSelection } = useSettings()
// Reactive data
const feedbackValue = ref(FeedbackValue.GENERAL)
// Method
function submitFeedback(feedback: Feedback) {
  if (!feedback.message) return
  ServerApi.logGeneralFeedback({ message: feedback.message!, knowledge_bank_id: knowledgeBankSelection.value  ?? ""})
}
</script>

<style scoped>
.btn-solution-text {
  color: #000000;
  font-family: 'SourceSansPro';
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 12px;
}

.btn-solution {
  color: #c8c8c8;
  top: 16px;
  right: 16px;
  z-index: 99;
  border-radius: 4px;
}
</style>
