<template>
  <div class="answer-card q-pa-sm">
    <div class="answer-section column">
      <div class="row no-wrap" style="max-width: 100%">
        <q-icon
          :name="customIcon"
          size="sm"
          style="margin-right: 8px"
          @error="answerIcon = defaultIcon"
        ></q-icon>
        <div class="answer-content">
          <span class="blinking-cursor" v-if="!answer && loading"></span>
          <div v-else class="bs-font-medium-3-normal answer-text">
            <div v-for="(block, index) in answerBlocks" :class="block.type">
              <span v-md="block.value" v-if="block.type == 'markdown'" :style="answerStyle"></span>
              <code-display v-else-if="block.type === 'code'" :value="block.value" />
              <span v-else>
                <q-btn
                  push
                  dense
                  flat
                  color="primary"
                  @click="handleCitationClick(block.index!, index)"
                  @mouseover="openOrCloseCitation(index, true)"
                  @mouseleave="openOrCloseCitation(index, false)"
                >
                  [{{ block.index }}]
                </q-btn>
                <q-popup-proxy
                  :offset="[10, 10]"
                  style="max-width: 400px"
                  v-model="openedCitations[index]"
                >
                  <q-banner style="max-width: 400px; padding: 4px">
                    <b><span style="font-size: 15px">“</span></b
                    ><i>{{ block.value }}</i
                    ><b><span style="font-size: 15px">”</span></b>
                  </q-banner>
                </q-popup-proxy>
              </span>
            </div>
          </div>
          <slot></slot>
        </div>
      </div>
      <div class="feedback-buttons self-end" v-if="answer && !loading">
        <q-icon class="feedback-icon" @click="copyAnswer">
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_copy') }}
          </BsTooltip>
          <copy-icon />
        </q-icon>
        <q-icon class="feedback-icon" v-if="!isNegativeFeedback">
          <thumbs-up :active="isPositiveFeedback" />
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_thumbs_up') }}
          </BsTooltip>
          <feedback-proxy-popup
            v-if="!submitted"
            :feedback-value="FeedbackValue.POSITIVE"
            :feedback-options="feedbackOptionsPositive"
            :submit-on-hide="true"
            @save="(value) => submitFeedback(value)"
          />
        </q-icon>
        <q-icon class="feedback-icon" v-if="!isPositiveFeedback">
          <thumbs-down :active="isNegativeFeedback" />
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_thumbs_down') }}
          </BsTooltip>
          <feedback-proxy-popup
            v-if="!submitted"
            :feedback-value="FeedbackValue.NEGATIVE"
            :feedback-options="feedbackOptionsNegative"
            :submit-on-hide="false"
            @save="(value) => submitFeedback(value)"
          />
        </q-icon>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { isEqual } from 'lodash'
import AnswerIcon from '@/assets/icons/answer-icon.svg'
import { useClipboard } from '@/components/composables/use-clipboard'
import { FeedbackValue, type Feedback } from '@/models'
import { computed, ref, onMounted, onBeforeUnmount, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import CopyIcon from './icons/CopyIcon.vue'
import ThumbsDown from './icons/ThumbsDown.vue'
import ThumbsUp from './icons/ThumbsUp.vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import CodeDisplay from './CodeDisplay.vue'
import { useUI } from './composables/use-ui'
import { mdiConsoleLine } from '@quasar/extras/mdi-v6'

const { isCopySupported, copyToClipboard } = useClipboard()

const { t } = useI18n()

const props = defineProps<{
  answer: string
  feedback: Feedback | null
  typingEffectOn: boolean
  errorState: boolean
  feedbackOptionsNegative: string[]
  feedbackOptionsPositive: string[]
  loading: boolean
}>()

const openedCitations = ref<boolean[]>([])
const emits = defineEmits<{
  (e: 'update:feedback', feedback: Feedback): void
  (e: 'expandSource', info: { sourceIndex: string; citationIndex: string }): void
}>()

const defaultIcon = `img:${AnswerIcon}`
let answerIcon = defaultIcon
const customIcon = computed(() => {
  const icon = useUI().setup.value?.customizations?.answer_icon
  answerIcon = icon ? `img:${icon}` : defaultIcon
  return answerIcon
})
const isNegativeFeedback = computed(() => {
  return props.feedback && props.feedback.value === FeedbackValue.NEGATIVE ? true : false
})

const isPositiveFeedback = computed(() => {
  return props.feedback && props.feedback.value === FeedbackValue.POSITIVE ? true : false
})

const submitted = computed(() => {
  return isNegativeFeedback.value || isPositiveFeedback.value
})

const answerStyle = computed(() => {
  return {
    color: props.answer == t('error_answer') ? 'red' : ''
  }
})

let timeout: ReturnType<typeof setTimeout> | number = 0

const answerBlocks = ref<AnswerBlock[]>([])

const copied = ref<boolean>(false)

async function copyAnswer() {
  if (!isCopySupported.value) return
  const isCopied = await copyToClipboard(props.answer)
  if (!isCopied) return
  copied.value = true
}

function submitFeedback(feedback: Feedback) {
  if (!isEqual(feedback, props.feedback)) {
    emits('update:feedback', feedback)
  }
}
function handleCitationClick(index: string, citationIndex: number) {
  emits('expandSource', { sourceIndex: index, citationIndex: citationIndex.toString() })
}
onMounted(() => {
  timeout = 0
  buildAnswer(props.answer)
})

onBeforeUnmount(() => {
  clearTimeout(timeout)
})

function buildAnswer(answer: string) {
  answerBlocks.value = parseString(answer)
}

watch(
  () => props.answer,
  (newAnswer, oldAnswer) => {
    buildAnswer(newAnswer)
  }
)

interface AnswerBlock {
  type: 'markdown' | 'code' | 'citation'
  value: string
  index?: string
}
function parseString(inputString: string): AnswerBlock[] {
  let blocks = [] as AnswerBlock[]
  const codePattern = /<gcb>((\n|\w+)[\s\S]*?)<\/gcb>/g
  const citationPattern = /<source_index>(\d+)<\/source_index><source_quote>(.*?)<\/source_quote>/g
  let codeMatch, citationMatch
  let index = 0

  while (index < inputString.length) {
    codePattern.lastIndex = index
    citationPattern.lastIndex = index
    codeMatch = codePattern.exec(inputString)
    citationMatch = citationPattern.exec(inputString)
    if (codeMatch || citationMatch) {
      // Take the first match that occurs
      const match =
        codeMatch && citationMatch
          ? codeMatch.index < citationMatch.index
            ? codeMatch
            : citationMatch
          : codeMatch || citationMatch
      // If the match is at the current index, add the block and update the index
      if (match!.index === index) {
        if (match?.index === codeMatch?.index) {
          blocks.push({
            type: 'code',
            value: match![1].trim()
          })
        } else {
          blocks.push({
            type: 'citation',
            index: match![1].trim(),
            value: match![2].trim()
          })
        }
        index = match!.index + match![0].length
        continue
      } else {
        // If the match is not at the current index, add the markdown block and update the index
        blocks.push({
          type: 'markdown',
          value: inputString.substring(index, match!.index).trim()
        })
        index = match!.index
        continue
      }
    } else {
      //Handle ongoing code block
      const lastCodeBlockStart = inputString.lastIndexOf('<gcb>')
      const isOngoingCodeBlock =
        lastCodeBlockStart !== -1 && (inputString.match(/gcb/g) || []).length % 2 !== 0
      if (isOngoingCodeBlock) {
        if (lastCodeBlockStart > index) {
          blocks.push({
            type: 'markdown',
            value: inputString.substring(index, lastCodeBlockStart).trim()
          })
        }
        blocks.push({
          value: inputString.slice(lastCodeBlockStart + '<gcb>'.length).trim(), //  Skip the <gcb> itself
          type: 'code'
        })
        break
      } else {
        blocks.push({
          type: 'markdown',
          value: inputString.substring(index).trim()
        })
        break
      }
    }
  }
  blocks.forEach((block, i) => {
    openedCitations.value[i] = false
  })
  return blocks
}
function openOrCloseCitation(blockIndex: number, open: boolean) {
  openedCitations.value[blockIndex] = open
}
</script>

<style lang="scss" scoped>
.answer-card {
  max-width: 95%;
  width: auto;
  background: white; //rgba(230, 247, 246, 0.6);
  border-radius: 6px;
  padding: 8px;
  align-self: flex-start;
}

.answer-section {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  max-width: 100%;
}

.answer-content {
  flex-grow: 1;
  word-wrap: break-word;
  overflow: hidden;
  /* Prevents overflowing */
}

.feedback-buttons {
  display: flex;
  color: #6666;
}

.feedback-icon.active {
  color: var(--brand);
}

.feedback-icon,
.copy-icon {
  margin-right: 8px;
  cursor: pointer;
  align-self: flex-start;
}

.answer-text {
  max-width: 100%;
  color: #444;
  margin-bottom: 6px;
}

.blinking-cursor {
  display: inline-block;
  width: 6px;
  height: 20px;
  background-color: #444444;
  animation: blink 0.8s infinite;
}

@keyframes blink {
  0%,
  100% {
    opacity: 0;
  }

  50% {
    opacity: 1;
  }
}

.answer-text a {
  color: var(--brand);
  text-decoration: none;
  transition: color 0.3s ease;
}

.answer-text a:hover {
  color: var(--brand);
  text-decoration: underline;
}

@media (max-width: 767px) {
  .answer-card {
    max-width: 90%;
  }
}

:deep(code) {
  white-space: break-spaces;
}

div.citation {
  display: inline-block;
}

div.markdown {
  display: inline;
}
</style>
