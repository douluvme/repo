import { ServerApi } from '@/api/server_api'
import {
  ResponseStatus,
  type QuestionData,
  type Feedback,
  type AnswerRequest,
  type AnswerResponse,
  type AnswerData
} from '@/models'
import type { Conversation } from '@/models/conversation'
import { ref, computed, watch } from 'vue'
import type { Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { nanoid } from 'nanoid'
import { useRouter } from 'vue-router'
import { useConversations } from './use-conversations'
import { createNotification } from '@/common/utils'
import { useSettings } from './use-settings'
import { WT1iser } from '@/common/wt1'

import { WebSocketApi, type WebSocketEventHandlers } from '@/api/websocket_api'

const initData: QuestionData = {
  id: '',
  query: '',
  answer: '',
  filters: {},
  sources: [],
  file_path: '',
  feedback: null
}
const currentData = ref<QuestionData>({ ...initData })
const currentConversation = ref<Conversation | null>(null)
const loadingQuestion = ref<boolean>(false)

export function useConversation(id: Ref<string | null>) {
  const { t } = useI18n()

  const { getUserConversations, conversations } = useConversations()
  const router = useRouter()

  const loading = ref<boolean>(false)
  const error = ref<any>(null)

  const errorState = ref<boolean>(false)

  const { filtersSelections, knowledgeBankSelection } = useSettings()

  const queryFilters = computed(() => {
    const result: Record<string, any[]> = {}
    if (knowledgeBankSelection.value) {
      for (const key in filtersSelections.value) {
        if (filtersSelections.value[key] && filtersSelections.value[key].length > 0) {
          result[key] = filtersSelections.value[key]
        }
      }
    }
    return Object.keys(result).length > 0 ? result : null
  })

  function createTmpId() {
    return `_${nanoid()}`
  }

  function handleErrorResponse(response: any) {
    WT1iser.actionError(
      'handleErrorResponse',
      router.currentRoute.value.name,
      currentConversation.value?.data.length || 0,
      response
    )
    console.debug("Error:", response)
    loadingQuestion.value = false
    errorState.value = true
    const errorAnswerTranslated = t('error_answer')
    const errorMsgTranslated = t('error_message')
    currentData.value = {
      ...currentData.value,
      answer: errorAnswerTranslated
    }
    updateCurrentConversation()

    currentData.value = { ...initData }
    if (response.status && response.status == ResponseStatus.KO) {
      createNotification('negative', response.message)
    } else {
      createNotification('negative', errorMsgTranslated)
    }
  }

  const isNew = computed(() => {
    return id.value == null || id.value.startsWith('_')
  })

  async function getConversation() {
    // only get conversation history when not new
    if (isNew.value) return

    loading.value = true

    try {
      if (!id.value) return
      const response = await ServerApi.getConversation(id.value)
      if (response && response.data) {
        currentConversation.value = response.data
      }
    } catch (e) {
      error.value = e
    } finally {
      loading.value = false
    }
  }

  async function reset() {
    loading.value = false
    error.value = null
    currentData.value = { ...initData }
    currentConversation.value = null
    conversations.value.forEach((conv) => { conv.selected = false })
    await getConversation()
  }
  async function deleteFile() {
    if (!currentData.value.file_path) return
    try {
      await ServerApi.deleteFile(currentData.value.file_path!)
      currentData.value = {
        ...currentData.value,
        file_path: ''
      }
    } catch (error) {
      createNotification('negative', t('delete_failed'))
    }
  }
  async function uploadFile(formData: FormData) {
    try {
      const response = await ServerApi.uploadFile(formData)
      if (response.status == ResponseStatus.OK) {
        currentData.value = {
          ...currentData.value,
          file_path: String(response.data.file_path)
        }
        createNotification('positive', t('upload_successful'))
      } else {
        throw Error
      }
    } catch (error) {
      createNotification('negative', t('upload_failed'))
    }
  }
  function stopQuery() {
    console.debug('Stoping query', currentData.value)
    loadingQuestion.value = false
    WebSocketApi.sendLogQuery({
      ...currentData.value,
      conversation_id: isNew.value ? '' : id.value
    })
  }
  function updateCurrentConversation() {
    if (currentConversation.value?.data.length && currentConversation.value?.data.length > 0) {
      currentConversation.value.data[currentConversation.value?.data.length - 1] = currentData.value
    }
  }

  async function sendQuestion() {
    WT1iser.action(
      'sendQuestion',
      router.currentRoute.value.name,
      currentConversation.value?.data.length || 0
    )
    if (!currentData.value.query) return

    loadingQuestion.value = true

    currentData.value = {
      ...initData,
      query: currentData.value.query,
      file_path: currentData.value.file_path,
      filters: queryFilters.value
    }
    if (isNew.value) {
      router.push({ path: `/conversation/${createTmpId()}` })
    }
    try {
      fetchAnswer()
    } catch (e) {
      handleErrorResponse(e)
    }
  }
  function handleQueryResponse(data: any) {
    console.debug('Query response:', data)
    try {
      const resp = JSON.parse(data)
      if (resp.status === ResponseStatus.OK) {
        if (loadingQuestion.value) {
          currentData.value = {
            ...currentData.value,
            answer: currentData.value.answer + resp.data.answer,
            sources: resp.data.sources ?? [],
            filters: currentData.value.filters ? currentData.value.filters : resp.data.filters ?? null
          }
          updateCurrentConversation()
        }
      } else {
        handleErrorResponse(resp)
        return;
      }
    } catch (e) {
      console.error('Error:', e)
    }
  }
  function handlerWSDisconnect() {
    loadingQuestion.value = false
  }
  async function handleLogQueryComplete(response: any) {
    const resp: AnswerResponse = JSON.parse(response)
    console.debug('Query complete event received', resp)
    if (resp.status == ResponseStatus.OK) {
      if (isNew.value) {
        const data = resp.data as AnswerData
        if (currentConversation.value) {
          currentConversation.value.name = data.conversation_infos.name
          conversations.value = conversations.value.map((conv) => {
            if (conv.id === data.conversation_infos.id)
              return {
                ...conv,
                name: data.conversation_infos.name
              }
            return conv
          })
        }
      }
      loadingQuestion.value = false
      updateCurrentConversation()
      currentData.value = { ...initData }
      if (isNew.value) {
        // trigger a list conv refresh
        await getUserConversations()
        await router.push({ path: `/conversation/${resp.data.conversation_infos.id}` })
      }
    } else {
      handleErrorResponse(resp)
    }
  }
  function fetchAnswer() {
    loadingQuestion.value = true
    if (isNew.value) {
      currentConversation.value = startTmpConv()
      conversations.value = [{ ...currentConversation.value }, ...conversations.value]
    }
    currentConversation.value?.data.push(currentData.value)
    const question = currentData.value.query
    const filePath = currentData.value.file_path

    let query_index_: number = currentConversation.value?.data.length ?? currentConversation.value?.data.length! - 1;
    console.debug(`Current query index is ${query_index_}`)

    const queryData: AnswerRequest = {
      conversation_id: id.value,
      query: question,
      query_index: query_index_,
      filters: queryFilters.value,
      file_path: filePath,
      knowledge_bank_id: knowledgeBankSelection.value ?? ''
    }
    try {
      const handlers: WebSocketEventHandlers = {
        onMessage: handleQueryResponse,
        onError: (data) => handleErrorResponse(JSON.parse(data)),
        onDisconnect: handlerWSDisconnect,
        onLogQueryComplete: handleLogQueryComplete
      }
      WebSocketApi.setupHandlers(handlers)
      WebSocketApi.sendMessage(queryData)
    } catch (e) {
      console.debug('Error:', e)
      handleErrorResponse(e)
    }
  }

  function startTmpConv() {
    const conversation: Conversation = {
      auth_identifier: '',
      id: createTmpId(),
      data: [],
      name: '',
      timestamp: Date.now() / 1000,
      selected: true
    }
    return conversation
  }

  async function clearHistory() {
    WT1iser.action(
      'clearHistory',
      router.currentRoute.value.name,
      currentConversation.value?.data.length || 0
    )
    try {
      if (!id.value || isNew.value) return
      await ServerApi.clearHistory(id.value)
      if (currentConversation.value?.data) {
        currentConversation.value.data = []
      }
    } catch (e) {
      createNotification('negative', t('error_message'))
    }
  }

  async function logFeedback(record_id: string | number, item: QuestionData, feedback: Feedback) {
    WT1iser.actionFeedback(
      router.currentRoute.value.name,
      currentConversation.value?.data.length || 0,
      feedback.value,
      feedback.message ? true : false,
    )
    if (!id.value || isNew.value) return
    try {
      item.feedback = feedback
      await ServerApi.logFeedback(id.value, record_id, item)

      if (currentConversation.value?.data) {
        currentConversation.value.data = currentConversation.value.data.map((val, index) => {
          if (index === record_id) {
            const result = { ...val, feedback: feedback }
            return result
          }
          return val
        })
      }
      createNotification('positive', t('feedback_succes_message'))
    } catch (e) {
      createNotification('negative', t('error_message'))
    }
  }

  watch(
    () => id.value,
    (newVal, oldVal) => {
      if (!(id.value == null || id.value.startsWith('_') || oldVal?.startsWith('_'))) reset()
    },
    { immediate: true }
  )

  return {
    currentData,
    currentConversation,
    sendQuestion,
    stopQuery,
    loadingQuestion,
    errorState,
    reset,
    isNew,
    clearHistory,
    logFeedback,
    uploadFile,
    deleteFile
  }
}
