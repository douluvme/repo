import type { Directive, DirectiveBinding } from 'vue';
import { md } from "@/utils/md";
const Markdown: Directive = {
	beforeMount: markdown,
	updated: markdown,
};

function markdown(el: Element, binding: DirectiveBinding) {
	const value = binding.value.content;
	const translations = binding.value.translations;
	if (typeof value === 'object' && 'value' in value) {
		el.innerHTML = md(value.value, translations,  binding.value.queryIndex, value);
	} else {
		el.innerHTML = md(value ?? '', translations, binding.value.queryIndex);
	}
}

export default Markdown;