<template>
  <div class="user-input-wrapper" :class="{ focused: focused }">
    <FilePreview
      ref="filePreviewRef"
      class="file-preview-wrapper"
      :filePath="filePath"
      :removable="!loading"
      @loaded="adjustTextareaHeight"
      @delete="deleteFile"
      v-if="filePath"
    ></FilePreview>
    <div class="row">
      <textarea
        ref="textAreaRef"
        v-model="internalValue"
        res
        class="query-input"
        :placeholder="inputPlaceholder"
        @keydown="(e: KeyboardEvent) => handleKey(e)"
        @focus="handleFocus(true)"
        @blur="handleFocus(false)"
        :disabled="props.loading"
        :style="withUploadStyle"
      >
      </textarea>
      <FileUploader
        ref="fileUploaderRef"
        class="upload-icon"
        @uploadFile="(f) => emits('uploadFile', f)"
        v-if="fileInputEnabled"
      ></FileUploader>
      <q-icon
        v-if="!loading"
        name="send"
        class="cursor-pointer send-icon"
        @click="emits('send')"
        size="xs"
        :style="activeStyle"
      >
        <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
          {{ $t('tooltip_send') }}
        </BsTooltip>
      </q-icon>
      <q-icon
        v-else-if="streamingEnabled"
        :name="mdiStopCircleOutline"
        class="spinner-wrapper"
        size="sm"
      ></q-icon>
      <div v-else class="spinner-wrapper">
        <q-spinner size="sm" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { useSync } from '@/components/composables/use-sync'
import { watch } from 'vue'
import FileUploader from '@/components/FileUploader.vue'
import FilePreview from '@/components/FilePreview.vue'
import { mdiStopCircleOutline } from '@quasar/extras/mdi-v6'

const props = defineProps<{
  value: string
  loading: boolean
  inputPlaceholder: string
  fileInputEnabled?: boolean
  streamingEnabled?: boolean
  filePath?: string
}>()

const emits = defineEmits([
  'send',
  'enterkey',
  'update:value',
  'sizeChange',
  'uploadFile',
  'deleteFile',
  'fileChange',
  'stop'
])
const internalValue = useSync(props, 'value', emits)
const focused = ref(false)
const textAreaRef = ref<InstanceType<typeof HTMLElement> | null>(null)
const fileUploaderRef = ref<InstanceType<typeof FileUploader> | null>(null)
const filePreviewRef = ref<InstanceType<typeof FilePreview> | null>(null)
const withUploadStyle = computed(() => {
  if (props.fileInputEnabled) {
    return {
      paddingLeft: '36px',
      maxHeight: props.filePath ? '40px' : '100px'
    }
  }
})
function handleKey(e: KeyboardEvent) {
  adjustTextareaHeight()

  if (e.key === 'Enter') {
    e.stopPropagation()
    if (!e.shiftKey) {
      // Prevent the default Enter key behavior and emit the 'enterkey' event
      e.preventDefault()
      emits('enterkey')
    }
  }
}
watch(
  () => props.filePath,
  (newFilePath) => {
    if (!newFilePath) deleteFile()
    emits('fileChange', newFilePath)
  }
)
watch(internalValue, () => {
  setTimeout(() => {
    adjustTextareaHeight()
    textAreaRef.value?.focus()
  }, 0)
})
function handleFocus(isFocused: boolean) {
  focused.value = isFocused
}
function adjustTextareaHeight() {
  const textarea = textAreaRef.value
  if (!textarea) return

  const maxHeight = 150
  const minHeight = 40
  if (internalValue.value === '') {
    textarea.style.height = `${minHeight}px` //min-height
  } else {
    // Set to max height if content exceeds it
    // or Expand height to fit content
    textarea.style.height =
      textarea.scrollHeight > maxHeight
        ? `${maxHeight}px`
        : `${Math.max(textarea.scrollHeight, textarea.offsetHeight)}px`
    const scrollHeight = textarea.scrollHeight
    textarea.style.overflowY = scrollHeight <= minHeight ? 'hidden' : 'auto'
  }

  emits('sizeChange', textarea.style.height)
}
const deleteFile = () => {
  emits('deleteFile', props.filePath)
  fileUploaderRef.value?.clearFileInput()
}
const activeStyle = computed(() => ({
  color: props.loading || !internalValue.value ? '#CCCCCC' : 'var(--brand)'
  // cursor: props.loading ? 'wait' : internalValue.value ? 'pointer' : 'not-allowed'
}))
</script>

<style scoped lang="scss">
.user-input-wrapper {
  position: relative;
  border: 1px solid #c8c8c8;
  border-radius: 4px;
  width: 100%;
}
.user-input-wrapper.focused {
  outline: none !important;
  border: 1px solid var(--brand);
}
.user-input-wrapper.disabled {
  background-color: var(--greyscale-grey-lighten-8, #f2f2f2);
}
.query-input {
  padding: 8px 12px;
  height: 40px;
  min-height: 40px;
  max-height: 100px;
  font-size: 16px;
  min-width: calc(100% - 1px);
  max-width: calc(100% - 1px);
  border: none;
  border-radius: 4px;
  resize: none;
  overflow-y: hidden;
}
.query-input:focus {
  outline: none !important;
}
textarea:disabled {
  background: var(--greyscale-grey-lighten-8, #f2f2f2);
}
.file-preview-wrapper {
  margin: 8px;
}
.send-icon,
.spinner-wrapper {
  position: absolute;
  right: 8px;
  bottom: 8px;
  color: var(--brand);
}
.upload-icon {
  position: absolute;
  bottom: 8px;
  left: 8px;
}
.send-icon {
  transform: rotate(-38.48deg);
  padding-bottom: 8px;
  bottom: 5px;
}
</style>
