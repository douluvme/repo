<template>
  <div :style="imgStyle">
    <img :src="endpoint" class="file-preview" :style="imgStyle" @load="emits('loaded')" />
    <q-icon :name="`img:${closeOutline}`" class="cursor-pointer file-preview-close" @click="emits('delete')" size="xs" v-if="removable"/>
  </div>
</template>

<script setup lang="ts">
import { toRefs } from 'vue'
import { computed } from 'vue'
import { useUI } from './composables/use-ui'
import closeOutline from '@/assets/icons/close-outline.svg'
const props = defineProps<{
  filePath: string,
  height?: string,
  width?: string,
  removable?: boolean
}>()
const emits = defineEmits(['loaded', 'delete'])
const { filePath, height, width } = toRefs(props)

const { setup } = useUI()

const imgStyle = computed(() => ({
  maxHeight: height?.value ?? '70px',
  maxWidth: width?.value ?? '100px'
}));
// for now we only handle images
const commonMimeTypes = new Map([
  ['jpeg', 'image/jpeg'],
  ['jpg', 'image/jpeg'],
  ['png', 'image/png']
])
const endpoint = computed(() => {
  const fileExtension = filePath.value.split('.').pop()?.toLowerCase() || ''
  const contentType = commonMimeTypes.get(fileExtension) || 'application/octet-stream'
  return `/dip/api/managedfolder/preview-image?contextProjectKey=${setup.value.projectKey}&itemPath=${encodeURIComponent(
    filePath.value
  )}&projectKey=${setup.value.projectKey}&odbId=${setup.value.uploadFolderId}&contentType=${contentType}`
})
</script>
<style>
.file-preview {
  display: inline;
}
.file-preview-close{
  position: absolute;
  top: 4px;
}
</style>
