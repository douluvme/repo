<template>
  <p class="dku-medium-title">Dataiku Answer</p>
  <p class="dku-text">
    With Dataiku Answer, democratize LLM Chat and RAG access across teams and domains.
    </p>
    <p class="dku-text">
      Connect to your choice of LLM through Dataiku LLM Mesh, select the relevant knowledge bank
    if you want to use Dataiku Answer for more than enterprise chat, and set up relevant web
    application configurations like filters and selected questions.
    </p>
    <p class="dku-text">
      You are ready to
    accelerate the impact of Generative AI across your organization with full control of usage and
    user feedback to optimize impact.
    </p>
</template>
<script lang="ts">
export default {
  name: 'Documentation'
}
</script>
