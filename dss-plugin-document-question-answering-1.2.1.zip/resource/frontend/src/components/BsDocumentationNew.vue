<template>
  <q-btn unelevated outline no-caps class="btn-solution absolute" square  id="feedback-btn-general">
    <div class="row items-center q-gutter-x-xs" style="flex-wrap: nowrap;">
      <img src="@/assets/icons/dataiku.png" width="15" height="16" />
      <span class="btn-solution-text">{{ t('feedback_btn_general') }}</span>
    </div>
    <FeedbackProxyPopup
      :feedback-value="feedbackValue"
      :feedback-options="[]"
      :submit-on-hide="false"
      @save="submitFeedback"
    />
  </q-btn>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import { FeedbackValue, type Feedback } from '@/models'
import { ServerApi } from '@/api/server_api'
import { useSettings } from './composables/use-settings'
import { useI18n } from 'vue-i18n'

const { knowledgeBankSelection } = useSettings()
const { t } = useI18n()
// Reactive data
const feedbackValue = ref(FeedbackValue.GENERAL)
// Method
function submitFeedback(feedback: Feedback) {
  if (!feedback.message) return
  ServerApi.logGeneralFeedback({ message: feedback.message!, knowledge_bank_id: knowledgeBankSelection.value  ?? ""})
}
</script>

<style scoped>
#feedback-btn-general{
  max-width: 170px;
}
.btn-solution-text {
  color: #000000;
  font-family: 'SourceSansPro';
  font-style: normal;
  font-weight: 600;
  font-size: 13px;
  line-height: 12px;
}

.btn-solution {
  color: #c8c8c8;
  top: 16px;
  right: 16px;
  z-index: 99;
  border-radius: 4px;
}
</style>
