<template>
  <div class="answer-card q-pa-sm">
    <div class="answer-section column">
      <div class="row no-wrap" style="max-width: 100%">
        <q-icon
          :name="customIcon"
          size="sm"
          style="margin-right: 8px"
          @error="answerIcon = defaultIcon"
        ></q-icon>
        <div class="answer-content">
          <span class="blinking-cursor" v-if="!answer && loading"></span>
          <div v-else class="bs-font-medium-3-normal answer-text">
            <div
              v-md="{
                content: answer,
                translations: { copy_code: t('copy_code') },
                queryIndex: props.queryIndex
              }"
              :style="answerStyle"
              ref="answerRef"
            ></div>
            <div class="kb_on_off_tag" v-if="kbOn">
              <q-icon size="20px" style="margin-right: 4px;">
                <DbIcon color="currentColor" />
              </q-icon>
              <span
                >{{ t('answer_generated_with_kb') }}</span
              >
            </div>
            <slot></slot>
          </div>
        </div>
      </div>
      <div class="feedback-buttons self-end" v-if="answer && !loading">
        <q-icon class="feedback-icon" @click="copyAnswer">
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_copy') }}
          </BsTooltip>
          <copy-icon />
        </q-icon>
        <q-icon class="feedback-icon" v-if="!isNegativeFeedback">
          <thumbs-up :active="isPositiveFeedback" />
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_thumbs_up') }}
          </BsTooltip>
          <feedback-proxy-popup
            v-if="!submitted"
            :feedback-value="FeedbackValue.POSITIVE"
            :feedback-options="feedbackOptionsPositive"
            :submit-on-hide="true"
            @save="(value) => submitFeedback(value)"
          />
        </q-icon>
        <q-icon class="feedback-icon" v-if="!isPositiveFeedback">
          <thumbs-down :active="isNegativeFeedback" />
          <BsTooltip anchor="top middle" self="bottom middle" class="arrow-bottom">
            {{ $t('tooltip_thumbs_down') }}
          </BsTooltip>
          <feedback-proxy-popup
            v-if="!submitted"
            :feedback-value="FeedbackValue.NEGATIVE"
            :feedback-options="feedbackOptionsNegative"
            :submit-on-hide="false"
            @save="(value) => submitFeedback(value)"
          />
        </q-icon>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { isEqual } from 'lodash'
import AnswerIcon from '@/assets/icons/answer-icon.svg'
import { useClipboard } from '@/components/composables/use-clipboard'
import { FeedbackValue, type Feedback } from '@/models'
import { computed, ref, onMounted, onBeforeUnmount } from 'vue'
import { useI18n } from 'vue-i18n'
import CopyIcon from './icons/CopyIcon.vue'
import ThumbsDown from './icons/ThumbsDown.vue'
import ThumbsUp from './icons/ThumbsUp.vue'
import FeedbackProxyPopup from './FeedbackProxyPopup.vue'
import { useUI } from './composables/use-ui'
import DbIcon from './icons/DbIcon.vue'
const { isCopySupported, copyToClipboard } = useClipboard()

const { t } = useI18n()

const props = defineProps<{
  answer: string
  kbOn: boolean | undefined
  feedback: Feedback | null
  typingEffectOn: boolean
  errorState: boolean
  feedbackOptionsNegative: string[]
  feedbackOptionsPositive: string[]
  loading: boolean
  queryIndex: number
}>()

const emits = defineEmits<{
  (e: 'update:feedback', feedback: Feedback): void
  (
    e: 'expandSource',
    info: { sourceIndex: string; citationIndex: string; queryIndex: string }
  ): void
}>()
const answerRef = ref<HTMLElement>()
const defaultIcon = `img:${AnswerIcon}`
let answerIcon = defaultIcon
const customIcon = computed(() => {
  const icon = useUI().setup.value?.customizations?.answer_icon
  answerIcon = icon ? `img:${icon}` : defaultIcon
  return answerIcon
})
const isNegativeFeedback = computed(() => {
  return props.feedback && props.feedback.value === FeedbackValue.NEGATIVE ? true : false
})

const isPositiveFeedback = computed(() => {
  return props.feedback && props.feedback.value === FeedbackValue.POSITIVE ? true : false
})

const submitted = computed(() => {
  return isNegativeFeedback.value || isPositiveFeedback.value
})

const answerStyle = computed(() => {
  return {
    color: props.answer == t('error_answer') ? 'red' : ''
  }
})

const copied = ref<boolean>(false)

async function copyAnswer() {
  if (!isCopySupported.value) return
  const isCopied = await copyToClipboard(props.answer)
  if (!isCopied) return
  copied.value = true
}

function submitFeedback(feedback: Feedback) {
  if (!isEqual(feedback, props.feedback)) {
    emits('update:feedback', feedback)
  }
}
function addWindowFunctions() {
  if (!(window as any).dkuAnswers_copyToClipboard) {
    ;(window as any).dkuAnswers_copyToClipboard = (element: Element) => {
      const code = decodeURIComponent(element.getAttribute('data-clipboard-text') ?? '')
      copyToClipboard(code)
    }
  }
  if (!(window as any).dkuAnswers_handleCitationClick) {
    ;(window as any).dkuAnswers_handleCitationClick = (
      citationIndex: number,
      sourceIndex: string,
      queryIndex: number
    ) => {
      // Create a new CustomEvent
      const expandSourceEvent = new CustomEvent('expandSource', {
        detail: {
          sourceIndex: sourceIndex,
          citationIndex: citationIndex.toString(),
          queryIndex: props.queryIndex.toString()
        }
      })
      const element = document.querySelector(`#query_${queryIndex}_sources`)
      // Dispatch the event on the desired element
      element?.dispatchEvent(expandSourceEvent)
    }
  }
  if (!(window as any).dkuAnswers_showHideQuote) {
    ;(window as any).dkuAnswers_showHideQuote = (elementId: string, show: boolean) => {
      const popup = document.getElementById(elementId)
      if (!popup) return
      const content = popup.children.item(0) as HTMLElement
      if (content) {
        const position = popup.getBoundingClientRect()
        if (position) {
          // position the popup below the citation: 24px below the top of the citation
          content.style.setProperty('top', `${position.top + 24}px`)
        }
        if (show) {
          content.classList.add('show')
        } else {
          content.classList.remove('show')
        }
      }
    }
  }
}
onMounted(() => {
  addWindowFunctions()
})

function cleanup() {
  // Remove global event handlers from the window object
  if ((window as any).dkuAnswers_handleCitationClick) {
    delete (window as any).dkuAnswers_handleCitationClick
  }

  if ((window as any).dkuAnswers_showHideQuote) {
    delete (window as any).dkuAnswers_showHideQuote
  }
  if ((window as any).dkuAnswers_copyToClipboard) {
    delete (window as any).dkuAnswers_copyToClipboard
  }
}
onBeforeUnmount(() => {
  cleanup()
})
</script>

<style lang="scss" scoped>
.answer-card {
  max-width: 95%;
  width: auto;
  background: white; //rgba(230, 247, 246, 0.6);
  border-radius: 6px;
  padding: 8px;
  align-self: flex-start;
}

.answer-section {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  max-width: 100%;
}

.answer-content {
  flex-grow: 1;
  word-wrap: break-word;
  overflow: hidden;
  /* Prevents overflowing */
}

.feedback-buttons {
  display: flex;
  color: #6666;
}

.feedback-icon.active {
  color: var(--brand);
}

.feedback-icon,
.copy-icon {
  margin-right: 8px;
  cursor: pointer;
  align-self: flex-start;
}

.answer-text {
  max-width: 100%;
  color: #444;
  margin-bottom: 6px;
}

.blinking-cursor {
  display: inline-block;
  width: 6px;
  height: 20px;
  background-color: #444444;
  animation: blink 0.8s infinite;
}
.kb_on_off_tag {
  margin-top: 8px;
  color: #666;
}
@keyframes blink {
  0%,
  100% {
    opacity: 0;
  }

  50% {
    opacity: 1;
  }
}

.answer-text a {
  color: var(--brand);
  text-decoration: none;
  transition: color 0.3s ease;
}

.answer-text a:hover {
  color: var(--brand);
  text-decoration: underline;
}

@media (max-width: 767px) {
  .answer-card {
    max-width: 90%;
  }
}

:deep(code) {
  white-space: break-spaces;
}

div.citation {
  display: inline-block;
}

div.markdown {
  display: inline;
}
</style>
<style>
.code-wrapper {
  background-color: #282c34;
  border-radius: 4px;
  color: #f8f8f8;
  font-family: 'Courier New', Courier, monospace;
  word-wrap: break-word;
  overflow-x: hidden;
  max-width: 100%;
  font-size: 14px;
  margin: 8px 0px;
}

.code-container {
  padding: 8px;
  word-wrap: break-word;
  overflow-x: auto;
  white-space: pre-wrap;
  max-width: 100%;
}
:not(pre) > code[class*='language-'],
pre[class*='language-'] {
  background-color: #282c34;
}
.header {
  padding: 8px;
  width: 100%;
  background-color: #202123;
}
.copy {
  cursor: pointer;
}
.copy-text {
  color: var(--greyscale-grey-lighten-4, #999);
}

.citation-popup {
  /* position: relative; */
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  color: var(--q-primary);
}

.citation-quote-popup {
  visibility: hidden;
  max-width: 400px;
  padding: 8px;
  background-color: white;
  color: #555;
}

/* Toggle this class - hide and show the popup */
.citation-popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 0.5s;
  animation: fadeIn 0.5s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
</style>
