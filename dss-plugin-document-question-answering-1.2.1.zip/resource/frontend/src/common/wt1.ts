import type { RouteRecordName } from 'vue-router'
import { useSettings } from '@/components/composables/use-settings'

const { knowledgeBankSelection: selectedknowledgeBankId, filtersSelections } = useSettings()

export class WT1iser {
  public static llmId: string | undefined
  private static webappVersion = '1.0.1'
  private static pluginID = 'ANSWER'

  public static init(llmId: any) {
    this.llmId = llmId
  }

  private static checkFilters(filtersActive: any): boolean {
    if (filtersActive && typeof filtersActive === 'object') {
      return Object.keys(filtersActive).length > 0
    } else {
      return false
    }
  }
  private static prepareEventParams(tab: null | undefined | RouteRecordName) {
    const filterState = this.checkFilters(filtersSelections.value)
    return {
      tab: tab,
      kbActive: selectedknowledgeBankId.value ? true : false,
      filtersActive: filterState,
      llmId: this.llmId,
      webappVersion: this.webappVersion,
      pluginID: this.pluginID
    }
  }
  public static open(tab: null | undefined | RouteRecordName): void {
    const params = this.prepareEventParams(tab)
    console.debug('sol-webapp-open', params)
    if ((window.parent as any).WT1SVC) {
      ;(window.parent as any).WT1SVC.event('sol-webapp-open', params)
    }
  }
  public static action(
    actionsName: string,
    tab: null | undefined | RouteRecordName,
    nQuestions: number
  ): void {
    const params = {
      ...this.prepareEventParams(tab),
      action: actionsName,
      nQuestions: nQuestions
    }
    console.debug('sol-webapp-action', params)
    if ((window.parent as any).WT1SVC) {
      ;(window.parent as any).WT1SVC.event('sol-webapp-action', params)
    }
  }

  public static actionFeedback(
    tab: null | undefined | RouteRecordName,
    nQuestions: number,
    feedbackType: string,
    feedbackHasComment: boolean
  ): void {
    const params = {
      ...this.prepareEventParams(tab),
      action: 'feedback',
      nQuestions: nQuestions,
      feedbackType: feedbackType,
      feedbackHasComment: feedbackHasComment
    }
    console.debug('sol-webapp-action', params)
    if ((window.parent as any).WT1SVC) {
      ;(window.parent as any).WT1SVC.event('sol-webapp-action', params)
    }
  }
  public static actionError(
    actionsName: string,
    tab: null | undefined | RouteRecordName,
    nQuestions: number,
    error: string
  ): void {
    const params = {
      ...this.prepareEventParams(tab),
      action: actionsName,
      nQuestions: nQuestions,
      error: error
    }
    if ((window.parent as any).WT1SVC) {
      ;(window.parent as any).WT1SVC.event('sol-webapp-action', params)
    }
  }
}
