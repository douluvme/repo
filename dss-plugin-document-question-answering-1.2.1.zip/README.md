# Answer


This repo contains the code for Dataiku plugin to run a Answer App.
The code is based on python for backend and Vue3 for the frontend.

## Development:

### Frontend

The web application is built on Node.js and utilizes the Quasar framework.
-   First, go to `resource/frontend`:
    `cd resource/frontend`
-   Then, install the dependencies:
    `yarn install`
-   Finally, run the local server:
    `yarn run dev`

### Backend

The backend is powered by Flask.

-   First, create your virtual environment:
    `python3 -m venv .your_venv_name`
-   Second, activate your virtual environment:
    `source .your_venv_name/bin/activate`
-   Third, install the required packages:
    `pip3 install -r code-env/python/spec/requirements.dev.txt`
-   Finally, run your local Flask server:
    ` python3 python-lib/wsgi.py`

## Web app UI customization
You can rebrand the webapp by applying custom style without changing the webapp code.
- In the Library folder of your DSS project, create an `answer` folder.
- For css changes, add a `custom.css` file inside the `answer` folder, you can find an example below:
    ```css
        :root {
        --brand: #031e3a !important;
        --bg-examples-brand: rgba(3, 30, 58, 0.05) !important;
        --bg-examples-brand-hover: rgba(3, 30, 58,0.07) !important;
        --bg-examples-borders: rgba(3, 30, 58, 0.05) !important;
        --examples-question-marks: #031e3a !important;
        --examples-text: black !important;
        --text-brand: #444 !important;
        }
    .logo-container .logo-img{
        height: 70%; 
        width: 70%;
    }

    ```
- To customize fonts:
    - First, create `fonts` folder inside `answer`
    - Second, add `fonts.css` and define your font like below depending on the format you can provide:
    ```css
    @font-face { 
        font-family: "YourFontName";
        src: url(data:application/octet-stream;base64,your_font_base64);
    }
     @font-face { 
        font-family: "YourFontName";
        src: url('yourFontPublicUrl') format('yourFontFormat');
    }
    ```
    - Finally, add this part to the `custom.css` file:
    ```css
    body,
    div {
        font-family: 'YourFontName' !important;
    }
    ```
- To customize images, create `images` folder where you can import `logo.*` file to change the logo image inside the landing page, and `answer-icon.*` to change the icon of the AI answer.
