from backend.utils.dataiku_api import dataiku_api
from llm_assist.logging import logger
from typing import Dict, List, Any, Optional
from dataiku.core.knowledge_bank import KnowledgeBank
from functools import cache, lru_cache


webapp_config = dataiku_api.webapp_config


def get_knowledge_bank_full_name(knowledge_bank_id):
    if knowledge_bank_id:
        knowledge_bank = KnowledgeBank(
            knowledge_bank_id, project_key=dataiku_api.default_project_key
        )
        return knowledge_bank.full_name
    else:
        return None

@cache
def get_knowledge_bank_name(id: Optional[str]) -> Optional[str]:
    if id is None:
        return None
    project = dataiku_api.default_project

    short_id = id
    if "." in id:
        (project_key, short_id) = id.split(".", 1)
    for kb in project.list_knowledge_banks():
        if kb.get('id') == short_id:
            return kb.get('name', id)
    return None

def get_knowledge_bank_retriever(knowledge_bank_id: str=None, filters: Dict[str, List[Any]]=None, search_type: str=""):
    from backend.utils.parameter_helpers import get_retriever_search_kwargs
    logger.debug(f'Search type: {search_type}')
    
    retriever = KnowledgeBank(
        knowledge_bank_id, project_key=dataiku_api.default_project_key
    ).as_langchain_retriever(
        search_type=search_type,
        search_kwargs=get_retriever_search_kwargs(filters=filters),
    )
    return retriever


@lru_cache(maxsize=None)
def get_vector_db_type(project, knowledge_bank_id: str = None):
    if knowledge_bank_id:
        return project.get_knowledge_bank(knowledge_bank_id).as_core_knowledge_bank()._get()['vectorStoreType']
    return None