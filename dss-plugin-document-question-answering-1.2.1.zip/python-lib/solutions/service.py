from backend.utils.dataiku_api import dataiku_api
from typing import Any, List, Dict, Union, Optional
from backend.utils.rag_sources import map_rag_sources
from langchain.chains import ConversationChain
from llm_assist.logging import logger
from langchain.memory import ConversationBufferMemory
from langchain.retrievers import EnsembleRetriever
from llm_assist.llm_api_handler import llm_setup
from langchain.schema.document import Document
from langchain.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate
)
from backend.models.base import LlmHistory, Source
from langchain.prompts import PromptTemplate
from solutions.knowledge_bank import  get_knowledge_bank_retriever
from backend.db.base import CONVERSATION_DEFAULT_NAME
from backend.utils.knowledge_filters import get_current_filter_config, process_filters_for_db
from backend.utils.language_management import get_language_rephrasing_prompt
from backend.utils.parameter_helpers import (load_knowledge_bank_parameters,
                                             load_prompt_parameters,
                                             check_knowledge_bank_descriptions)
from backend.utils.picture_utils import b64encode_image_from_path
from dataikuapi.utils import DataikuException
from backend.utils.llm_utils import get_llm_capabilities, get_llm_completion
from langchain_core.prompt_values import PromptValue
from solutions.chains.conversation_retrieval import DKUConversationRetrievalChain
from solutions.chains.knowledge_bank_selection import KnowledgeBankSelectionChainHandler
from solutions.chains.conversation_title import ConversationTitleChainHandler
from solutions.prompts.citations import CITATIONS_PROMPT
from solutions.prompts.conversations import CONVERSATION_TITLE_PROMPT, CondensationChainHandler


class LLM_Question_Answering:
    """LLM_Question_Answering: A class to facilitate the question-answering process using LLM model"""

    def __init__(self, memory_max_token_limit, llm):
        # Constructor parameters:
        self.project = dataiku_api.default_project
        self.memory_max_token_limit = (memory_max_token_limit,)
        self.llm = llm
        self.memory = ConversationBufferMemory(
            max_token_limit=memory_max_token_limit, return_messages=True
        )

        # Knowledge bank parameters:
        self.all_knowledge_bank_parameters, self.per_knowledge_bank_parameters = load_knowledge_bank_parameters()
        self.knowledge_bank_ids = self.all_knowledge_bank_parameters["knowledge_bank_ids"]
        self.knowledge_bank_descriptions = self.all_knowledge_bank_parameters["knowledge_bank_descriptions"]
        self.enable_smart_usage_of_the_knowledge_bank = self.all_knowledge_bank_parameters["enable_smart_usage_of_the_knowledge_bank"]
        self.knowledge_bank_vector_db_types = self.all_knowledge_bank_parameters["knowledge_bank_vector_db_types"]
        self.knowledge_bank_weighs = self.all_knowledge_bank_parameters.get("knowledge_bank_weighs")
        self.filters_config = get_current_filter_config()
        self.prompt_parameters = load_prompt_parameters()

        # Chains and chain handlers:
        self.conversation_title_chain = ConversationTitleChainHandler(CONVERSATION_TITLE_PROMPT).get_chain(llm)
        self.condensation_chain_handler = CondensationChainHandler(contensation_prompt="dataiku")
        if self.enable_smart_usage_of_the_knowledge_bank:
            self.knowledge_bank_selection_chain_handler = KnowledgeBankSelectionChainHandler(
                    self.knowledge_bank_ids, self.knowledge_bank_descriptions)
        else:
            self.knowledge_bank_selection_chain_handler = None
        

    def update_memory(self, chat_history: List[LlmHistory]) -> None:
        self.memory.clear()
        for item in chat_history:
            inputs = {"input": item["input"]}
            outputs = {"output": item["output"]}

            logger.debug(f"The memory inputs {inputs}")
            logger.debug(f"The memory outputs {outputs}")

            self.memory.save_context(inputs, outputs)

    def __verify_filters(
        self, filters: Dict[str, List[Any]]
    ) -> Optional[Dict[str, List[Any]]]:
        if not filters or not self.filters_config:
            return None
        verified_columns = [
            col
            for col in filters.keys()
            if col in self.filters_config["filter_columns"]
        ]
        verified_filters = {}
        for col in verified_columns:
            verified_values = [
                value
                for value in filters[col]
                if value in self.filters_config["filter_options"][col]
            ]

            verified_filters[col] = verified_values

        return verified_filters    
    

    def compute_prompt_for_streaming(self, conv_chain: ConversationChain,  user_question: str) -> PromptValue:
        """
        Generates a prompt for streaming by processing the user's question and conversation history.

        Steps:
        1. Prepares inputs from the user's question and history.
        2. Builds and returns the final prompt based on these inputs

        Parameters:
        - conv_chain (ConversationChain): Used for input preparation and prompt generation.
        - user_question (str): The user's current question.

        Returns:
        - PromptValue: The generated prompt for the given question.
        """
        inputs = conv_chain.prep_inputs(
            {"input": user_question, "history": self.memory})
        computed_prompt = conv_chain.prep_prompts(
            input_list=[{"input": user_question, "history": inputs["history"]}])
        return computed_prompt[0][0]


    def prepare_qa_chain(self, act_like_prompt: str, system_prompt: str, filters: Optional[Dict[str, List[Any]]] = None, 
                         knowledge_bank_selection: list=[], knowledge_bank_enabled: bool=False):
        qa_chain = self.create_conversation_chain(act_like_prompt=act_like_prompt, system_prompt=system_prompt) 
        if knowledge_bank_enabled and knowledge_bank_selection:
            qa_chain = self.create_conversational_retrieval_chain(act_like_prompt=act_like_prompt,
                                                                  system_prompt=system_prompt,
                                                                  filters=filters,
                                                                  knowledge_banks_to_use=knowledge_bank_selection)
        return qa_chain


    def get_answer_and_sources(
        self,
        query: str,
        chat_history: List[LlmHistory] = [],
        filters: Optional[Dict[str, List[Any]]] = None,
        file_path: str = None,
        knowledge_bank_enabled: bool=False
    ) -> Any:
        """Extracts the answer and its corresponding sources for a given prompt.

        Args:
            query (str): The user query.
            query_index: int: The index of the query within the conversation.
            chat_history (List[LlmHistory]): A list of prior interactions (optional). Each interaction
                is a dictionary with the question and response.
            filters (Optional[Dict[str, List[Any]]]): A dictionary of filters to apply to the knowledge bank.
            file_path (str): The file path uploaded into a managed folder
            knowledge_bank_enabled (bool): Precises whether the knowledge bank is enabled or not in the webapp UI.
            

        Returns:
            Dict[str, Union[str, Dict[str, Any]]]: A dictionary containing:
                - 'answer' (str): The generated answer to the prompt.
                - 'sources' (List[Dict]): A list of dict:
                    - 'excerpt' (str): The content of the source.
                    - 'metadata' (Dict[str, str]): Additional metadata about the source.
        """
        logger.debug("Generating response")
        act_like_prompt = self.prompt_parameters["act_like_prompt"]
        system_prompt = self.prompt_parameters["system_prompt"]        
        logger.debug(f"knowledge_bank_enabled: {knowledge_bank_enabled}")
        if knowledge_bank_enabled: # TODO: check the filters later           
            vector_db_type = self.knowledge_bank_vector_db_types[0] # TODO: Adapt when several knowledge banks will be connected
            if vector_db_type and filters and len(filters) > 0:
                verified_filters = process_filters_for_db( # TODO: Adapt when several knowledge banks will be connected
                    self.__verify_filters(filters=filters), vector_db_type)
                logger.debug(f"vector_db_type:{vector_db_type}   / filters: {filters}")
                filters = {self.knowledge_bank_ids[0]: verified_filters} # TODO: Adapt when several knowledge banks will be connected
            else:
                filters = {self.knowledge_bank_ids[0]: {}} # TODO: Adapt when several knowledge banks will be connected
                        
        else:
            filters = {}        

        knowledge_bank_selection = []
        if knowledge_bank_enabled:
            if self.enable_smart_usage_of_the_knowledge_bank:
                check_knowledge_bank_descriptions(self.per_knowledge_bank_parameters)
                if len(chat_history) > 0:
                    knowledge_bank_selection_query = self.condensation_chain_handler.condense_chat_history(llm=self.llm,
                                                                                                        chat_history=chat_history,
                                                                                                        last_user_input=query)
                else:
                    knowledge_bank_selection_query = query
                logger.debug(f"knowledge_bank_selection_query/condensation: {knowledge_bank_selection_query}")
                knowledge_bank_selection = self.knowledge_bank_selection_chain_handler.get_knowledge_banks_to_use(self.llm, knowledge_bank_selection_query)
            else:
                knowledge_bank_selection = self.knowledge_bank_ids
        if knowledge_bank_selection == []:
            logger.warn("No knowledge bank has been selected.")
        logger.debug(f"knowledge_bank_selection: {knowledge_bank_selection}")

        answer_in_question_language = dataiku_api.webapp_config.get("answer_in_question_language", False)
        logger.debug(f"answer_in_question_language is set to :{answer_in_question_language}")
        query_prompt =  get_language_rephrasing_prompt(query, answer_in_question_language=answer_in_question_language)

        if file_path:
            return self.run_llm_with_media(act_like_prompt=act_like_prompt,
                                           system_prompt=system_prompt,
                                           user_question=query_prompt,
                                           chat_history=chat_history,
                                           file_path=file_path,
                                           knowledge_bank_enabled=knowledge_bank_enabled,
                                           filters=filters,
                                           knowledge_bank_selection=knowledge_bank_selection
                                           )
        else:
            return self.run_llm(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                user_question=query_prompt,
                chat_history=chat_history,
                knowledge_bank_enabled=knowledge_bank_enabled,
                filters=filters,
                knowledge_bank_selection=knowledge_bank_selection
            )
        
    def run_llm(
        self,
        act_like_prompt: str,
        system_prompt: str,
        user_question: str,
        chat_history: List[LlmHistory] = [],
        knowledge_bank_enabled: bool = False,
        filters= None,
        knowledge_bank_selection: list = []
    ) -> Any:
        """
        Run the LLM with the provided query and chat history.

        Args:
            act_like_prompt (str): The configured settings prompt.
            system_prompt (str): The system prompt for the LLM
            user_question (str): The user query string
            chat_history (List[LlmHistory], optional): List of chat histories,
                                                           where each chat history is
                                                           represented as a dictionary with
                                                           inputs and outputs. Defaults to [].
            filters (Optional[Dict[str, List[Any]]]): Selected filters to be applied
            knowledge_bank_id: The knowledge bank DSS id
            knowledge_bank_enabled: Precises whether the knowledge bank is enabled or not in the webapp UI.

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        self.update_memory(chat_history=chat_history)
        try:
            llm_capabilities = get_llm_capabilities()
            qa_chain = self.prepare_qa_chain(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                knowledge_bank_enabled=knowledge_bank_enabled,
                filters=filters,
                knowledge_bank_selection=knowledge_bank_selection
                )
            return self.run_with_capabilities(llm_capabilities=llm_capabilities,
                                              qa_chain=qa_chain,
                                              user_question=user_question,
                                              knowledge_bank_enabled=knowledge_bank_enabled,
                                              knowledge_bank_selection=knowledge_bank_selection,
                                              filters=filters,
                                              chat_history=chat_history
                                              )
        except Exception as e:
            logger.error(f"Service Got exception:{e}")
            return "ERROR"
        
    def run_llm_with_media(self,
                            act_like_prompt: str,
                            system_prompt: str,
                            user_question: str,
                            chat_history: List[LlmHistory] = [],
                            file_path: str="",
                            knowledge_bank_enabled:bool=False,
                            filters: Optional[Dict[str, List[Any]]]=None,
                            knowledge_bank_selection:List[str]=[]
                            ) -> Any:
        """
        Run the LLM with the provided query and file.

        Args:
            act_like_prompt (str): The configured settings prompt.
            system_prompt (str): The system prompt for the LLM
            user_question (str): The user query string
            query_index: int: The index of the query within the conversation. 
            file_path (str): File path of the image uploaded to a managed folder
            chat_history (List[LlmHistory], optional): List of chat histories,
                                                           where each chat history is
                                                           represented as a dictionary with
                                                           inputs and outputs. Defaults to [].

        Returns:
            Any: The result of running the LLM. The return type may vary
                 depending on the LLM's implementation.
        """
        response = ""
        resp = None

        try:
            img_b64 = b64encode_image_from_path(file_path)
            self.update_memory(chat_history=chat_history)
            question_context = None
            computed_prompt = None
            qa_chain = self.prepare_qa_chain(
                act_like_prompt=act_like_prompt,
                system_prompt=system_prompt,
                knowledge_bank_enabled=knowledge_bank_enabled,
                filters=filters,
                knowledge_bank_selection=knowledge_bank_selection
                )
            if not knowledge_bank_enabled:
                computed_prompt = self.compute_prompt_for_streaming(
                    conv_chain=qa_chain, user_question=user_question)
            else:
                [computed_prompt, question_context] = qa_chain.prepare_final_answer_prompt(llm=self.llm,
                                                                                           inputs={"question": user_question, 
                                                                                                   "chat_history": self.format_history(chat_history)})
            completion = get_llm_completion()
            completion.cq["messages"].append({
                "role": "user",
                "parts": [
                    {"type": "TEXT", "text": computed_prompt.to_string()},
                    {"type": "IMAGE_INLINE", "inlineImage": img_b64}
                ]
            })
            # Check if it handles streaming or not
            llm_capabilities = get_llm_capabilities()
            if (llm_capabilities["streaming"]):
                for chunk in completion.execute_streamed():
                    yield chunk
                if knowledge_bank_enabled:
                    # Send sources and filters at the end of the streaming
                    yield self.get_as_json(question_context, filters=filters, knowledge_bank_selection=knowledge_bank_selection)
            else:
                resp = completion.execute()
                if resp and resp.success:
                    response = resp.text
                else:
                    logger.error(f"Multimodal completion call failed: ${resp._raw if resp else 'No response'}")
                    response = resp._raw if resp else None
                    yield response
        except DataikuException as e:
            logger.error(f"Dataiku API Error: {e}")
        except FileNotFoundError:
            logger.error("File not found in the managed folder.")
        except IOError as e:
            logger.error(f"I/O Error: {e}")
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")

    def run_with_capabilities(self, llm_capabilities: Dict[str, bool],
                              qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                              user_question: str,
                              knowledge_bank_enabled: bool=False,
                              knowledge_bank_selection: list=[],
                              filters= None,
                              chat_history: Optional[Any] = None
                              ):
        if (llm_capabilities["streaming"]):
            return self.run_streaming_mode(qa_chain=qa_chain, user_question=user_question,
                                           knowledge_bank_enabled=knowledge_bank_enabled, knowledge_bank_selection=knowledge_bank_selection,
                                           filters=filters, chat_history=chat_history)
        else:
            return self.run_non_streaming_mode(qa_chain=qa_chain, user_question=user_question,
                                               knowledge_bank_enabled=knowledge_bank_enabled, knowledge_bank_selection=knowledge_bank_selection,
                                               filters=filters, chat_history=chat_history)

    def run_streaming_mode(self, qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                           user_question: str,
                           knowledge_bank_enabled: bool=False,
                           knowledge_bank_selection: list=[],
                           filters= None,
                           chat_history: Optional[Any] = None):
        question_context = {}
        if knowledge_bank_enabled and knowledge_bank_selection:
            computed_prompt, question_context = qa_chain.prepare_final_answer_prompt(llm=self.llm,
                inputs={"question": user_question, "chat_history": self.format_history(chat_history)})
            logger.debug(f"question_context: {question_context}")
            
        else:
            computed_prompt = self.compute_prompt_for_streaming(
                conv_chain=qa_chain, user_question=user_question)

        logger.debug(
            f"Final prompt:  {computed_prompt.to_string()}")
        completion = get_llm_completion()
        completion.cq["messages"].append({
            "role": "user",
            "parts": [
                {"type": "TEXT",
                    "text": computed_prompt.to_string()},
            ]
        })
        for chunk in completion.execute_streamed():
            yield chunk

        if knowledge_bank_enabled: #and knowledge_bank_selection:
            # Send sources and filters at the end of the streaming
            yield self.get_as_json(question_context, filters=filters, knowledge_bank_selection=knowledge_bank_selection)

    def run_non_streaming_mode(self,
                               qa_chain: Union[ConversationChain, DKUConversationRetrievalChain],
                               user_question: str,
                               chat_history: List[LlmHistory] = [],
                               knowledge_bank_enabled: bool=False,
                               knowledge_bank_selection:list=[],
                               filters= None):
        if knowledge_bank_enabled and knowledge_bank_selection:
            response = qa_chain(
                {"question": user_question, "chat_history": self.format_history(chat_history)})
            yield self.get_as_json(response, filters=filters, knowledge_bank_selection=knowledge_bank_selection)
        else:
            yield self.get_as_json(qa_chain.predict(input=user_question), filters=filters, knowledge_bank_selection=knowledge_bank_selection)
            
    def create_conversation_chain(
            self,
            act_like_prompt: str,
            system_prompt: str) -> ConversationChain:
        """
            Initializes a ConversationChain with a custom prompt template for generating detailed and friendly AI-human interactions.

            Parameters:
            - act_like_prompt (str): A descriptive string guiding the AI's behavior and language style.
            - system_prompt (str): A system prompt for the AI to follow.

            Returns:
            - ConversationChain: An instance configured with a tailored prompt template, leveraging the provided `act_like_prompt`.
        """
        template = r"""{act_like_prompt}
        
        {system_prompt}
                
        Current conversation:
        {{history}}

        Human: {{input}}
        Assistant:""".format(act_like_prompt=act_like_prompt, system_prompt=system_prompt)
        qa_prompt = PromptTemplate(
            input_variables=["history", "input"], template=template)

        chain = ConversationChain(
            llm=self.llm, memory=self.memory, verbose=True, prompt=qa_prompt)
        return chain

    def create_conversational_retrieval_chain(self,
                                              act_like_prompt: str,
                                              system_prompt: str,
                                              filters= None,
                                              knowledge_banks_to_use: list=[]
                                              ) -> DKUConversationRetrievalChain:
        enable_llm_citations = dataiku_api.webapp_config.get("enable_llm_citations", False)
        context_prompt = CITATIONS_PROMPT if enable_llm_citations else "### CONTEXT"
        general_retrieval_template = r""" 
        {act_like_prompt}
        
        {system_prompt}

        {context_prompt}

        ----
        {{context}}
        ----
        """.format(act_like_prompt=act_like_prompt, system_prompt=system_prompt, context_prompt=context_prompt)
        if enable_llm_citations:
            question_prefix = "Leveraging the context sources and our citations policy, "
            question_suffix = " Apply citations referencing the sources folowing the citations policy."
        else:
            question_prefix = "Given the context, "
            question_suffix = ""
        general_user_template = question_prefix+"{question}"+question_suffix+"\nAssistant: "

        logger.debug("Building general_user_template")
        messages = [
            SystemMessagePromptTemplate.from_template(
                general_retrieval_template),
            HumanMessagePromptTemplate.from_template(
                general_user_template)
        ]
        qa_prompt = ChatPromptTemplate.from_messages(messages)

        retriever_chain = self.get_ensemble_retriever(knowledge_banks_to_use, filters=filters)
        
        dku_chain = DKUConversationRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever_chain,
            return_source_documents=True,
            verbose=True,
            condense_question_llm=self.llm,
            chain_type="stuff",
            combine_docs_chain_kwargs={'prompt': qa_prompt},
        )
        return dku_chain
    

    def format_history(self, chat_history):
        return [
            (item["input"], item["output"]) for item in chat_history
        ]
    
    def get_as_json(
        self,
        generated_answer: Union[str, Dict[str, Any]],
        filters= None,
        knowledge_bank_selection: list=[]
    ) -> Dict[str, Any]:
        
        def handle_filters(filters):
            clear_filters = True
            for kb_id in self.knowledge_bank_ids:
                if filters:
                    kb_filters =  filters[kb_id]
                    if kb_filters:
                        clear_filters = False
            if clear_filters:
                filters = None
            return filters
        
        filters = handle_filters(filters)
        if isinstance(generated_answer, str):
            return {"answer": generated_answer, "sources": [], "filters": filters, "knowledge_bank_selection": knowledge_bank_selection}
        else:
            if isinstance(generated_answer, dict):
                source_documents: List[Document] = generated_answer.get(
                    "source_documents", []
                )
                answer = generated_answer.get("answer", "")
                sources = []
                for document in source_documents:
                    source_content = document.page_content
                    source_metadata = document.metadata

                    sources.append(dict(
                        Source(
                            excerpt=source_content, metadata=source_metadata
                            )))

                sources = map_rag_sources(sources)
                return {"answer": answer, "sources": sources, "filters": filters, "knowledge_bank_selection": knowledge_bank_selection}
            else:
                return {}
    
    def get_ensemble_retriever(self, knowledge_bank_selection, filters={}):
        knowledge_bank_retrievers = []
        for knowledge_bank_id in knowledge_bank_selection:
            knowledge_bank_filter = filters[knowledge_bank_id]
            knowledge_bank_retriever = get_knowledge_bank_retriever(
                knowledge_bank_id, knowledge_bank_filter,
                self.all_knowledge_bank_parameters["retrieval_parameters"]["search_type"])
            knowledge_bank_retrievers.append(knowledge_bank_retriever)
        if self.knowledge_bank_weighs:
            ensemble_retriever = EnsembleRetriever(retrievers=knowledge_bank_retrievers, weights=self.knowledge_bank_weighs)
        else:
            ensemble_retriever = EnsembleRetriever(retrievers=knowledge_bank_retrievers)
        return ensemble_retriever

    def get_conversation_title(self, query: str, answer: str):
        result = self.conversation_title_chain.run(query=query, answer=answer)
        json_answer = self.get_as_json(result)
        return json_answer.get("answer", CONVERSATION_DEFAULT_NAME)


memory_max_token_limit = int(
    dataiku_api.webapp_config.get("memory_token_limit", 2000))

llm_qa = LLM_Question_Answering(memory_max_token_limit, llm_setup.get_llm())