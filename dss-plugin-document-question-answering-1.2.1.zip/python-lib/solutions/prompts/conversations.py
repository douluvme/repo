from langchain.chains.conversational_retrieval.prompts import CONDENSE_QUESTION_PROMPT
from langchain.prompts import PromptTemplate


# Conversation summary
CONVERSATION_TITLE_PROMPT = """Given a user query and a generated answer, write a conversation title that is concise.

The user query: {query}

The generated text: {answer}

Conditions:
- Don't write a title that contains more than 6 words.
"""


# Condensation
dku_condense_question_template = """Given the chat history and the follow up user input, rephrase the follow up user input to get a standalone sentence, in its original language. If the follow up user input is a question, rephrase the sentence as a question. On the other hand, if it is a declarative sentence, rephrase it as a declarative sentence.

# Chat history:
{chat_history}
# Follow up user input: {question}
# Standalone sentence:"""

DKU_CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template(dku_condense_question_template)

class CondensationChainHandler:
    def __init__(self, contensation_prompt: str="langchain"):
        if contensation_prompt == "langchain":
            self.prompt = CONDENSE_QUESTION_PROMPT
        elif contensation_prompt == "dataiku":
            self.prompt = DKU_CONDENSE_QUESTION_PROMPT
        self.chain = None
    
    def get_chain(self, llm):
        condensation_chain = self.prompt | llm
        self.chain = condensation_chain
        return condensation_chain
    
    def format_chat_history_for_condensation(self, chat_history: list, dialogs_format: str="input_output_dictionaries"):
        """
        Formats a chat history as a string for condensation

        :param: chat_history: list: The chat history containing dialog turns.
        :param: dialogs_format: str: The format of the chat dialogs. Allowed values are:
            - 'input_output_dictionaries': if the 'chat_history' contains dictionaries with 'input' and 'output'.
                Example: [{'input': 'What is the capital of Germany?', 'output': 'The capital of Germany is Berlin.'}]
            - 'tuples' if  the 'chat_history' cotains tuples:
                Example: [('What is the capital of Germany?', 'The capital of Germany is Berlin.')]

        """
        chat_history_string = ""
        for dialog_turn in chat_history:
            if dialogs_format == "input_output_dictionaries":
                human_input = dialog_turn['input']
                ai_input = dialog_turn['output']
            elif dialogs_format == "tuples":
                human_input = dialog_turn[0]
                ai_input = dialog_turn[1]
            chat_history_string += f"Human: {human_input}\nAssistant:{ai_input}\n"
        return chat_history_string 

    def condense_chat_history(self, llm, chat_history, last_user_input, dialogs_format: str="input_output_dictionaries"):
        chat_history_str = self.format_chat_history_for_condensation(chat_history, dialogs_format)
        condensation_chain = self.get_chain(llm)
        llm_condensation = condensation_chain.invoke(input={"chat_history": chat_history_str, "question": last_user_input})
        return llm_condensation