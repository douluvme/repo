FORMAT_JSON_PROMPT = """For all responses to the following query, present the information strictly in JSON format. 
Do not include any introductory text, conclusions, any form of narrative or any key/values that are not relevant. 
Simply provide the requested data or answers encapsulated within a JSON object structure, including appropriate keys and values that directly relate to the query. 
The response should start and end with curly braces {{}}. The opening (resp. 'closing') curly brace is the JSON start (resp. 'end').
Keys should be descriptive of the data they represent, and all key names must be enclosed in double quotes. 
Values should be accurately represented according to their data type (e.g., strings in double quotes, numerical values without quotes, boolean as true or false). 
Arrays should be used to list multiple items, if necessary. 
Example of a bad response (response is between the ''): '```json\n{{\n"key": "value"\n}}\n```'
The previous response starts and ends by '```' and contains 'json' at the beginning: it won't be possible to read it.
The response should have been (response is between the ''): '{{\n"key": "value"\n}}'
Ensure the syntax is valid JSON that follows the structure described in the guidelines: Keys that were not presented in the guidelines are not tolerated.
Human: Here's the specific query: {user_input}.
Assistant:
""" # Works well by providing few-shots examples of question/answers adapted to your context. 