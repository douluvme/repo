from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate


class ConversationTitleChainHandler:
    def __init__(self, prompt_template: str):
        self.prompt = PromptTemplate.from_template(prompt_template)
        self.chain = None

    def get_chain(self, llm):
        conversation_title_creation_chain = LLMChain(
            llm=llm, prompt=self.prompt
            )
        self.chain = conversation_title_creation_chain
        return conversation_title_creation_chain