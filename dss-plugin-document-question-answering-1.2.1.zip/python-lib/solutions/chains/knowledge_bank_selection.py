from solutions.prompts.output_formatting import FORMAT_JSON_PROMPT
from langchain.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate
)
from langchain_core.output_parsers import JsonOutputParser


ROLE = "You are a JSON formatting assistant."

GUIDELINES = """# Guidelines:
- Knowledge Banks are databases designed for retrieving additional information to assist in answering questions. 
- You have access to a set of Knowledge Banks.
- Utilize the Knowledge Banks when their content are pertinent to the question at hand.
- Create JSON objects that specify which Knowledge Banks are applicable for answering a particular question.
- All the JSON responses you create should follow the format {{"sources_of_information": ARRAY_INFORMATION_SOURCES}}, where:
    - ARRAY_INFORMATION_SOURCES is an array containing tags that identify all relevant Knowledge Banks for the question.
    - ARRAY_INFORMATION_SOURCES is left empty if no Knowledge Bank applies to the question.
"""

EXAMPLES = """# The following rows are examples assuming you have access to the Knowledge Banks:
- 'country_news' that contains daily news of the world countries over the last 10 years, here are examples of the answers you should provide in conversations.
- 'macro_economy' that contains macro economic data recorded days after days over the last 20 years.

Human: How are you doing?
Assistant: {{"sources_of_information": []}}
Human: Which country had demonstrations yesterday?
Assistant: {{"sources_of_information": ["country_news"]}}
Human: Which country had their presidential elections in 2000?
Assistant: {{"sources_of_information": ["country_news"]}}
Human: What is the color of my favorite T-shirt?
Assistant: {{"sources_of_information": []}}
Human: What could explain the recent increase of the employment rate?
Assistant: {{"sources_of_information": ["country_news", "macro_economy"]}}
"""

CONVERSATION_START = """# Conversation start
# KNOWLEDGE BANKS CONTEXT
"""

class KnowledgeBankSelectionChainHandler:
    def __init__(self, knowledge_bank_ids, knowledge_bank_descriptions):
        self.knowledge_bank_ids = knowledge_bank_ids
        knowledge_bank_description = "The available Knowledge Banks are:"
        for knowledge_bank_id, knowledge_bank_description in zip(knowledge_bank_ids, knowledge_bank_descriptions):
            knowledge_bank_description += f"\n- '{knowledge_bank_id}': {knowledge_bank_description}"
        knowledge_bank_description += "\n\n"   
        system_prompt = f"{ROLE}\n{GUIDELINES}\n\n{EXAMPLES}\n\n"\
            f"{CONVERSATION_START}{knowledge_bank_description}\n\n"

        knowledge_bank_selection_messages = [
            SystemMessagePromptTemplate.from_template(
                system_prompt),
            HumanMessagePromptTemplate.from_template(
            FORMAT_JSON_PROMPT)
        ]
        self.prompt = ChatPromptTemplate.from_messages(knowledge_bank_selection_messages)
        self.chain = None
    
    def get_chain(self, llm):
        knowledge_bank_selection_chain = self.prompt | llm
        self.chain = knowledge_bank_selection_chain
        return knowledge_bank_selection_chain
    
    def get_knowledge_banks_to_use(self, llm, user_question):
        knowledge_banks_to_use = []
        knowledge_bank_selection_chain = self.get_chain(llm) | JsonOutputParser()
        chain_response = knowledge_bank_selection_chain.invoke(input={"user_input": user_question})
        print(f"Knowledge Bank Selection chain_response: {chain_response}")
        sources_of_information = chain_response.get("sources_of_information")
        if sources_of_information:
            knowledge_bank_candidates = [
                source for source in sources_of_information
                if source in self.knowledge_bank_ids
            ]
            if knowledge_bank_candidates:
                knowledge_banks_to_use += knowledge_bank_candidates
        return knowledge_banks_to_use