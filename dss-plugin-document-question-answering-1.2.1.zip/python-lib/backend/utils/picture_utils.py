import dataiku
from typing import Dict
import base64
from backend.utils.dataiku_api import dataiku_api


def b64encode_image_from_path(file_path: str):
    """
        Encodes an image from a specified file path to a base64-encoded string.

        Parameters:
        - file_path (str): The path to the image file to be encoded. This path must point to a valid
        image file in the managed folder configured in the webapp.

        Returns:
        - str: A base64-encoded string representing the image. This string can be directly used in data URIs
            or for storage in text-based formats.
    """
    config: Dict[str, str] = dataiku_api.webapp_config
    upload_folder: str = config.get("upload_folder")
    file_folder = dataiku.Folder(upload_folder)
    with file_folder.get_download_stream(file_path) as stream:
        file_content = stream.read()
    base64_encoded = base64.b64encode(file_content)
    img_b64 = base64_encoded.decode('utf-8')
    return img_b64