from lingua import Language, LanguageDetectorBuilder, ConfidenceValue
from typing import List
from llm_assist.logging import logger

# Eager-loading all language models on import to improve performance
SUPPORTED_DETECTION_LANGUAGES = [Language.ENGLISH, Language.GERMAN, Language.KOREAN,
                                 Language.SPANISH, Language.JAPANESE, Language.ARABIC,
                                 Language.FRENCH]

detector = LanguageDetectorBuilder.from_languages(*SUPPORTED_DETECTION_LANGUAGES).with_preloaded_language_models().build()

def determine_lang(lang_confidence_values: List[ConfidenceValue], prob_threshold: float = 0.1)->str:
    if len(lang_confidence_values)>0:
        top_lang = lang_confidence_values[0]
        confidence_value = top_lang.value 
        language_name =  top_lang.language.name.title()
        logger.debug(f'Question language is {language_name} with confidence value of {round(confidence_value, 2)}')
        if confidence_value > prob_threshold:
            return language_name
    return ''

def detect_query_langs(user_question: str)->List[ConfidenceValue]:
    lang_confidence_values = detector.compute_language_confidence_values(user_question)
    return determine_lang(lang_confidence_values)
    
def get_language_rephrasing_prompt(user_question: str, answer_in_question_language: bool = True, min_word_len: int = 2)->str:
    n_words = len(user_question.split())
    if answer_in_question_language and n_words > min_word_len:
        lang = detect_query_langs(user_question)
        if len(lang) > 0:
            return user_question + f" \n It is essential that you reply to my question in {lang}. Do not mention this."

    logger.debug('No language enforced. Either the question is too short or the language is confidence is too low.')
    return user_question

if __name__ == "__main__":
    user_question ="Xin chào. Bạn có thể giúp tôi không?"
    print(get_language_rephrasing_prompt(user_question))
    user_question ="Que más?"
    print(get_language_rephrasing_prompt(user_question))
    user_question ="What else?"
    print(get_language_rephrasing_prompt(user_question))
    user_question ="Yo!"
    print(get_language_rephrasing_prompt(user_question))
