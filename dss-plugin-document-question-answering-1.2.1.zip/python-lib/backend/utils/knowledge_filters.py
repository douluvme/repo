from backend.utils.dataiku_api import dataiku_api
from backend.utils.dataiku_utils import find_recipe
from backend.utils.metas_utils import is_string_list_representation, convert_to_list
from llm_assist.logging import logger
from typing import Dict, Any, TypedDict, List
import dataiku
import pandas as pd


class KnowledgeBankFilterConfig(TypedDict):
    input_dataset: str
    filter_columns: List[str]
    filter_options: Dict[str, List[Any]]
    vector_db_type: str


def flatten(list_of_lists):
    return [item for sublist in list_of_lists for item in sublist]


# Disable lists flattening for now, just show what has been configured
manage_lists = False


def compute_filter_options(input_dataset: str, columns: List[str]):
    dataset = dataiku.Dataset(
        project_key=dataiku_api.default_project_key, name=input_dataset
    )
    df: pd.DataFrame = dataset.get_dataframe(
        columns=columns, parse_dates=False)
    result = {}
    for column in df.columns:
        if manage_lists:
            if df[column].apply(lambda x: isinstance(x, str) and is_string_list_representation(x)).any():
                df[column] = df[column].apply(convert_to_list)

            if df[column].apply(lambda x: isinstance(x, list)).any():
                flattened_list = [
                    item for sublist in df[column].dropna().tolist() for item in sublist]
                unique_values = pd.unique(flattened_list)
            else:
                unique_values = pd.unique(df[column])
        else:
            unique_values = pd.unique(df[column])

        result[column] = list(unique_values)
    return result


def get_knowledge_bank_filtering_settings(knowledge_bank_id: str, with_options: bool = True):
    project = dataiku_api.default_project
    config = dataiku_api.webapp_config
    vector_db_type = None
    if not with_options and knowledge_bank_id:
        vector_db_type = project.get_knowledge_bank(
            knowledge_bank_id).as_core_knowledge_bank()._get()['vectorStoreType']

    flow = project.get_flow()
    graph = flow.get_graph()
    recipe_json = None
    try:
        recipe_json = find_recipe(graph.data, knowledge_bank_id)
    except KeyError:
        raise KeyError(knowledge_bank_id)

    dataset_name = recipe_json.get("predecessors")[0]
    recipe_name = recipe_json.get("ref")
    recipe = project.get_recipe(recipe_name)
    recipe_settings = recipe.get_settings()
    recipe_json_payload = recipe_settings.get_json_payload()
    kb_columns = []
    if "metadataColumns" in recipe_json_payload:
        metadataColumns = recipe_json_payload["metadataColumns"]
        if metadataColumns:
            for metadata in metadataColumns:
                if with_options:
                    if metadata["column"] in config.get('knowledge_sources_filters'):
                        kb_columns.append(metadata["column"])
                else:
                    kb_columns.append(metadata["column"])

    filter_options = {}
    if len(kb_columns) > 0 and with_options:
        filter_options = compute_filter_options(
            dataset_name, columns=kb_columns)

    return KnowledgeBankFilterConfig(
        input_dataset=dataset_name,
        filter_columns=kb_columns,
        filter_options=filter_options,
        vector_db_type=vector_db_type
    )

def get_current_filter_config():
    # TODO: Adapt when several knowledge banks will be connected
    knowledge_bank_id = dataiku_api.webapp_config.get(
        "knowledge_bank_id", None)
    if knowledge_bank_id:
        try:
            result = get_knowledge_bank_filtering_settings(
                knowledge_bank_id)
            return result
        except KeyError:
            return None
    return None


def transform_filters_for_pinecone(filters: Dict[str, List[Any]]):
    transformed_filters = []
    for key, value in filters.items():
        if isinstance(value, list) and len(value) >= 2:
            or_filter = {'$or': [{key: v} for v in value]}
            transformed_filters.append(or_filter)
        elif len(value) == 1:
            transformed_filters.append({key: value[0]})
        else:
            raise ValueError("No valid filters provided.")

    return {'$and': transformed_filters} if len(transformed_filters) > 1 else transformed_filters[0]


def transform_filters_for_chroma_db(filters: Dict[str, List[Any]]):
    transformed_filters = []

    for key, value in filters.items():
        if isinstance(value, list) and len(value) >= 2:
            or_filter = {'$or': [{key: v} for v in value]}
            transformed_filters.append(or_filter)
        elif len(value) == 1:
            transformed_filters.append({key: value[0]})
        else:
            raise ValueError("No valid filters provided.")

    if len(transformed_filters) > 1:
        return {'$and': transformed_filters}
    elif len(transformed_filters) == 1:
        return transformed_filters[0]
    else:
        raise ValueError("No valid filters provided.")


def process_filters_for_db(filters: Dict[str, List[Any]], vector_db_type):
    logger.debug(f"processing filters for {vector_db_type}")
    if vector_db_type == 'CHROMA':
        return transform_filters_for_chroma_db(filters)
    elif vector_db_type == 'FAISS':
        return filters
    elif vector_db_type == 'PINECONE':
        return transform_filters_for_pinecone(filters)
    else:
        raise ValueError(
            f"Unsupported database type for filtering: {vector_db_type}")